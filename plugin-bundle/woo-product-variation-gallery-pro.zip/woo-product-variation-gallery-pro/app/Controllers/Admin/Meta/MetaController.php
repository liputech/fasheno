<?php

namespace Rtwpvgp\Controllers\Admin\Meta;

class MetaController {
	public function __construct() { 
		new MetaOptions(); 
	}  
}