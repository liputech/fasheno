<?php

/**
 * Per-product gallery settings via WooCommerce product data tab.
 *
 * @package Rtwpvgp\Controllers\Admin\Meta
 */

namespace Rtwpvgp\Controllers\Admin\Meta;

/**
 * Class MetaOptions
 *
 * Adds a "Variation Gallery" tab to WooCommerce product data panel
 * for per-product gallery settings override.
 */
class MetaOptions {

	/**
	 * Meta key for per-product thumbnail position.
	 *
	 * @var string
	 */
	const THUMBNAIL_POSITION_META = '_rtwpvg_thumbnail_position';

	/**
	 * Meta key for per-product gallery change effect.
	 *
	 * @var string
	 */
	const GALLERY_EFFECT_META = '_rtwpvg_gallery_change_effect';

	/**
	 * Meta key for per-product zoom setting.
	 *
	 * @var string
	 */
	/**
	 * Meta key for per-product thumbnails columns.
	 *
	 * @var string
	 */
	const THUMBNAILS_COLUMNS_META = '_rtwpvg_thumbnails_columns';

	/**
	 * Meta key for per-product thumbnails columns (medium device).
	 *
	 * @var string
	 */
	const THUMBNAILS_COLUMNS_MD_META = '_rtwpvg_thumbnails_columns_sm';

	/**
	 * Meta key for per-product thumbnails columns (small device).
	 *
	 * @var string
	 */
	const THUMBNAILS_COLUMNS_SM_META = '_rtwpvg_thumbnails_columns_xs';

	/**
	 * Meta key for per-product thumbnail slider setting.
	 *
	 * @var string
	 */
	const THUMBNAIL_SLIDE_META = '_rtwpvg_thumbnail_slide';


	/**
	 * Constructor to initialize hooks.
	 */
	public function __construct() {
		add_action( 'rtwpvg_product_data_panel_content', [ $this, 'render_product_data_panel' ] );
		add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_meta' ] );
	}

	/**
	 * Render the Variation Gallery panel content.
	 *
	 * @return void
	 */
	public function render_product_data_panel() {
		global $post;

		$thumbnail_position    = get_post_meta( $post->ID, self::THUMBNAIL_POSITION_META, true );
		$gallery_effect        = get_post_meta( $post->ID, self::GALLERY_EFFECT_META, true );
		$thumbnail_slide       = get_post_meta( $post->ID, self::THUMBNAIL_SLIDE_META, true );
		$thumbnails_columns    = get_post_meta( $post->ID, self::THUMBNAILS_COLUMNS_META, true );
		$thumbnails_columns_md = get_post_meta( $post->ID, self::THUMBNAILS_COLUMNS_MD_META, true );
		$thumbnails_columns_sm = get_post_meta( $post->ID, self::THUMBNAILS_COLUMNS_SM_META, true );

		$thumbnail_options = apply_filters(
			'rtwpvg_thumbnail_style',
			[
				'bottom' => esc_html__( 'Position Bottom', 'woo-product-variation-gallery' ),
			]
		);
		?>
		<div class="options_group">
			<p class="form-field">
				<strong><?php esc_html_e( 'Override global gallery settings for this product.', 'woo-product-variation-gallery-pro' ); ?></strong>
			</p>
		</div>

		<div class="options_group">
				<?php
				woocommerce_wp_text_input(
					[
						'id'                => 'rtwpvg_thumbnails_columns',
						'label'             => esc_html__( 'Thumbnail Items', 'woo-product-variation-gallery-pro' ),
						'description'       => esc_html__( 'Override thumbnail items per row, column, or view. Leave empty to use global setting. Limit: 2-8.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'          => true,
						'value'             => $thumbnails_columns,
						'type'              => 'number',
						'placeholder'       => esc_html__( 'Global Setting', 'woo-product-variation-gallery-pro' ),
						'custom_attributes' => [
							'min'  => 2,
							'max'  => 8,
							'step' => 1,
						],
					]
				);

				woocommerce_wp_text_input(
					[
						'id'                => 'rtwpvg_thumbnails_columns_sm',
						'label'             => esc_html__( 'Thumbnail Items (Tablet ≤992px)', 'woo-product-variation-gallery-pro' ),
						'description'       => esc_html__( 'Override thumbnail items for tablet devices. Leave empty to use global setting. Limit: 2-8.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'          => true,
						'value'             => $thumbnails_columns_md,
						'type'              => 'number',
						'placeholder'       => esc_html__( 'Global Setting', 'woo-product-variation-gallery-pro' ),
						'custom_attributes' => [
							'min'  => 2,
							'max'  => 8,
							'step' => 1,
						],
					]
				);

				woocommerce_wp_text_input(
					[
						'id'                => 'rtwpvg_thumbnails_columns_xs',
						'label'             => esc_html__( 'Thumbnail Items (Mobile ≤480px)', 'woo-product-variation-gallery-pro' ),
						'description'       => esc_html__( 'Override thumbnail items for mobile devices. Leave empty to use global setting. Limit: 2-8.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'          => true,
						'value'             => $thumbnails_columns_sm,
						'type'              => 'number',
						'placeholder'       => esc_html__( 'Global Setting', 'woo-product-variation-gallery-pro' ),
						'custom_attributes' => [
							'min'  => 2,
							'max'  => 8,
							'step' => 1,
						],
					]
				);

				woocommerce_wp_select(
					[
						'id'          => 'rtwpvg_thumbnail_position',
						'label'       => esc_html__( 'Thumbnail Style', 'woo-product-variation-gallery-pro' ),
						'description' => esc_html__( 'Override the global thumbnail position for this product.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'    => true,
						'value'       => $thumbnail_position,
						'options'     => array_merge(
							[ '' => esc_html__( '— Global Setting —', 'woo-product-variation-gallery-pro' ) ],
							$thumbnail_options
						),
					]
				);

				woocommerce_wp_select(
					[
						'id'          => 'rtwpvg_thumbnail_slide',
						'label'       => esc_html__( 'Thumbnail Slider', 'woo-product-variation-gallery-pro' ),
						'description' => esc_html__( 'Override the global thumbnail slider setting.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'    => true,
						'value'       => $thumbnail_slide,
						'options'     => [
							''    => esc_html__( '— Global Setting —', 'woo-product-variation-gallery-pro' ),
							'yes' => esc_html__( 'Enable', 'woo-product-variation-gallery-pro' ),
							'no'  => esc_html__( 'Disable', 'woo-product-variation-gallery-pro' ),
						],
					]
				);
				?>
				<script>
					jQuery(function($){
						var $position = $('#rtwpvg_thumbnail_position');
						var $slideField = $('#rtwpvg_thumbnail_slide').closest('.form-field');
						function toggleSlideField(){
							var val = $position.val();
							if ( '' === val ) {
								val = '<?php echo esc_js( rtwpvg()->get_option( 'thumbnail_position', 'bottom' ) ); ?>';
							}
							if ( 'left' === val || 'right' === val ) {
								$slideField.hide();
							} else {
								$slideField.show();
							}
						}
						toggleSlideField();
						$position.on('change', toggleSlideField);
					});
				</script>
				<?php

				woocommerce_wp_select(
					[
						'id'          => 'rtwpvg_gallery_change_effect',
						'label'       => esc_html__( 'Transition Effect', 'woo-product-variation-gallery-pro' ),
						'description' => esc_html__( 'Override the main image slider transition effect.', 'woo-product-variation-gallery-pro' ),
						'desc_tip'    => true,
						'value'       => $gallery_effect,
						'options'     => [
							''      => esc_html__( '— Global Setting —', 'woo-product-variation-gallery-pro' ),
							'slide' => esc_html__( 'Slide', 'woo-product-variation-gallery' ),
							'fade'  => esc_html__( 'Fade', 'woo-product-variation-gallery' ),
						],
					]
				);
				?>
			</div>


		<?php
		/**
		 * Fires at the end of the Variation Gallery product data panel.
		 *
		 * @param int $post_id The product post ID.
		 */
		do_action( 'rtwpvg_product_data_panel_end', $post->ID );
	}

	/**
	 * Save per-product gallery meta fields.
	 *
	 * @param int $post_id The product post ID.
	 *
	 * @return void
	 */
	public function save_product_meta( $post_id ) {
		$fields = [
			'rtwpvg_thumbnails_columns'    => self::THUMBNAILS_COLUMNS_META,
			'rtwpvg_thumbnails_columns_sm' => self::THUMBNAILS_COLUMNS_MD_META,
			'rtwpvg_thumbnails_columns_xs' => self::THUMBNAILS_COLUMNS_SM_META,
			'rtwpvg_thumbnail_position'    => self::THUMBNAIL_POSITION_META,
			'rtwpvg_thumbnail_slide'       => self::THUMBNAIL_SLIDE_META,
			'rtwpvg_gallery_change_effect' => self::GALLERY_EFFECT_META,
		];

		foreach ( $fields as $field_name => $meta_key ) {
			if ( isset( $_POST[ $field_name ] ) ) {
				$value = sanitize_text_field( wp_unslash( $_POST[ $field_name ] ) );
				update_post_meta( $post_id, $meta_key, $value );
			}
		}
	}
}
