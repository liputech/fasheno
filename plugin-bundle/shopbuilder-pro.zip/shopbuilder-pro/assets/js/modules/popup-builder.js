/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!*****************************************************!*\
  !*** ./src/js/frontend/v2/modules/popup-builder.js ***!
  \*****************************************************/
/**
 * ShopBuilder Popup Builder Module
 * Handles popup display, triggers, animations, and user interactions
 *
 * @version 1.0.0
 */



(function ($) {
  /**
   * Creates and initializes the Popup Builder module.
   */
  var popupBuilder = function popupBuilder() {
    var _ref = window.RTSB || {},
      cache = _ref.cache,
      events = _ref.events,
      helpers = _ref.helpers;
    var moduleCache = cache === null || cache === void 0 ? void 0 : cache.create('popupBuilder');
    return {
      name: 'popupBuilder',
      version: '1.0.0',
      /**
       * Initializes the module.
       */
      init: function init() {
        var _this = this;
        events === null || events === void 0 || events.on(document, 'rtsb:frontend:loaded', function () {
          helpers === null || helpers === void 0 || helpers.rAF(function () {
            return _this.popupHandlers();
          });
        });
        moduleCache === null || moduleCache === void 0 || moduleCache.set('initialized', true);
        return this;
      },
      /**
       * Main popup handlers initialization
       */
      popupHandlers: function popupHandlers() {
        this.initializePopup();
        this.bindPopupEvents();
        this.bindKeyboardHandlers();
      },
      /**
       * Refresh method to re-initialize popup
       */
      refresh: function refresh() {
        var _this2 = this;
        helpers === null || helpers === void 0 || helpers.rAF(function () {
          return _this2.popupHandlers();
        });
      },
      /**
       * Initialize popup
       */
      initializePopup: function initializePopup() {
        var $popup = $('#rtsb-popup-builder-wrapper');
        if (!$popup.length) {
          return;
        }

        // Parse popup configuration from JSON
        var config = this.getPopupConfig($popup);
        if (!config) {
          console.error('Popup Builder: Invalid configuration');
          return;
        }

        // Check if popup should be shown
        if (this.shouldShowPopup(config.popupId, config.frequency)) {
          this.setupTrigger($popup, config);
        }
      },
      /**
       * Get and parse popup configuration from data attribute
       *
       * @param {jQuery} $popup - The popup element
       * @return {Object|null} Parsed configuration object or null
       */
      getPopupConfig: function getPopupConfig($popup) {
        try {
          var configString = $popup.attr('data-popup-config');
          if (!configString) {
            console.warn('Popup Builder: No configuration found');
            return null;
          }
          var config = JSON.parse(configString);

          // Set defaults for missing values
          return {
            popupId: config.popupId || 'rtsb_popup_builder',
            triggerType: config.triggerType || 'time',
            triggerValue: parseInt(config.triggerValue, 10) || 500,
            frequency: config.frequency || 'always',
            entryAnimation: config.entryAnimation || 'fade_in',
            exitAnimation: config.exitAnimation || 'fade_out',
            animationSpeed: config.animationSpeed || 'normal',
            overlayAnimation: config.overlayAnimation !== false
          };
        } catch (error) {
          console.error('Popup Builder: Failed to parse config', error);
          return null;
        }
      },
      /**
       * Check if popup should be shown based on frequency and storage
       *
       * @param {string} popupId - The popup ID
       * @param {string} frequency - Display frequency (once, daily, always)
       * @return {boolean} Whether popup should be shown
       */
      shouldShowPopup: function shouldShowPopup(popupId, frequency) {
        if (!popupId) {
          return true;
        }
        var storageKey = "rtsb_popup_".concat(popupId);
        var lastShown = localStorage.getItem(storageKey);

        // No previous record, show popup
        if (!lastShown) {
          return true;
        }

        // Handle frequency-based logic
        switch (frequency) {
          case 'once':
            return this.handleOnceFrequency(popupId, storageKey);
          case 'daily':
            return this.handleDailyFrequency(lastShown);
          case 'always':
            return true;
          default:
            return true;
        }
      },
      /**
       * Handle "once per session" frequency
       *
       * @param {string} popupId - The popup ID
       * @param {string} storageKey - localStorage key
       * @return {boolean} Whether to show popup
       */
      handleOnceFrequency: function handleOnceFrequency(popupId, storageKey) {
        var sessionKey = "rtsb_session_".concat(popupId);
        var sessionStart = sessionStorage.getItem(sessionKey);
        if (!sessionStart) {
          // New session, allow showing again
          localStorage.removeItem(storageKey);
          return true;
        }
        return false;
      },
      /**
       * Handle "once per day" frequency
       *
       * @param {string} lastShown - Timestamp of last shown
       * @return {boolean} Whether to show popup
       */
      handleDailyFrequency: function handleDailyFrequency(lastShown) {
        var lastShownTime = parseInt(lastShown, 10);
        var now = Date.now();
        var oneDay = 24 * 60 * 60 * 1000;
        return now - lastShownTime > oneDay;
      },
      /**
       * Setup trigger for popup display
       *
       * @param {jQuery} $popup - The popup element
       * @param {Object} config - Popup configuration
       */
      setupTrigger: function setupTrigger($popup, config) {
        switch (config.triggerType) {
          case 'time':
            this.setupTimeTrigger($popup, config.triggerValue);
            break;
          case 'scroll':
            this.setupScrollTrigger($popup, config);
            break;
          case 'exit':
            this.setupExitIntentTrigger($popup, config);
            break;
          case 'immediate':
            this.showPopup($popup);
            break;
          default:
            console.warn("Unknown trigger type: ".concat(config.triggerType));
        }
      },
      /**
       * Setup time-based trigger
       *
       * @param {jQuery} $popup - The popup element
       * @param {number} milliseconds - Milliseconds to wait before showing
       */
      setupTimeTrigger: function setupTimeTrigger($popup, milliseconds) {
        var _this3 = this;
        setTimeout(function () {
          if (_this3.canShowPopup($popup)) {
            _this3.showPopup($popup);
          }
        }, milliseconds);
      },
      /**
       * Setup scroll-based trigger
       *
       * @param {jQuery} $popup - The popup element
       * @param {Object} config - Popup configuration
       */
      setupScrollTrigger: function setupScrollTrigger($popup, config) {
        var _this4 = this;
        var popupId = config.popupId || 'default';
        var scrollTriggered = false;
        $(window).on("scroll.rtsb_popup_".concat(popupId), function () {
          if (scrollTriggered || !_this4.canShowPopup($popup)) {
            return;
          }
          var scrollPercent = _this4.calculateScrollPercentage();
          if (scrollPercent >= config.triggerValue) {
            scrollTriggered = true;
            _this4.showPopup($popup);
            $(window).off("scroll.rtsb_popup_".concat(popupId));
          }
        });
      },
      /**
       * Setup exit intent trigger
       *
       * @param {jQuery} $popup - The popup element
       * @param {Object} config - Popup configuration
       */
      setupExitIntentTrigger: function setupExitIntentTrigger($popup, config) {
        var _this5 = this;
        var popupId = config.popupId || 'default';
        var exitTriggered = false;
        $(document).on("mouseleave.rtsb_popup_".concat(popupId), function (e) {
          if (exitTriggered || !_this5.canShowPopup($popup)) {
            return;
          }

          // Mouse moved to top of viewport (closing browser/tab)
          if (e.clientY < 0) {
            exitTriggered = true;
            _this5.showPopup($popup);
            $(document).off("mouseleave.rtsb_popup_".concat(popupId));
          }
        });
      },
      /**
       * Calculate current scroll percentage
       *
       * @return {number} Scroll percentage (0-100)
       */
      calculateScrollPercentage: function calculateScrollPercentage() {
        var scrollTop = $(window).scrollTop();
        var docHeight = $(document).height();
        var winHeight = $(window).height();
        var scrollPercent = scrollTop / (docHeight - winHeight) * 100;
        return Math.min(scrollPercent, 100);
      },
      /**
       * Check if popup can be shown (not already visible)
       *
       * @param {jQuery} $popup - The popup element
       * @return {boolean} Whether popup can be shown
       */
      canShowPopup: function canShowPopup($popup) {
        return !$popup.hasClass('active') && !$popup.is(':visible');
      },
      /**
       * Show popup with animations
       *
       * @param {jQuery} $popup - The popup element
       */
      showPopup: function showPopup($popup) {
        var _this6 = this;
        // Get config directly from element (FIXED: Don't rely on cache)
        var config = this.getPopupConfig($popup);
        if (!config) {
          console.error('Popup Builder: Configuration not found');
          return;
        }

        // Get elements
        var $container = $popup.find('.rtsb-popup-container');
        var $overlay = $popup.find('.rtsb-popup-overlay');

        // Show popup wrapper
        $popup.css('display', 'flex');
        $popup.css('opacity', '1');
        $popup.css('visibility', 'visible');

        // Reset animations
        $container.css('animation', 'none');
        $overlay.css('animation', 'none');

        // Force reflow
        $popup[0].offsetWidth;

        // Apply animations
        requestAnimationFrame(function () {
          $popup.addClass('active');
          $('body').addClass('rtsb-popup-open').css('overflow', 'hidden');

          // Container animation
          if (config.entryAnimation !== 'none') {
            var animName = _this6.getAnimationName(config.entryAnimation);
            $container.addClass("animation-".concat(config.animationSpeed));
            $container.css('animation', "".concat(animName, " ").concat(_this6.getAnimationDuration(config.animationSpeed), "s ease-out forwards"));
          } else {
            $container.css('transform', 'translate(-50%, -50%)');
          }

          // Overlay animation
          if (config.overlayAnimation) {
            $overlay.css('animation', "fadeIn ".concat(_this6.getAnimationDuration(config.animationSpeed), "s ease-out forwards"));
          }
        });

        // Save to localStorage
        this.savePopupDisplay(config.popupId, config.frequency);

        // Cache last shown popup
        moduleCache === null || moduleCache === void 0 || moduleCache.set('lastShownPopupId', config.popupId);

        // Trigger custom event
        $(document).trigger('rtsb:popup:shown', [config.popupId]);
      },
      /**
       * Close popup with animations
       *
       * @param {jQuery} $popup - The popup element
       */
      closePopup: function closePopup($popup) {
        var _this7 = this;
        // Get config directly from element (FIXED: Don't rely on cache)
        var config = this.getPopupConfig($popup);
        if (!config) {
          this.hidePopup($popup);
          return;
        }
        var $container = $popup.find('.rtsb-popup-container');
        var $overlay = $popup.find('.rtsb-popup-overlay');
        if (config.exitAnimation !== 'none') {
          // Get exit animation name
          var exitAnimName = this.getAnimationName(config.exitAnimation, true);
          var duration = this.getAnimationDuration(config.animationSpeed);
          $container.css('animation', "".concat(exitAnimName, " ").concat(duration, "s ease-in forwards"));
          if (config.overlayAnimation) {
            $overlay.css('animation', "fadeOut ".concat(duration, "s ease-in forwards"));
          }
          setTimeout(function () {
            _this7.hidePopup($popup);
          }, duration * 1000);
        } else {
          this.hidePopup($popup);
        }
      },
      /**
       * Hide popup and reset state
       *
       * @param {jQuery} $popup - The popup element
       */
      hidePopup: function hidePopup($popup) {
        var config = this.getPopupConfig($popup);
        $popup.removeClass('active');
        $popup.css('display', 'none');
        $('body').removeClass('rtsb-popup-open').css('overflow', '');
        var $container = $popup.find('.rtsb-popup-container');
        var $overlay = $popup.find('.rtsb-popup-overlay');
        $container.css('animation', 'none');
        $overlay.css('animation', 'none');

        // Trigger custom event
        $(document).trigger('rtsb:popup:closed', [config === null || config === void 0 ? void 0 : config.popupId]);
      },
      /**
       * Get CSS animation name from settings value
       *
       * @param {string} animation - Animation setting (e.g., 'fade_in', 'slide_down')
       * @param {boolean} isExit - Whether this is an exit animation
       * @return {string} CSS keyframe animation name
       */
      getAnimationName: function getAnimationName(animation) {
        var isExit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
        // Convert snake_case to camelCase
        var camelCase = animation.replace(/_([a-z])/g, function (g) {
          return g[1].toUpperCase();
        });

        // Map exit animations
        if (isExit) {
          var exitMap = {
            slideDown: 'slideDownExit',
            slideUp: 'slideUpExit',
            slideLeft: 'slideLeftExit',
            slideRight: 'slideRightExit'
          };
          return exitMap[camelCase] || camelCase;
        }
        return camelCase;
      },
      /**
       * Get animation duration in seconds
       *
       * @param {string} speed - Animation speed (fast, normal, slow)
       * @return {number} Duration in seconds
       */
      getAnimationDuration: function getAnimationDuration(speed) {
        var durations = {
          fast: 0.3,
          normal: 0.5,
          slow: 0.8
        };
        return durations[speed] || 0.5;
      },
      /**
       * Save popup display to storage
       *
       * @param {string} popupId - The popup ID
       * @param {string} frequency - Display frequency
       */
      savePopupDisplay: function savePopupDisplay(popupId, frequency) {
        if (!popupId) {
          return;
        }
        if (frequency === 'once' || frequency === 'daily') {
          localStorage.setItem("rtsb_popup_".concat(popupId), Date.now().toString());
          if (frequency === 'once') {
            sessionStorage.setItem("rtsb_session_".concat(popupId), 'true');
          }
        }
      },
      /**
       * Bind popup event handlers
       */
      bindPopupEvents: function bindPopupEvents() {
        var _this8 = this;
        // Close button click
        $(document).off('click.rtsb_popup_close').on('click.rtsb_popup_close', '.rtsb-popup-close', function (e) {
          e.preventDefault();
          var $popup = $(e.currentTarget).closest('.rtsb-popup-builder-wrapper');
          _this8.closePopup($popup);
        });

        // Overlay click
        $(document).off('click.rtsb_popup_overlay').on('click.rtsb_popup_overlay', '.rtsb-popup-overlay', function (e) {
          if (e.target === e.currentTarget) {
            var $popup = $(e.currentTarget).closest('.rtsb-popup-builder-wrapper');
            _this8.closePopup($popup);
          }
        });

        // Prevent closing when clicking inside popup content
        $(document).off('click.rtsb_popup_content').on('click.rtsb_popup_content', '.rtsb-popup-content', function (e) {
          e.stopPropagation();
        });
      },
      /**
       * Bind keyboard event handlers
       */
      bindKeyboardHandlers: function bindKeyboardHandlers() {
        var _this9 = this;
        $(document).off('keydown.rtsb_popup').on('keydown.rtsb_popup', function (e) {
          // ESC key
          if (e.keyCode === 27) {
            var $popup = $('.rtsb-popup-builder-wrapper.active');
            if ($popup.length) {
              _this9.closePopup($popup);
            }
          }
        });
      },
      /**
       * Get popup configuration
       *
       * @return {Object|null} Current popup configuration
       */
      getConfig: function getConfig() {
        var $popup = $('#rtsb-popup-builder-wrapper');
        return this.getPopupConfig($popup);
      },
      /**
       * Get popup state
       *
       * @return {Object} Popup state information
       */
      getState: function getState() {
        var $popup = $('#rtsb-popup-builder-wrapper');
        var config = this.getPopupConfig($popup);
        return {
          isVisible: $popup.hasClass('active'),
          popupId: config === null || config === void 0 ? void 0 : config.popupId,
          lastShown: moduleCache === null || moduleCache === void 0 ? void 0 : moduleCache.get('lastShownPopupId'),
          config: config
        };
      },
      /**
       * Manually trigger popup
       */
      trigger: function trigger() {
        var $popup = $('#rtsb-popup-builder-wrapper');
        if (!$popup.length) {
          console.warn('Popup element not found');
          return;
        }
        this.showPopup($popup);
      },
      /**
       * Manually close popup
       */
      close: function close() {
        var $popup = $('.rtsb-popup-builder-wrapper.active');
        if ($popup.length) {
          this.closePopup($popup);
        }
      },
      /**
       * Reset popup frequency storage
       *
       * @param {string} popupId - The popup ID to reset (optional, uses current if not provided)
       */
      resetFrequency: function resetFrequency() {
        var popupId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
        var config = this.getConfig();
        var id = popupId || (config === null || config === void 0 ? void 0 : config.popupId);
        if (!id) {
          return;
        }
        localStorage.removeItem("rtsb_popup_".concat(id));
        sessionStorage.removeItem("rtsb_session_".concat(id));
      },
      /**
       * Destroy module and cleanup
       */
      destroy: function destroy() {
        // Remove all event listeners
        $(document).off('.rtsb_popup_close .rtsb_popup_overlay .rtsb_popup_content .rtsb_popup');
        $(window).off('.rtsb_popup');

        // Hide popup if active
        var $popup = $('.rtsb-popup-builder-wrapper.active');
        if ($popup.length) {
          this.hidePopup($popup);
        }

        // Clear cache
        moduleCache === null || moduleCache === void 0 || moduleCache.clear();

        // Reset body state
        $('body').removeClass('rtsb-popup-open').css('overflow', '');
      }
    };
  };

  /**
   * Register the module if RTSB is ready
   */
  if (window.RTSB && window.RTSB._initialized) {
    var _RTSB$modules$registe;
    (_RTSB$modules$registe = RTSB.modules.register('popupBuilder', popupBuilder)) === null || _RTSB$modules$registe === void 0 || _RTSB$modules$registe.init();
  } else {
    // Initialize standalone if RTSB is not available
    $(document).ready(function () {
      var instance = popupBuilder();
      instance.popupHandlers();
    });
  }
})(jQuery);
/******/ })()
;
//# sourceMappingURL=popup-builder.js.map