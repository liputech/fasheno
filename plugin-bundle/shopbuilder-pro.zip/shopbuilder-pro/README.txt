=== ShopBuilder Pro ===

== Changelog ==

= 2.1.3 (Oct 03, 2025) =
* Fixed: Resolved query string parameter conflicts between filter functionality and general URL parameters that were causing AJAX filter requests to fail.
* Fixed: My account navigation menu items are not active when using the Page Builder.
* Fixed: Fixed Sales Notification Latest Order Data Cache Issue.
* Fixed: Fixed Sales Notification Guest User Notice Missing Issue resolved.
* Fixed: Fixed Sales Notification Refunded Order Status.
* Fixed: Improves detection of address type endpoints in BuilderFunPro by mapping endpoint options and handling i18n.
* Fix: Add to cart button With Google Site Kit issue resolve
* Added: My account "Add Payment Method" Page Builder Template.
* Optimization: Optimized Pre Order Functionality.

= 2.1.2 (Sep 05, 2025) =
* Fix: Variation Swatch Module Clear Button Spacing Issue
* Fix: Pre Order Module Code Optimization

= 2.1.1 (Aug 15, 2025) =
* Fix: Missing Cart Table custom data.
* Fix: Conflict with page builder on My Account → Pay Order page.
* Fix: Missing file path for Gift Card and variation swatches.
* Fix: Embedded video issue in variation gallery.

= 2.1.0 ( Aug 06, 2025) =
* New: Added **Variation Swatch** module — users can now disable third-party variation swatch plugins and use this built-in module.
* New: Added **Variation Gallery** module — users can now disable separate variation gallery plugins and rely on this built-in module.
* Fix: Resolved hook error in Cart Page **Cart Table Widget**.
* Fix: Ensured compatibility with **currency switching** for: ( Mini Cart, Partial Payment, Pre-Order, Product Add-Ons, Buy X Get Y | BOGO, Bulk Discount, Gift Card, Flash Sale Countdown, Smart Coupons  )


= 2.0.1 (July 16, 2025) =
* Fix: Resolved a PHP fatal error when activating without ShopBuilder free version.

= 2.0.0 (July 15, 2025) =
* New: Introduced a dynamic asset optimization system for loading module and widget assets only when needed.
* Fix: Corrected tab filter count display in the Ajax Tab Filters widget.
* Fix: Resolved a PHP fatal error in the Partial Payment module.
* Fix: Addressed issue where the Flying Cart disable option didn’t work with the Mini Cart module.
* Fix: Resolved issues with view mode, switcher, search, and sorting in the Shop Ajax Filters.
* Fix: Corrected error handling for Shopify Checkout integration.
* Fix: Rectified the icon styling issue in the Customize My Account module.
* Fix: Addressed the backorder stock error handling bug.
* Fix: Resolved duplicate volume discount message rendering.
* Fix: Corrected an undefined index warning for attribute terms in the Shop Ajax Filter.
* Fix: Addressed Ajax add-to-cart functionality for variable products in the Highlighted Product widget.
* Fix: Resolved email delivery issue in the Gift Card module.
* Update: Improved active filter behavior in the Shop Ajax Filters widget.
* Update: Flash Sale Countdown widget (Layout-1) now supports custom label.
* Optimization: Optimized core, module, and widget CSS/JS for faster load times.
* Optimization: Refactored JS with a unified module pattern to eliminate global namespace pollution.
* Optimization: Implemented LRU caching across multiple components to reduce redundant processing.

= 1.12.1 (May 09, 2025) =
* Fix: Resolved a PHP warning caused by early loading of the text domain.
* Fix: Corrected pricing calculation discrepancies in the Gift Card module.
* Update: Added support for the Block Editor in the Gift Card module.

= 1.12.0 (May 07, 2025) =
* Feature: Introduced the Partial Payments module for partial payment options.
* Feature: Introduced the Gift Cards module for creating, sending and redeeming gift cards.
* Feature: Template Builder now supports creation of the My Account > Order Pay page.
* New: New General Widget - Hero Slider: for building visually stunning homepage banners.
* New: New Product Page Widget - QR Code: for allowing quick access via mobile devices.
* New: Product Attribute & Brand support is included in Ajax Tab Filters.
* New: Ajax Product Filters widget (Shop Page) now supports filtering by Product Brands.
* New: Introduced a new control for mobile filter toggle in Ajax Product Filters widget (Shop Page).
* Add: Implemented Pay Button support on my-account Order Details table widget.
* Fix: Resolved compatibility issues between Flash Sale countdown and other modules.
* Fix: Addressed Ajax add-to-cart undefined issue when WC setting is disabled.
* Fix: Corrected preview rendering in the Pre-Order Email system.
* Fix: Rectified Buy X Get Y module logic for accurate discount rule calculations.
* Fix: Addressed cart messaging and coupon disable logic in Buy-X-Get-Y module.
* Fix: Made Mini Cart Coupon Messages translatable for multilingual sites.
* Fix: Eliminated duplicate CSS ID issue in the Currency Switcher Flags.
* Fix: Resolved the Ajax add to cart error affecting variable products.
* Fix: Addressed PHP warning related to back-order logic.
* Update: Improved Pre-Order Email Templates with support for additional placeholders.

= 1.11.0 (April 10, 2025) =
* Feature: Introduced the Buy-X-Get-Y with BOGO module for dynamic discounting based on product quantity.
* Add: Support for collapsing advanced product tabs on the initial page load.
* Fix: Resolved duplicate Add to Cart button issue when widgets are used multiple times on a details page.
* Fix: Addressed SVG color rendering issue in product add-ons.
* Fix: Standardized Add to Cart button text display for variable products in pre-order scenarios.
* Fix: Adjusted padding for select fields in Product Add-ons.
* Fix: Improved drag-and-drop behavior in the Product Add-on image uploader.
* Fix: Corrected various text domain inconsistencies.

= 1.10.0 (March 12, 2025) =
* Feature: Introduced the Smart Coupons module for advanced coupon management.
* Feature: Introduced the Bulk Discounts module for setting up wholesale pricing.
* Add: Image upload field in the Product Add-Ons module, allowing customers to upload images with their orders.
* Add: A new layout option for the Multi-step Checkout module.
* Add: New General Widget - Coupon List, to display a list of available coupons.
* Fix: Resolved the icon display issue in the Customize My Account module.
* Fix: Addressed the Pre-Order price calculation issue.
* Fix: Rectified the PHP warning related to the Sticky Add to Cart feature.

= 1.9.0 (January 28, 2025) =
* New: Introduced Two (2) new Elementor general widgets:
  - Product LookBook
  - Image Hotspots
* Add: An option to change the button text in the Size Chart module.
* Tweak: Improved and refactored codebase for Elementor general widgets.

= 1.8.3 (January 16, 2025) =
* Add: Eliminated the dependency on the Elementor plugin, enabling modules to function smoothly without it.
* Fix: Resolved the Action button positioning issue in general widgets when product gallery thumbnails are enabled.
* Fix: Addressed compatibility problems with the masonry layout.
* Fix: Corrected the display issue of flash sales on gallery thumbnails in general widgets.
* Fix: Rectified the slider jumping issue with gallery thumbnails.
* Tweak: Introduced a caching mechanism to optimize the retrieval of product gallery images.
* Update: Improved JavaScript performance for the gallery thumbnails slider.

= 1.8.2 (December 27, 2024) =
* Feature: Introduced masonry layout support for the Product Grid/List/Categories widget.
* Add: Integrated masonry layout capability in the archive 'Products - Custom Layouts' widget.
* Add: Introduced custom text control for failed orders in the 'Thank You' page widget.
* Add: Introduced a notice style section for the 'Account Downloads' widget.
* Fix: Resolved Currency Switcher URL issue on subdirectory pages.
* Fix: Corrected CSS inconsistencies on the My Account page.
* Fix: Addressed an issue with the plugin version update notifications.

= 1.8.1 (December 19, 2024) =
* Add: Introduced new margin settings for the Quick Checkout button.
* Fix: Resolved My Account Dashboard template builder issue on subdirectory pages.
* Fix: Ensured compatibility with the latest Elementor version by merging Swiper Slider CSS.
* Fix: Corrected support for Elementor SVG icons across multiple widgets.
* Fix: Resolved a fatal error in the sticky cart bar caused by a missing product object.
* Fix: Corrected styling issues for Pre-order & Backorder badges in Shopify Checkout.
* Fix: Resolved multiple CSS issues in the Sticky Bar.

= 1.8.0 (December 12, 2024) =
* Feature: Introducing the new Shopify Checkout module with multistep support.
* Add: Widget to display custom checkout fields on the thank-you page.
* Add: Support for Elementor SVG Icons across all widgets.
* Fix: Compatibility issue with the Variation Swatches for WooCommerce plugin when importing templates.
* Fix: Resolved Ajax pagination issue on category archive pages.
* Fix: Corrected JSON parsing error in Ajax filter caused by special characters.
* Fix: Addressed conflict between the Flash Sale and Product Add-Ons modules for shared products.
* Fix: Fixed Ajax error related to undefined indexes in Elementor widgets.
* Fix: Rectified mini cart quantity issue for “sold individually” product settings.
* Fix: Ensured Quick View Template Builder content displays correctly in modals.
* Fix: Corrected visibility issues for pre-order and backorder statuses in order posts.
* Fix: Resolved CSS issues with product filters, track filters, quick checkout and product add-ons.
* Fix: Addressed mini cart loading animation glitches.

= 1.7.1 (November 05, 2024) =
* Fix: Corrected EU flag display issue in the currency switcher.
* Fix: Resolved visibility issue with the success icon for add-on products on the shop page.
* Fix: Addressed Elementor Panel Loading Issue.
* Fix: Resolved product sorting issue in general widgets.
* Fix: Rectified toggle issue with badge percentage display.

= 1.7.0 (October 21, 2024) =
* Feature: Introducing the 'Checkout Fields Editor' module for adding, editing and sorting checkout fields.
* Feature: Introducing the 'Sticky Add-To-Cart' module to keep the “Add to Cart” button visible during scrolling.
* Add: Support for variable products within the 'Quick Checkout' module.
* Fix: Resolved input number float type support in Product Add-Ons.
* Fix: Addressed an issue with Multistep Checkout compatibility in the Astra theme.
* Fix: Corrected shipping style and URL issues in Multistep Checkout.
* Fix: Rectified the display issue for pre-order prices.
* Fix: Resolved issues related to pre-order variation products.
* Fix: Corrected the pre-order cart limit issue.
* Fix: Resolved maximum quantity issues in the Mini-Cart for pre-orders.
* Fix: Addressed maximum quantity restrictions for pre-orders in the cart.
* Fix: Resolved a PHP warning in the Product Add-Ons processor.
* Fix: Corrected issue with shipping fields always remaining open in Quick Checkout.
* Fix: Addressed shipping fields visibility issue in Multistep Checkout.

= 1.6.0 (September 24, 2024) =
* Feature: Introducing the 'Product Add-Ons' Module for creating extra product add-ons.
* Add: Support for variable products within the 'Flash Sale Countdown' module.
* Fix: Corrected an issue with JSON string handling in 'Customize My Account' module.
* Fix: Resolved a JS issue preventing proper add-to-cart functionality for variable products.
* Fix: Addressed a PHP notice appearing in the Currency Switcher module.
* Fix: Rectified an issue where the mini-cart did not respect product stock status.

= 1.5.1 (August 12, 2024) =
* Feature: Introducing the ability to create product page templates based on categories and tags.
* Fix: Resolved an issue causing extra markup in the cart table widget.
* Fix: Addressed visibility issues with the flash sale countdown layout in the general widget.
* Fix: Corrected a JSON parsing error in the Ajax filter, which was triggered by special characters.
* Fix: Rectified a JS issue affecting the Ajax add-to-cart functionality on the product details page.
* Fix: Resolved an issue with the Ajax filter not hiding out-of-stock products as per WC settings.
* Fix: Addressed a query issue in the Ajax filter showing draft and private products.
* Fix: Corrected a JS issue on the product admin post-type page.
* Optimization: Reduced the size of the frontend JS file by separating the Ajax filter scripts.

= 1.5.0 (July 10, 2024) =
* Feature: Introducing the 'Pre-Order' Module for managing pre-order products.
* Feature: Introducing the 'Currency Switcher' Module for displaying different currencies.
* Feature: Introducing the condition-based tabs (e.g., featured, best-selling, etc.) in the Ajax Tab Filters.
* Add: New special product grid layout.
* Add: New category grid layout.
* Add: Enhanced compatibility with new modules and features.
* Add: Clear cache button support and compatibility for all connected caches.
* Add: Additional style settings for the 'Back Order' module.
* Add: 'Back Order' badge for back-order products.
* Fix: Resolved a JS error in Ajax Tab Filters when no selected items are found.
* Fix: Addressed a pagination markup issue in Ajax Load More functionality.
* Fix: Corrected discrepancies with Elementor class selectors.
* Fix: Rectified countdown error for products without activated flash sales.
* Fix: Resolved issues with 'My Account' template when the endpoint is a custom link.
* Fix: Addressed issues with the shop's Facebook share link glitch.
* Performance: Updated and optimized caching mechanism for Ajax Tab Filters.
* Performance: Implemented an advanced caching mechanism in the template builder.

= 1.4.3 (June 25, 2024) =
* Fix: Resolved an error that prevented guest users from completing the PayPal checkout process.

= 1.4.2 (June 11, 2024) =
* Fix: Corrected a PHP fatal error that occurred when activating without WooCommerce.

= 1.4.1 (June 10, 2024) =
* Add: A new layout option for the flash sale countdown widget on single pages.
* Add: Controls for variation stock text style in the Highlighted Product widget.
* Fix: Resolved compatibility issues with the Flash Sale Countdown module.
* Fix: Corrected a PHP fatal error that occurred when activating without WooCommerce.
* Fix: Resolved issues related to the login and register widgets not being found.

= 1.4.0 (May 20, 2024) =
* Feature: Introducing the 'Customize My Account' Module for managing my account endpoints.
* Feature: Builder now supports custom endpoint templates, providing users with greater flexibility.
* Fix: Resolved the issue with special characters not displayed properly in attributes.
* Fix: Addressed various text-domain issues.
* Fix: Corrected the authentication check issue in the 'My Account' section.
* Fix: Resolved PHP warnings regarding undefined indexes.
* Fix: Addressed various CSS issues.
* Tweak: Implemented sortable support for settings Repeater fields.
* Update: Enhanced flush rewrite functionality for improved performance.
* Update: Improved UI for the Settings Repeater field.
* Update: Updated dependency libraries for enhanced stability and security.

= 1.3.3 (April 22, 2024) =
* Add: Compatibility with the WPML plugin.
* Fix: Resolved an issue with Ajax filters for child categories.
* Fix: Addressed a responsive issue with Ajax tab filters to ensure optimal display.
* Fix: Corrected an issue with Ajax filters for on-sale products, for accurate filtering.
* Fix: Resolved various text-domain issues.
* Fix: Addressed Ajax filters product count inconsistency in attribute archives.
* Optimization: Optimized Ajax filters products query for faster loading times and improved performance.
* Performance: Updated and optimized Ajax filters caching mechanism for enhanced efficiency.

= 1.3.2 (April 07, 2024) =
* Add: Apply Filters section translation support.
* Fix: Addressed Mini Cart multilingual Display issue.
* Fix: Resolved Ajax tab filter multilingual issue.
* Fix: Corrected pagination issues on the template pages.
* Fix: Rectified Apply Filters multiple clear button issue.
* Update: Ajax pagination with visible range support.

= 1.3.1 (April 01, 2024) =
* Fix: Addressed issues related to product stock count functionality.
* Fix: Resolved discrepancies with Elementor class selectors.
* Fix: Corrected style problems affecting the display of stock counts.

= 1.3.0 (March 29, 2024) =
* Feature: Introducing the Back Order Module for managing out-of-stock items.
* Feature: Quick View Builder for enhanced product browsing.
* Feature: Product Stock Counter widget to display stock progress bar.
* Feature: Highlighted Product widget to spotlight featured item.
* Feature: Ajax add-to-cart support on product pages.
* Add: Stock counter support in general widgets.
* Add: Some new widget controls.
* Fix: Resolved mini-cart Ajax update issue with PayPal.
* Fix: Addressed styling issue with size chart button.
* Fix: Corrected quick checkout coupon form problem.
* Fix: Addressed various CSS issues.

= 1.2.2 (March 06, 2024) =
* Add: Feature to hide usernames in Sales Notifications.
* Fix: Issue with multi-word Ajax search filters.
* Fix: Billing and shipping address display issue.
* Fix: Resolved licensing problem.
* Fix: Addressed template issues with Ajax filters.
* Update: My Account address templates.

= 1.2.1 (February 28, 2024) =
* Add: Implemented automatic cart update via Ajax when quantity changes.
* Add: Included product gallery slider arrows visibility control.
* Add: Enabled SKU search functionality in shop Ajax filters.
* Add: Introduced new settings for my-account widgets.
* Fix: Addressed some translation issues.
* Fix: Resolved some Elementor class selector discrepancies.
* Fix: Corrected numerous style issues.
* Fix: Addressed guest user issue on the checkout page.
* Fix: Resolved datetime format issue in my-account order notes.
* Fix: Addressed compatibility issues with the WooCommerce notice system.
* Fix: Rectified pagination issue in shop page Ajax search filter.
* Fix: Addressed navigation issue in product gallery slider.
* Fix: Resolved caching issues to optimize performance.

= 1.2.0 (February 15, 2024) =
* New: Product Badge Module integration.
* Add: Product slider arrows visibility control.
* Add: Flash sale countdown compatibility for variable products.
* Fix: Resolved Ajax tab filter issue.
* Fix: Corrected Ajax pagination issue.
* Fix: Addressed some CSS issues.
* Fix: Resolved some caching issues.
* Fix: Product query issue.
* Fix: Resolved Template Builder API issue in offline mode.
* Update: Product page Badge widget.
* Update: Enhanced theme compatibility with Badge module.
* Tweak: General widgets Badge controls.
* Tweak: Improved flash sale compatibility with Badge module.

= 1.1.3 (February 06, 2024) =
* Add: Product Categories slider feature.
* Add: Product Categories custom image feature.
* Add: Settings to restrict some features for guest users.
* Fix: Resolved Checkout page 500 error issue.
* Fix: Addressed Cart page shipping calculation issue.
* Fix: Corrected Sales notification name issue.
* Fix: Resolved various text-domain issues.
* Update: Enhanced Elementor render system and conducted code cleanups.
* Optimization: Improved Ajax filter queries for enhanced performance.
* Optimization: Reduced the size of the frontend JS file for improved loading times.

= 1.1.2 (January 26, 2024) =
* Add: My account Separate Login Form widget.
* Add: My account Separate Registration Form widget.
* Add: Product Slider slide zoom-in effect.
* Add: One (1) new product grid layout.
* Add: One (1) new product list layout.
* Add: One (1) new product slider layout.
* Fix: PHP class not found issue.
* Fix: Cart page coupon issue.
* Fix: Cart table style issues.
* Fix: Come CSS fixes.

= 1.1.1 (January 19, 2024) =
* Add: Multi-Step checkout widget for checkout page.
* Add: Custom element ordering in general widgets.
* Fix: Translation issues.
* Fix: My Account page login issue.
* Fix: Authentication issue for non-logged in users.
* Fix: Settings Repeater issue.
* Fix: Compatibility with WoodMart theme.
* Tweak: Elementor rendering optimization.

= 1.1.0 (January 05, 2024) =
* Add: Two (2) new product grid layouts.
* Add: One (1) new product list layout.
* Add: Three (3) new product slider layouts.
* Add: One (1) new single category layouts.
* Add: One (1) new product categories layout.
* Add: Recently viewed products display.
* Add: Advanced product tabs widget with custom tab support.
* Fix: Ajax category tab filter data.
* Fix: Ajax number pagination list issue.
* Fix: Incorrect products issue with On-Sale filter.
* Fix: Product Ajax tab filter issues.
* Fix: Some CSS issues.
* Tweak: Update product queries for performance enhancement.
* Performance: Update and optimize database queries.
* Performance: Remove lots of duplicate database queries.
* Performance: Implement advanced caching mechanism.

= 1.0.3 (December 01, 2023) =
* Add: Archive product Ajax search filter.
* Add: Two (2) new product grid layouts.
* Add: Two (2) new product list layouts.
* Add: Three (3) new product slider layouts.
* Add: Product rating presets & settings.
* Add: Product slider multi-row settings.
* Add: Product Ajax tab filter track buttons.
* Fix: Ajax view mode issue.
* Fix: Quick checkout widget selector issue.
* Fix: My account navigation icon color issue.
* Fix: Product sorting ajax issue.

= 1.0.2 (November 17, 2023) =
* Add: Archive product view mode Ajax feature.
* Add: Archive product sorting Ajax feature.
* Fix: Ajax Load More button issue.

= 1.0.1 (November 13, 2023) =
* Add: RTL Support.
* Fix: Some Style issues.
* Fix: HPOS Support in Elementor Editor Page.
* Fix: Multi-Step Shipping Form Issue.

= 1.0.0 (November 03, 2023) =
* Stable version release


