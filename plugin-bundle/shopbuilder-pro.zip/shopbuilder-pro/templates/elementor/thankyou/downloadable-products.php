<?php
/**
 * Template variables:
 *
 * @var $controllers        array settings as array
 * @var $is_builder_mode    bool Editor Mode status
 * @var $show_downloads     bool has downloadable products
 * @var $downloads          array all downloadable products
 * @var $show_title         bool show or hide section title
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}


if ( $show_downloads ) {
	?>
	<div class="rtsb-order-thankyou">
		<?php
		wc_get_template(
			'order/order-downloads.php',
			[
				'downloads'  => $downloads,
				'show_title' => $show_title,
			]
		);
		?>
	</div>
	<?php
}

