<?php
/**
 * Template variables:
 *
 * @var $controllers  array settings as array
 * @var $content  string
 */

global $product;

if ( empty( $product ) ) {
	return;
}

?>

<div class="rtsb-product-flash-sale-countdown">
	<?php do_action( 'rtsb/modules/flash_sale_countdown/frontend/display' ); ?>
</div>
