<?php
/**
 * Template variables:
 *
 * @var $controllers  array settings as array
 * @var $content  string
 */

global $product;

if ( empty( $product ) ) {
	return;
}

?>

<div class="rtsb-product-quick-checkout">
	<?php do_action( 'rtsb/modules/quick_checkout/frontend/display' ); ?>
</div>
