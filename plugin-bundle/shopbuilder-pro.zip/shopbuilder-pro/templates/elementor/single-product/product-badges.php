<?php
/**
 * Template variables:
 *
 * @var $controllers  array settings as array
 * @var $content  string
 */

global $product;

if ( empty( $product ) ) {
	return;
}

?>

<div class="rtsb-product-badges-widgets">
	<?php do_action( 'rtsb/modules/product_badges/frontend/display' ); ?>
</div>
