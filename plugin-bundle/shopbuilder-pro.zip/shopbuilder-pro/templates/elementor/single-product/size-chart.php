<?php
/**
 * Template variables:
 *
 * @var $controllers  array settings as array
 * @var $content  string
 */

global $product;

if ( empty( $product ) ) {
	return;
}

?>

<div class="rtsb-product-size-chart">
	<?php do_action( 'rtsb/modules/product_size_chart/frontend/display' ); ?>
</div>
