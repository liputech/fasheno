<?php
/**
 * Template variables:
 *
 * @var $controllers  array settings as array
 * @var $content  string
 */

global $product;

if ( empty( $product ) ) {
	return;
}

?>

<div class="rtsb-product-stock-count-wrapper">
	<?php echo do_shortcode( '[product_stock_count]' ); ?>
</div>
