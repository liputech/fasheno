<?php
/**
 * Template: Advanced Ajax Search.
 *
 * @package RadiusTheme\SB
 */

/**
 * Template variables:
 *
 * @var $taxonomy_search_type               string
 * @var $all_cat_text                       string
 * @var $all_tag_text                       string
 * @var $all_brand_text                     string
 * @var $search_btn_text                    string
 * @var $custom_order                       string
 * @var $category_separator_position        string
 * @var $has_search_btn_text                bool
 * @var $search_icon                        array
 * @var $raw_settings                       array
 * @var $settings                           array
 */

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Helpers\FnsPro;


switch ( $taxonomy_search_type ) {
	case 'tag':
		$taxonomy_name = 'product_tag';
		$default_label = $all_tag_text ? $all_tag_text : esc_html__( 'All Tags', 'shopbuilder-pro' );
		$selected_term = sanitize_text_field( wp_unslash( $_GET['product_tag'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		break;

	case 'brand':
		$taxonomy_name = 'product_brand';
		$default_label = $all_brand_text ? $all_brand_text : esc_html__( 'All Brands', 'shopbuilder-pro' );
		$selected_term = sanitize_text_field( wp_unslash( $_GET['product_brand'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		break;

	default:
		$taxonomy_name = 'product_cat';
		$default_label = $all_cat_text ? $all_cat_text : esc_html__( 'All Categories', 'shopbuilder-pro' );
		$selected_term = sanitize_text_field( wp_unslash( $_GET['product_cat'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		break;
}

$trm_list = FnsPro::get_taxonomy_list( $taxonomy_name, 'term_id' );

?>
<div class="rtsb-advanced-product-search" style="<?php echo esc_attr( $custom_order ); ?>" data-settings="<?php echo esc_attr( wp_json_encode( $settings ) ); ?>">
	<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="rtsbSearchForm">
		<input type="hidden" name="post_type" value="product" />
		<div class="rtsb-search-input-group">
			<div class="rtsb-category-select-wrapper <?php echo esc_attr( $category_separator_position ); ?>">
				<select class="rtsb-search-select" name="<?php echo esc_attr( $taxonomy_name ); ?>">
					<option value=""><?php echo esc_html( $default_label ); ?></option>
					<?php
					if ( ! empty( $trm_list ) && is_array( $trm_list ) ) {
						foreach ( $trm_list as $_term_key => $_term ) {
							$term_object = get_term( $_term_key );
							$term_slug   = is_wp_error( $term_object ) ? '' : ( $term_object->slug ? $term_object->slug : '' );

							echo '<option value="' . esc_attr( $term_slug ) . '" data-value="' . esc_attr( $_term_key ) . '" ' . selected( ( $selected_term === $term_slug ), true, false ) . '>' . esc_html( $_term ) . '</option>';
						}
					}
					?>
				</select>
			</div>
			<div class="rtsb-search-input-wrapper">
				<input
						type="search"
						class="rtsb-search-input"
						name="s"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search products...', 'shopbuilder-pro' ); ?>"
						autocomplete="off"
						aria-label="<?php esc_attr_e( 'Search products', 'shopbuilder-pro' ); ?>"
				>
				<div class="rtsb-search-suggestion-overlay" data-thinking="<?php esc_html_e( 'AI is thinking...', 'shopbuilder-pro' ); ?>"></div>
			</div>
			<button type="submit" class="rtsb-search-button">
				<?php if ( ! empty( $search_icon ) ) { ?>
					 <span class="rtsb-search-icon"><?php Fns::print_html( Fns::icons_manager( $search_icon ) ); ?></span>
				<?php } ?>
				<?php if ( $has_search_btn_text ) { ?>
					<span class="rtsb-search-text"><?php Fns::print_html( $search_btn_text ); ?></span>
				<?php } ?>
			</button>

		</div>
	</form>
	<div class="rtsb-advanced-ajax-search-results" style="display: none;">
		<div class="rtsb-advanced-ajax-search-loading" style="display: none;">
			<span class="rtsb-advanced-ajax-search-spinner"></span>
		</div>
		<div class="rtsb-advanced-ajax-search-products-list"></div>
	</div>
</div>

