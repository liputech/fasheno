<?php
/**
 * Template variables:
 *
 * @var $show_category bool
 * @var $show_brand bool
 * @var $show_thumbnail bool
 * @var $show_add_to_cart bool
 * @var $show_quantity_field bool
 * @var $show_rating bool
 * @var $product object
 */

use RadiusTheme\SB\Helpers\Fns;

defined( 'ABSPATH' ) || exit;
$product_id    = $product->get_id();
$product_name  = $product->get_name();
$product_url   = $product->get_permalink();
$product_price = $product->get_price_html();
$product_image = $product->get_image( 'thumbnail' );
$stock_status  = $product->get_stock_status();
$product_type  = $product->get_type();

$categories    = wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'names' ] );
$brands        = wp_get_post_terms( $product_id, 'product_brand', [ 'fields' => 'names' ] );
$category_name = ! empty( $categories ) ? $categories[0] : '';
$brand_name    = ! empty( $brands ) ? $brands[0] : '';

?>
<div class="rtsb-product-item">
		<?php if ( $show_thumbnail && $product_image ) : ?>
			<div class="rtsb-product-image">
				<?php Fns::print_html( $product_image ); ?>
			</div>
		<?php endif; ?>

		<div class="rtsb-product-details">
			<?php if ( $show_category && $category_name ) : ?>
				<div class="rtsb-product-category"><?php echo esc_html( $category_name ); ?></div>
			<?php endif; ?>
			<?php if ( $show_brand && $brand_name ) : ?>
				<div class="rtsb-product-brand"><?php echo esc_html( $brand_name ); ?></div>
			<?php endif; ?>
			<a href="<?php echo esc_url( $product_url ); ?>" class="rtsb-product-name">
				<?php Fns::print_html( $product_name ); ?>
			</a>
			<?php
			if ( $show_rating ) :
				Fns::print_html( Fns::get_product_rating_html() );
				endif;
			?>
			<div class="rtsb-product-price">
				<?php Fns::print_html( $product_price ); ?>
			</div>
			<?php if ( $show_add_to_cart || $show_quantity_field ) : ?>
				<div class="rtsb-product-actions">
				<?php if ( 'outofstock' === $stock_status ) : ?>
					<span class="rtsb-out-of-stock"><?php esc_html_e( 'Out of stock', 'shopbuilder-pro' ); ?></span>
				<?php else : ?>
					<?php if ( $show_add_to_cart ) : ?>
						<?php if ( $show_quantity_field && $product->is_type( 'simple' ) ) : ?>
							<input type="number"
								   class="rtsb-quantity-input"
								   value="1"
								   min="1"
								   name="rtsb-product-quantity"
								   data-product-id="<?php echo esc_attr( $product_id ); ?>">
						<?php endif; ?>
						<?php
						if ( $product->is_type( 'variable' ) ) :
							?>
							<a href="<?php echo esc_url( $product->get_permalink() ); ?>"
							   class="rtsb-ajax-search-select-options">
								<?php esc_html_e( 'Select options', 'shopbuilder-pro' ); ?>
							</a>
						<?php elseif ( $product->is_type( 'simple' ) ) : ?>
							<button class="rtsb-ajax-search-add-to-cart"
									data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
								<?php esc_html_e( 'Add to Cart', 'shopbuilder-pro' ); ?>
							</button>
						<?php else : ?>
							<a href="<?php echo esc_url( $product->get_permalink() ); ?>"
							   class="rtsb-ajax-search-view-product">
								<?php esc_html_e( 'View Product', 'shopbuilder-pro' ); ?>
							</a>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
	</div>


