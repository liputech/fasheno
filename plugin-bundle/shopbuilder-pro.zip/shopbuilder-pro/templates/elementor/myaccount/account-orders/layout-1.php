<?php
/**
 * Template variables:
 *
 * @var $controllers        array settings as array
 * @var $current_page    bool Editor Mode status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wrapper_classes = ! empty( $controllers['table_horizontal_scroll_on_mobile'] ) ? ' rtsb-table-horizontal-scroll-on-mobile' : '';
?>
<section class="rtsb-myacount-page<?php echo esc_attr( $wrapper_classes ); ?>">
	<?php
	do_action( 'woocommerce_account_orders_endpoint', $current_page );
	?>
</section>
