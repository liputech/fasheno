<?php
/**
 * Template variables:
 *
 * @var $controllers        array settings as array
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<section class="rtsb-myacount-page address-description">
	<?php
	if ( $controllers['description_text'] ) {
		?>
		<p><?php echo esc_html( $controllers['description_text'] ); ?></p>
		<?php
	} else {
		?>
	<p>
		<?php echo apply_filters( 'woocommerce_my_account_my_address_description', esc_html__( 'The following addresses will be used on the checkout page by default.', 'shopbuilder-pro' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</p>
	<?php } ?>
</section>
