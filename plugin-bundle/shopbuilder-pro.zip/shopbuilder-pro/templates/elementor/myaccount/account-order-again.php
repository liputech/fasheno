<?php
/**
 * Template variables:
 *
 * @var $controllers        array settings as array
 * @var $order        array settings as array
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! $order ) {
	return;
}

$order_completed = $order->has_status( apply_filters( 'woocommerce_valid_order_statuses_for_order_again', [ 'completed' ] ) );
?>
<section class="rtsb-myacount-page">
	<?php
	if ( true === $order_completed && is_user_logged_in() ) {
		do_action( 'woocommerce_order_details_after_order_table', $order );
	}
	?>
</section>
