<?php
/**
 * Template variables:
 *
 * @var $controllers       array settings as array
 * @var $avatar_url        string Avatar URL
 * @var $avatar_size       string Avatar size
 * @var $avatar_alt        string Avatar image alt
 * @var $user_name         string Avatar user name
 * @var $user_email        string Avatar email
 * @var $hover_class       string hover class
 * @var $content_position  string hover class
 * @var $user_id           integer Avatar user id
 */

use RadiusTheme\SB\Helpers\Fns;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="rtsb-account-custom-avatar">
	<div class="rtsb-avatar-wrapper <?php echo esc_attr( $content_position ); ?>">
		<div class="rtsb-avatar-thumb <?php echo esc_attr( $hover_class ); ?>">
			<div class="rtsb-avatar-preview">
				<?php if ( $avatar_url ) { ?>
					<img src="<?php echo esc_url( $avatar_url ); ?>"
						 alt="<?php echo esc_attr( $avatar_alt ); ?>"
						 id="rtsb-custom-avatar" />
				<?php } else { ?>
					<div id="rtsb-default-avatar">
						<?php echo get_avatar( $user_id, $avatar_size, '', $avatar_alt ); ?>
					</div>
				<?php } ?>
			</div>
			<?php if ( ! empty( $controllers['upload_icon']['value'] ) ) { ?>
				<label for="rtsb_custom_avatar_file" class="upload-icon-overlay">
					<?php
					Fns::print_html( Fns::icons_manager( $controllers['upload_icon'] ) );
					?>
				</label>
			<?php } ?>
			<?php if ( $avatar_url && ! empty( $controllers['remove_icon']['value'] ) ) { ?>
				<div class="remove-icon-overlay" id="remove-avatar-btn" title="<?php esc_attr_e( 'Remove avatar', 'shopbuilder-pro' ); ?>">
					<?php
					Fns::print_html( Fns::icons_manager( $controllers['remove_icon'] ) );
					?>
				</div>
			<?php } ?>
		</div>
		<div class="rtsb-avatar-content">
			<div class="rtsb-user-info">
				<div class="user-name"><?php Fns::print_html( $user_name ); ?></div>
				<div class="user-email"><?php Fns::print_html( $user_email ); ?></div>
			</div>
			<form class="rtsb-account-avatar-upload-form" enctype="multipart/form-data">
				<input type="file" id="rtsb_custom_avatar_file" name="rtsb_custom_avatar_file" accept="image/jpeg,image/png" />
				<span class="selected-file-name"></span>
				<div class="rtsb-avatar-upload-message"></div>
			</form>
		</div>
	</div>
</div>
