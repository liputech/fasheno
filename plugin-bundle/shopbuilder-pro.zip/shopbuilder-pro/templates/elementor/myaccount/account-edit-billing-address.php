<?php
/**
 * Template variables:
 *
 * @var $controllers        array settings as array
 * @var $is_builder_mode    bool Editor Mode status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$wrapper_class = ! empty( $controllers['fields_width_100'] ) ? 'rtsb-form-fields-width-100' : '';
?>
<section class="rtsb-myacount-page edit-address <?php echo esc_attr( $wrapper_class ); ?>">
	<?php
	WC_Shortcode_My_Account::edit_address( 'billing' );
	?>
</section>

