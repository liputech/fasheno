<?php
/**
 * Preview Template
 *
 * @var $show_title         bool show or hide section title
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<section class="rtsb-myacount-page rtsb-order-thankyou preview-demo-markup">
	<section class="woocommerce-order-downloads">
		<?php
		if ( $show_title ) {
			?>
			<h2 class="woocommerce-order-downloads__title"><?php esc_html_e( 'Downloads', 'shopbuilder-pro' ); ?></h2>
		<?php } ?>
		<table class="woocommerce-table woocommerce-table--order-downloads shop_table shop_table_responsive order_details">
			<thead>
			<tr>
				<th class="download-product"><span class="nobr"><?php esc_html_e( 'Product', 'shopbuilder-pro' ); ?></span></th>
				<th class="download-remaining"><span class="nobr"> <?php esc_html_e( 'Downloads remaining', 'shopbuilder-pro' ); ?></span></th>
				<th class="download-expires"><span class="nobr"><?php esc_html_e( 'Expires', 'shopbuilder-pro' ); ?></span></th>
				<th class="download-file"><span class="nobr"> <?php esc_html_e( 'Download', 'shopbuilder-pro' ); ?></span></th>
			</tr>
			</thead>

			<tbody><tr>
				<td class="download-product" data-title="Product">
					<a href="http://shop-builder.test/product/shopbuilder-plugin/"> <?php esc_html_e( 'ShopBuilder Plugin', 'shopbuilder-pro' ); ?></a>					</td>
				<td class="download-remaining" data-title="Downloads remaining">
					∞					</td>
				<td class="download-expires" data-title="Expires">
						<?php esc_html_e( 'Never', 'shopbuilder-pro' ); ?>				</td>
				<td class="download-file" data-title="Download">
					<a href="#" class="woocommerce-MyAccount-downloads-file button alt"> <?php esc_html_e( 'shopbuilder plugin', 'shopbuilder-pro' ); ?></a>					</td>
			</tr>
			<tr>
				<td class="download-product" data-title="Product">
					<a href="http://shop-builder.test/product/shopbuilder-pro-plugin/"> <?php esc_html_e( 'Theme', 'shopbuilder-pro' ); ?></a>					</td>
				<td class="download-remaining" data-title="Downloads remaining">
					10					</td>
				<td class="download-expires" data-title="Expires">
							<?php esc_html_e( 'Never', 'shopbuilder-pro' ); ?>			</td>
				<td class="download-file" data-title="Download">
					<a href="#" class="woocommerce-MyAccount-downloads-file button alt"> <?php esc_html_e( 'Consalty Theme', 'shopbuilder-pro' ); ?></a>					</td>
			</tr>
			</tbody></table>
	</section>
</section>
