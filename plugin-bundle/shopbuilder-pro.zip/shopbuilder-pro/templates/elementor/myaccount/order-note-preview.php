<?php
/**
 * Preview Template
 *
 * @var $show_title         bool show or hide section title
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<section class="rtsb-myacount-page preview-note-demo-markup">
	<?php
	if ( $show_title ) {
		?>
		<h2><?php esc_html_e( 'Order updates', 'shopbuilder-pro' ); ?></h2>
	<?php } ?>
	<ol class="woocommerce-OrderUpdates commentlist notes">
		<li class="woocommerce-OrderUpdate comment note">
			<div class="woocommerce-OrderUpdate-inner comment_container">
				<div class="woocommerce-OrderUpdate-text comment-text">
					<p class="woocommerce-OrderUpdate-meta meta">
						<?php
						$order_note_date = date_i18n( esc_html__( 'l jS \o\f F Y, h:ia', 'shopbuilder-pro' ), strtotime( time() ) );
						echo apply_filters( 'rtsb/order/note/data/time', $order_note_date, time() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</p>
					<div class="woocommerce-OrderUpdate-description description">
						<p><?php esc_html_e( 'Order note demo content', 'shopbuilder-pro' ); ?></p>
					</div>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
		</li>
		<li class="woocommerce-OrderUpdate comment note">
			<div class="woocommerce-OrderUpdate-inner comment_container">
				<div class="woocommerce-OrderUpdate-text comment-text">
					<p class="woocommerce-OrderUpdate-meta meta">
						<?php
						$order_note_date = date_i18n( esc_html__( 'l jS \o\f F Y, h:ia', 'shopbuilder-pro' ), strtotime( time() ) );
						echo apply_filters( 'rtsb/order/note/data/time', $order_note_date, time() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</p>
					<div class="woocommerce-OrderUpdate-description description">
						<p><?php esc_html_e( 'Order note demo content', 'shopbuilder-pro' ); ?></p>
					</div>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
		</li>
	</ol>
</section>

