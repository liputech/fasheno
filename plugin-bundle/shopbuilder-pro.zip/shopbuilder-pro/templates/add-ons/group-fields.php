<?php
/**
 * Template: Product Add-Ons Group Fields.
 *
 * @package RadiusTheme\SBPRO
 */

/**
 * Template variables:
 *
 * @var $name                string
 * @var $description         string
 * @var $show_name           string
 * @var $show_desc           string
 */

use RadiusTheme\SB\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

$show_name = ! empty( $show_name ) ? $show_name : 'no';
$show_desc = ! empty( $show_desc ) ? $show_desc : 'no';

if ( 'on' !== $show_name || 'on' !== $show_desc ) {
	return;
}
?>


