<?php
/**
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\ExtendedCrossSell;

use RadiusTheme\SB\Helpers\Fns;
use WC_Order;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class CrossSellFns {
	/**
	 * @param string       $key Default Attribute.
	 * @param array|string $default Default Attribute.
	 * @return array|string
	 */
	public static function get_options( $key = null, $default = '' ) {
		$options = Fns::get_options( 'modules', 'extended_cross_sell' );
		if ( $key ) {
			if ( isset( $options[ $key ] ) ) {
				return $options[ $key ];
			} else {
				return $default;
			}
		}
		return $options;
	}
	/**
	 * Returns the settings fields for the ShopBuilder Pro popup.
	 *
	 * Defines configuration for popup title, delay, layout, product display,
	 * and styling options.
	 *
	 * @since 1.0.0
	 *
	 * @return array Settings fields configuration.
	 */
	public static function settings_field() {
		$fields = [
			'popup_title'            => [
				'id'    => 'popup_title',
				'label' => __( 'Product Lists Popup Title', 'shopbuilder-pro' ),
				'type'  => 'text',
				'value' => esc_html__( 'You may also like', 'shopbuilder-pro' ),
				'help'  => esc_html__( 'Enter the cross-sell products popup title.', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'product_source'         => [
				'id'      => 'product_source',
				'type'    => 'select',
				'value'   => 'cross_sell',
				'tab'     => 'general',
				'label'   => esc_html__( 'Product Source', 'shopbuilder-pro' ),
				'options' => [
					'cross_sell'      => esc_html__( 'Cross Sell', 'shopbuilder-pro' ),
					'up_sell'         => esc_html__( 'Upsells', 'shopbuilder-pro' ),
					'related'         => esc_html__( 'Related Products', 'shopbuilder-pro' ),
					'categories'      => esc_html__( 'Product Categories', 'shopbuilder-pro' ),
					'custom_products' => esc_html__( 'Custom Products', 'shopbuilder-pro' ),
				],
				'help'    => esc_html__( 'Specify which products to display. Cross-sells, up-sells, and related products, product categories, and custom products are available for display.', 'shopbuilder-pro' ),
			],
			'applicable_products'    => [
				'id'              => 'applicable_products',
				'type'            => 'search_and_multi_select',
				'label'           => esc_html__( 'Applicable Products', 'shopbuilder-pro' ),
				'help'            => esc_html__( 'Choose specific products to display in the popup.', 'shopbuilder-pro' ),
				'placeholder'     => esc_html__( 'Search Products', 'shopbuilder-pro' ),
				'func_with_param' => [ Fns::class, 'get_post_types', [ 'post_type' => 'product' ] ],
				'options'         => Fns::get_post_types( null, [ 'post_type' => 'product' ] ),
				'dependency'      => [
					'rules' => [
						[
							'item'     => 'modules.extended_cross_sell.product_source',
							'value'    => 'custom_products',
							'operator' => '==',
						],
					],
				],
				'tab'             => 'general',
			],
			'applicable_categories'  => [
				'id'              => 'applicable_categories',
				'type'            => 'search_and_multi_select',
				'label'           => esc_html__( 'Applicable Categories', 'shopbuilder-pro' ),
				'help'            => esc_html__( 'Choose specific categories to display in the popup.', 'shopbuilder-pro' ),
				'placeholder'     => esc_html__( 'Search Category', 'shopbuilder-pro' ),
				'func_with_param' => [
					Fns::class,
					'products_category_query',
				],
				'options'         => Fns::products_category_query(),
				'dependency'      => [
					'rules' => [
						[
							'item'     => 'modules.extended_cross_sell.product_source',
							'value'    => 'categories',
							'operator' => '==',
						],
					],
				],
				'tab'             => 'general',
			],
			'popup_delay'            => [
				'id'    => 'popup_delay',
				'type'  => 'number',
				'value' => 500,
				'size'  => 'small',
				'min'   => 100,
				'label' => esc_html__( 'Popup Delay (milliseconds)', 'shopbuilder-pro' ),
				'help'  => esc_html__( 'Enter the popup delay in milliseconds.', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'template_layout'        => [
				'id'      => 'template_layout',
				'label'   => esc_html__( 'Template Layout', 'shopbuilder-pro' ),
				'help'    => esc_html__( 'Select the Popup Layout.', 'shopbuilder-pro' ),
				'type'    => 'image_select',
				'value'   => 'layout1',
				'tab'     => 'general',
				'options' => [
					'layout1' => [
						'label' => esc_html__( 'Layout 1', 'shopbuilder-pro' ),
						'url'   => esc_url( rtsbpro()->get_assets_uri( 'images/extended-cross-sell/grid.png' ) ),
					],
					'layout2' => [
						'label' => esc_html__( 'Layout 2', 'shopbuilder-pro' ),
						'url'   => esc_url( rtsbpro()->get_assets_uri( 'images/extended-cross-sell/list.png' ) ),
					],
				],
			],
			'products_limit'         => [
				'id'    => 'products_limit',
				'type'  => 'slider',
				'label' => esc_html__( 'Product Limit', 'shopbuilder-pro' ),
				'help'  => esc_html__( 'Set maximum number of products to display.', 'shopbuilder-pro' ),
				'min'   => 1,
				'max'   => 100,
				'unit'  => '',
				'value' => 4,
				'tab'   => 'general',
			],
			'btn_bg'                 => [
				'id'    => 'btn_bg',
				'type'  => 'color',
				'label' => esc_html__( 'Button Background', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
			'btn_color'              => [
				'id'    => 'btn_color',
				'type'  => 'color',
				'label' => esc_html__( 'Button Color', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
			'btn_border_color'       => [
				'id'    => 'btn_border_color',
				'type'  => 'color',
				'label' => esc_html__( 'Border Color', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
			'btn_border_hover_color' => [
				'id'    => 'btn_border_hover_color',
				'type'  => 'color',
				'label' => esc_html__( 'Border Hover Color', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
			'btn_bg_hover'           => [
				'id'    => 'btn_bg_hover',
				'type'  => 'color',
				'label' => esc_html__( 'Button Hover Background', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
			'btn_hover_color'        => [
				'id'    => 'btn_hover_color',
				'type'  => 'color',
				'label' => esc_html__( 'Button Hover Color', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
		];
		return $fields;
	}
}
