<?php
/**
 * Extended Cross-sell Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\ExtendedCrossSell;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Helpers\AdminInputsFns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();
/**
 * Main CrossSellAdmin class.
 */
class CrossSellAdmin {
	use SingletonTrait;

	/**
	 * Constructor.
	 *
	 * Registers hooks to add and render the custom "Extended Cross Sell"
	 * tab and meta boxes in the WooCommerce product data panel.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'woocommerce_product_data_tabs', [ $this, 'add_extended_cross_sell_tab' ] );
		add_action( 'woocommerce_product_data_panels', [ $this, 'render_meta_boxes' ] );
		add_action( 'woocommerce_process_product_meta', [ $this, 'save_extended_cross_sell_meta' ], 10 );
	}
	/**
	 * Adds the Product Add-Ons tab to the product data tabs.
	 *
	 * @param array $tabs Existing tabs.
	 *
	 * @return array Modified tabs.
	 */
	public function add_extended_cross_sell_tab( $tabs ) {
		$tabs['rtsb_extended_cross_sell'] = [
			'label'    => esc_html__( 'Extended Cross-sell', 'shopbuilder-pro' ),
			'target'   => 'rtsb_extended_cross_sell',
			'class'    => [ 'show_if_simple', 'show_if_variable' ],
			'priority' => 66,
		];

		return $tabs;
	}
	/**
	 * Renders meta-boxes to the WooCommerce product data panels.
	 *
	 * @return void
	 */
	public function render_meta_boxes() {
		global $post;
		$disable_cross_sell = get_post_meta( $post->ID, '_rtsb_disable_extended_cross_sell', true );
		$enable_cross_sell  = get_post_meta( $post->ID, '_rtsb_enable_extended_cross_sell', true );
		$product_source     = get_post_meta( $post->ID, '_rtsb_cross_sell_product_source', true );

		$applied_products   = get_post_meta( $post->ID, '_rtsb_cross_sell_applied_products', true );
		$applied_categories = get_post_meta( $post->ID, '_rtsb_cross_sell_applied_categories', true );
		$disable_checked    = 'on' === $disable_cross_sell ? 'on' : 'off';
		$enable_checked     = 'on' === $enable_cross_sell ? 'on' : 'off';
		$enable_visibility  = 'on' === $enable_cross_sell ? ' hidden' : '';

		$applied_product_titles = [];
		if ( ! empty( $applied_products ) ) {
			if ( is_array( $applied_products ) ) {
				foreach ( $applied_products as $product_id ) {
					$applied_product_titles[ $product_id ] = get_the_title( $product_id );
				}
			} else {
				$applied_product_titles[ $applied_products ] = get_the_title( $applied_products );
			}
		}
		$applied_category_titles = [];

		if ( ! empty( $applied_categories ) ) {
			if ( is_array( $applied_categories ) ) {
				foreach ( $applied_categories as $cat_slug ) {
					$term = get_term_by( 'slug', $cat_slug, 'product_cat' );
					if ( $term && ! is_wp_error( $term ) ) {
						$applied_category_titles[ $cat_slug ] = $term->name;
					}
				}
			} else {
				$term = get_term_by( 'slug', $applied_categories, 'product_cat' );
				if ( $term && ! is_wp_error( $term ) ) {
					$applied_category_titles[ $applied_categories ] = $term->name;
				}
			}
		}
		?>
		<div id='rtsb_extended_cross_sell' class='panel woocommerce_options_panel rtsb_panel hidden'>
			<div class="rtsb-group-heading">
				<h2><?php esc_html_e( 'Extended Cross-sell Settings', 'shopbuilder-pro' ); ?></h2>
			</div>
			<div id="rtsb_extended_cross_sell_options_group" class="options_group">
				<?php wp_nonce_field( rtsb()->nonceText, rtsb()->nonceId ); ?>
				<div class="rtsb-extended-cross-sell-group-control">
					<div id="rtsb_extended_disable_cross_sell_group">
						<?php
						Fns::print_html(
							AdminInputsFns::generate_switch_input(
								[
									'id'            => '_rtsb_disable_extended_cross_sell',
									'label'         => esc_html__( 'Disable Global Cross-Sell?', 'shopbuilder-pro' ),
									'desc_tip'      => true,
									'aria_label'    => esc_html__( 'Disable Global Extended Cross-sell', 'shopbuilder-pro' ),
									'description'   => esc_html__( 'Switch on to disable the ShopBuilder extended cross-sell settings for this product.', 'shopbuilder-pro' ),
									'checked'       => esc_attr( $disable_checked ),
									'value'         => 'on',
									'input_class'   => 'switch-input',
									'wrapper_class' => 'form-field disable-rules',
								]
							),
							true
						);
						?>
					</div>
					<div id="rtsb_extended_enable_cross_sell_group">
						<?php
						Fns::print_html(
							AdminInputsFns::generate_switch_input(
								[
									'id'            => '_rtsb_enable_extended_cross_sell',
									'label'         => esc_html__( 'Override Global Cross-Sell?', 'shopbuilder-pro' ),
									'desc_tip'      => true,
									'aria_label'    => esc_html__( 'Override Global Extended Cross-sell', 'shopbuilder-pro' ),
									'description'   => esc_html__( 'Switch on to override the ShopBuilder global extended cross-sell settings for this product.', 'shopbuilder-pro' ),
									'checked'       => esc_attr( $enable_checked ),
									'value'         => 'on',
									'input_class'   => 'switch-input',
									'wrapper_class' => 'form-field ',
								]
							),
							true
						);
						?>
					</div>
				</div>
				<div id="rtsb_extended_cross_sell_groups" class="rtsb-rtsb-extended-cross-sell-fields<?php echo esc_attr( $enable_visibility ); ?>">
					<?php
					$fields  = AdminInputsFns::generate_select_input(
						[
							'id'            => '_rtsb_cross_sell_product_source',
							'label'         => esc_html__( 'Product Source', 'shopbuilder-pro' ),
							'desc_tip'      => true,
							'aria_label'    => esc_html__( 'Product Source', 'shopbuilder-pro' ),
							'description'   => esc_html__( 'Select product source.', 'shopbuilder-pro' ),
							'value'         => ! empty( $product_source ) ? $product_source : '',
							'input_class'   => 'short',
							'label_class'   => 'field-label',
							'options'       => [
								'cross_sell'      => esc_html__( 'Cross Sell', 'shopbuilder-pro' ),
								'up_sell'         => esc_html__( 'UpSell', 'shopbuilder-pro' ),
								'related'         => esc_html__( 'Related Products', 'shopbuilder-pro' ),
								'categories'      => esc_html__( 'Product Categories', 'shopbuilder-pro' ),
								'custom_products' => esc_html__( 'Custom Products', 'shopbuilder-pro' ),
							],
							'wrapper_class' => 'form-field input-type rtsb-cross-sell-product-source',
						]
					);
					$fields .= AdminInputsFns::generate_product_search_multiselect_input(
						[
							'id'            => '_rtsb_cross_sell_applied_products',
							'label'         => esc_html__( 'Applicable Products', 'shopbuilder-pro' ),
							'desc_tip'      => true,
							'aria_label'    => esc_html__( 'Applicable Products', 'shopbuilder-pro' ),
							'description'   => esc_html__( 'Select your desired products for displaying cross-sell popups.', 'shopbuilder-pro' ),
							'value'         => ! empty( $applied_products ) ? $applied_products : '',
							'options'       => $applied_product_titles,
							'multiple'      => true,
							'input_class'   => 'short',
							'label_class'   => 'field-label',
							'wrapper_class' => 'form-field input-type rtsb-cross-sell-applied-product',
						]
					);
					$fields .= AdminInputsFns::generate_product_category_search_multiselect_input(
						[
							'id'            => '_rtsb_cross_sell_applied_categories',
							'label'         => esc_html__( 'Applicable Categories', 'shopbuilder-pro' ),
							'desc_tip'      => true,
							'aria_label'    => esc_html__( 'Applicable Categories', 'shopbuilder-pro' ),
							'description'   => esc_html__( 'Select your desired categories for displaying cross-sell popups.', 'shopbuilder-pro' ),
							'value'         => ! empty( $applied_categories ) ? $applied_categories : '',
							'options'       => $applied_category_titles,
							'multiple'      => true,
							'input_class'   => 'short',
							'label_class'   => 'field-label',
							'wrapper_class' => 'form-field input-type rtsb-cross-sell-applied-category',
						]
					);

					Fns::print_html( $fields, true )
					?>
				</div>

			</div>
		</div>
		<?php
	}
	/**
	 * Saves discount meta fields for a product.
	 *
	 * This function handles saving discount enable/disable options
	 * when a product is updated in the admin panel.
	 *
	 * @param int $post_id The ID of the product being saved.
	 * @return void
	 */
	public function save_extended_cross_sell_meta( $post_id ) {
		// Verify nonce.
		check_admin_referer( rtsb()->nonceText, rtsb()->nonceId );

		$disable_cross_sell = isset( $_REQUEST['_rtsb_disable_extended_cross_sell'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_rtsb_disable_extended_cross_sell'] ) ) : null;
		$enable_cross_sell  = isset( $_REQUEST['_rtsb_enable_extended_cross_sell'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_rtsb_enable_extended_cross_sell'] ) ) : null;

		$product_source = isset( $_REQUEST['_rtsb_cross_sell_product_source'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_rtsb_cross_sell_product_source'] ) ) : null;

		$applied_products = [];
		if ( isset( $_REQUEST['_rtsb_cross_sell_applied_products'] ) ) {
			if ( is_array( $_REQUEST['_rtsb_cross_sell_applied_products'] ) ) {
				$applied_products = $this->sanitize_array( '_rtsb_cross_sell_applied_products' );
			} else {
				$applied_products = sanitize_text_field( wp_unslash( $_REQUEST['_rtsb_cross_sell_applied_products'] ) );
			}
		}

		$applied_categories = [];
		if ( isset( $_REQUEST['_rtsb_cross_sell_applied_categories'] ) ) {
			if ( is_array( $_REQUEST['_rtsb_cross_sell_applied_categories'] ) ) {
				$applied_categories = $this->sanitize_array( '_rtsb_cross_sell_applied_categories' );
			} else {
				$applied_categories = sanitize_text_field( wp_unslash( $_REQUEST['_rtsb_cross_sell_applied_categories'] ) );
			}
		}

		// Disable Cross Sell.
		if ( ! empty( $disable_cross_sell ) && 'on' === $disable_cross_sell ) {
			update_post_meta( $post_id, '_rtsb_disable_extended_cross_sell', $disable_cross_sell );
		} else {
			delete_post_meta( $post_id, '_rtsb_disable_extended_cross_sell' );
		}
		// Enable Cross Sell.
		if ( ! empty( $enable_cross_sell ) && 'on' === $enable_cross_sell ) {
			update_post_meta( $post_id, '_rtsb_enable_extended_cross_sell', $enable_cross_sell );
		} else {
			delete_post_meta( $post_id, '_rtsb_enable_extended_cross_sell' );
		}

		update_post_meta( $post_id, '_rtsb_cross_sell_applied_products', $applied_products );
		update_post_meta( $post_id, '_rtsb_cross_sell_product_source', $product_source );
		update_post_meta( $post_id, '_rtsb_cross_sell_applied_categories', $applied_categories );
	}
	/**
	 * Sanitize an array of strings.
	 *
	 * @param string $meta_key Meta key.
	 *
	 * @return array
	 */
	public function sanitize_array( $meta_key ) {
		return isset( $_REQUEST[ $meta_key ] ) && is_array( $_REQUEST[ $meta_key ] ) ? array_map( 'sanitize_text_field', wp_unslash( $_REQUEST[ $meta_key ] ) ) : []; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
}
