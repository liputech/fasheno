<?php
/**
 * PDF Invoice Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\ExtendedCrossSell;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Back-order Module Class.
 */
class CrossSellInit {

	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Asset Handle
	 *
	 * @var string
	 */
	private $handle = 'rtsb-extended-cross-sell';

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		if ( is_admin() ) {
			CrossSellAdmin::instance();
		}
		$this->init();
	}
	/**
	 * @return void
	 */
	public function init() {
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_assets' ], 99 );
		add_action( 'wp_footer', [ $this, 'add_popup_html' ] );
		add_action( 'woocommerce_add_to_cart', [ $this, 'trigger_crosssell_popup' ], 10, 2 );
		add_action( 'wp_ajax_rtsb_get_crosssell_trigger', [ $this, 'get_crosssell_trigger' ] );
		add_action( 'wp_ajax_nopriv_rtsb_get_crosssell_trigger', [ $this,'get_crosssell_trigger' ] );
		add_action( 'wp_ajax_rtsb_add_to_cart_crosssell', [ $this, 'handle_add_to_cart' ] );
		add_action( 'wp_ajax_nopriv_rtsb_add_to_cart_crosssell', [ $this, 'handle_add_to_cart' ] );

		// AJAX handlers for add to cart.
		add_action( 'wp_ajax_rtsb_crosssell_add_to_cart', [ $this, 'cross_sell_ajax_add_to_cart' ] );
		add_action( 'wp_ajax_nopriv_rtsb_crosssell_add_to_cart', [ $this, 'cross_sell_ajax_add_to_cart' ] );
	}
	/**
	 * Assets.
	 *
	 * @return void
	 */
	public function frontend_assets() {
		$this->handle = Fns::enqueue_module_assets(
			$this->handle,
			'extended-cross-sell',
			[
				'context' => rtsbpro(),
				'version' => RTSBPRO_VERSION,
			]
		);
		$options      = CrossSellFns::get_options();
		$params       = [
			'crossSellPopupDelay' => $options['popup_delay'] ?? 500,
		];
		wp_localize_script( $this->handle, 'rtsbProCrossSellParams', $params );

		$dynamic_css = '';

		$button_selector       = '#rtsb-crosssell-popup .rtsb-crosssell-popup-action-btn a,#rtsb-crosssell-popup .rtsb-cross-sell-popup-footer .rtsb-checkout-button,.rtsb-crosssell-popup .rtsb-cross-sell-select-options,.rtsb-crosssell-popup .rtsb-cross-sell-add-to-cart,.rtsb-crosssell-popup .rtsb-cross-sell-view-product';
		$button_hover_selector = '#rtsb-crosssell-popup .rtsb-crosssell-popup-action-btn a:hover,#rtsb-crosssell-popup .rtsb-cross-sell-popup-footer .rtsb-checkout-button:hover,.rtsb-crosssell-popup .rtsb-cross-sell-select-options:hover,.rtsb-crosssell-popup .rtsb-cross-sell-add-to-cart:hover,.rtsb-crosssell-popup .rtsb-cross-sell-view-product:hover';
		if ( ! empty( $options['btn_bg'] ) ) {
			$dynamic_css .= "$button_selector{background-color:{$options['btn_bg']};}";
		}
		if ( ! empty( $options['btn_color'] ) ) {
			$dynamic_css .= "$button_selector{color:{$options['btn_color']};}";
		}
		if ( ! empty( $options['btn_border_color'] ) ) {
			$dynamic_css .= "$button_selector{border:1px solid {$options['btn_border_color']};}";
		}
		if ( ! empty( $options['btn_border_hover_color'] ) ) {
			$dynamic_css .= "$button_hover_selector{border:1px solid {$options['btn_border_hover_color']};}";
		}
		if ( ! empty( $options['btn_bg_hover'] ) ) {
			$dynamic_css .= "$button_hover_selector{background-color:{$options['btn_bg_hover']};}";
		}
		if ( ! empty( $options['btn_hover_color'] ) ) {
			$dynamic_css .= "$button_hover_selector{color:{$options['btn_hover_color']};}";
		}

		if ( ! empty( $dynamic_css ) ) {
			wp_add_inline_style( $this->handle, $dynamic_css );
		}
	}
	/**
	 * Render the HTML structure for the cross-sell popup.
	 *
	 * This function outputs the popup container and its content markup,
	 * which includes a close button, a dynamic title, and an empty grid
	 * container where products will be injected via AJAX.
	 *
	 * The popup title is retrieved from the plugin settings (`crosssell_popup_settings`)
	 * and falls back to a default string if not set.
	 *
	 * @return void Outputs HTML directly.
	 */
	public function add_popup_html() {
		if ( ! $this->should_show_popup() ) {
			return;
		}
		$options = CrossSellFns::get_options();
		$layout  = $options['template_layout'] ?? 'layout1';
		?>
		<div id="rtsb-crosssell-popup" class="rtsb-crosssell-popup <?php echo esc_attr( $layout ); ?>" style="display: none;">
			<div class="rtsb-crosssell-popup-content">
				<!-- Products will be loaded here via AJAX -->
			</div>
		</div>
		<?php
	}
	/**
	 * Trigger the cross-sell popup when a product is added to the cart.
	 *
	 * This function stores the product ID in the WooCommerce session, which
	 * can later be used to determine which product(s) to display in the popup.
	 *
	 * @param string $cart_item_key Unique key for the cart item.
	 * @param int    $product_id    The ID of the product being added to the cart.
	 *
	 * @return void
	 */
	public function trigger_crosssell_popup( $cart_item_key, $product_id ) {
		$disable_cross_sell = get_post_meta( $product_id, '_rtsb_disable_extended_cross_sell', true );

		if ( ! $this->should_show_popup() || 'on' == $disable_cross_sell ) {
			return;
		}

		// Store the product ID in WooCommerce session.
		if ( WC()->session ) {
			WC()->session->set( 'rtsb_crosssell_trigger', $product_id );
			\WC()->session->set( 'rtsb_cross_sell_popup', true );
		}
	}
	/**
	 * Get the cross-sell trigger product ID via AJAX.
	 *
	 * Verifies the nonce, retrieves the product ID from WooCommerce session,
	 * clears it, and returns it in a JSON response.
	 *
	 * @return void
	 */
	public function get_crosssell_trigger() {
		if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rtsb_nonce' ) ) {
			wp_send_json_error( [ 'message' => 'Invalid nonce' ], 403 );
		}

		$product_id = WC()->session ? WC()->session->get( 'rtsb_crosssell_trigger' ) : false;

		if ( $product_id && \WC()->session->get( 'rtsb_cross_sell_popup' ) ) {
			WC()->session->__unset( 'rtsb_crosssell_trigger' );
			WC()->session->__unset( 'rtsb_cross_sell_popup' );
			wp_send_json_success( [ 'product_id' => intval( $product_id ) ] );
		} else {
			wp_send_json_error( [ 'message' => 'No trigger found' ] );
		}
	}
	/**
	 * Handle AJAX request for cross-sell products after add-to-cart.
	 *
	 * Validates nonce, gets cross-sell or related products for the given product,
	 * renders their HTML output, and returns it as a JSON response.
	 *
	 * @return void
	 */
	public function handle_add_to_cart() {

		if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rtsb_nonce' ) ) {
			wp_send_json_error( [ 'message' => 'Invalid nonce' ], 403 );
		}
		$options                  = CrossSellFns::get_options();
		$title                    = $options['popup_title'] ?? '';
		$layout                   = $options['template_layout'] ?? 'layout1';
		$layout_class             = 'layout1' === $layout ? 'grid' : 'list';
		$product_id               = ! empty( intval( $_POST['product_id'] ) ) ? intval( $_POST['product_id'] ) : 0;
		$last_added_product_title = get_the_title( $product_id );
		$product_name             = $last_added_product_title ? $last_added_product_title : 'Product';
		$product                  = wc_get_product( $product_id );
		$disable_cross_sell       = get_post_meta( $product_id, '_rtsb_disable_extended_cross_sell', true );
		if ( ! $product ) {
			wp_die();
		}

		$crosssell_ids = $this->get_products_for_popup( $product, $product_id );

		ob_start();

		if ( ! empty( $crosssell_ids && 'on' != $disable_cross_sell ) ) {
			?>
			<div class="rtsb-cross-sell-popup-header">
				<div class="rtsb-success-message">
					<svg viewBox="0 0 24 24" width="20" height="20"><circle cx="12" cy="12" r="10" fill="#4CAF50"/><path d="M9 12l2 2 4-4" fill="none" stroke="#fff" stroke-width="2"/></svg>
					<span class="added-message"><?php echo esc_html( $product_name ); ?> <?php esc_html_e( 'Has been added.', 'shopbuilder-pro' ); ?></span>
				</div>
				<span class="rtsb-crosssell-popup-close">&times;</span>
			</div>
			<div class="rtsb-crosssell-popup-action-btn">
				<a  href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="shopping-cart-btn"><?php esc_html_e( 'View Shopping Cart', 'shopbuilder-pro' ); ?></a>
				<a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="continue-shopping-btn"><?php esc_html_e( 'Continue Shopping', 'shopbuilder-pro' ); ?></a>
			</div>
			<?php if ( $title ) { ?>
				<h3 class="rtsb-popup-title"><?php echo esc_html( $title ); ?></h3>
			<?php } ?>
			<div id="rtsb-crosssell-products" class="rtsb-crosssell-products-<?php echo esc_attr( $layout_class ); ?>">
				<?php
				foreach ( $crosssell_ids as $crosssell_id ) {
					$data = [
						'crosssell_id' => $crosssell_id,
					];
					Fns::load_template( 'extended-cross-sell/cross-sell-product', $data, false, '', rtsbpro()->get_plugin_template_path() );
				}
				?>
			</div>
			<div class="rtsb-cross-sell-popup-footer">
				<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="rtsb-checkout-button">
					<?php echo esc_html__( 'Proceed to Checkout', 'shopbuilder-pro' ); ?>
				</a>
			</div>
			<?php
		}

		$html = ob_get_clean();
		$this->cleanup_session_data();
		wp_send_json_success( $html );
	}
	/**
	 * Handle AJAX add-to-cart for cross-sell products.
	 *
	 * Validates nonce, product ID, stock status, and WooCommerce filters,
	 * then adds the product to the cart and returns updated cart details.
	 * Sends JSON error responses if validation fails or product cannot be added.
	 *
	 * @return void
	 * @throws \Exception If validation fails or adding to cart is unsuccessful.
	 */
	public function cross_sell_ajax_add_to_cart() {
		try {
			if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rtsb_nonce' ) ) {
				wp_send_json_error( [ 'message' => 'Invalid nonce' ], 403 );
			}
			if ( ! isset( $_POST['product_id'] ) ) {
				throw new \Exception( esc_html__( 'Invalid product', 'shopbuilder-pro' ) );
			}
			$product_id = absint( $_POST['product_id'] );
			$quantity   = isset( $_POST['quantity'] ) ? absint( $_POST['quantity'] ) : 1;
			$product    = wc_get_product( $product_id );
			if ( ! $product ) {
				throw new \Exception( esc_html__( 'Product not found', 'shopbuilder-pro' ) );
			}

			if ( ! $product->is_in_stock() ) {
				throw new \Exception( esc_html__( 'Product is out of stock', 'shopbuilder-pro' ) );
			}

			$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );
			if ( ! $passed_validation ) {
				throw new \Exception( esc_html__( 'Product validation failed', 'shopbuilder-pro' ) );
			}
			if ( \WC()->cart->add_to_cart( $product_id, $quantity ) ) {
				do_action( 'woocommerce_ajax_added_to_cart', $product_id );

				wp_send_json_success(
					[
						'message'    => __( 'Product added to cart', 'shopbuilder-pro' ),
						'cart_count' => \WC()->cart->get_cart_contents_count(),
						'cart_total' => \WC()->cart->get_cart_total(),
					]
				);
			} else {
				throw new \Exception( __( 'Failed to add product to cart', 'shopbuilder-pro' ) );
			}
		} catch ( \Exception $e ) {
			wp_send_json_error(
				[
					'message' => $e->getMessage(),
				]
			);
		}
	}
	/**
	 * Determine if the cross-sell popup should be shown.
	 *
	 * Currently hides the popup on the checkout page.
	 *
	 * @return bool True if popup should be shown, false otherwise.
	 */
	public function should_show_popup() {
		if ( is_checkout() ) {
			return false;
		}
		return true;
	}
	/**
	 * Clear cross-sell popup session data.
	 *
	 * Resets stored session values for popup trigger and last added product.
	 *
	 * @return void
	 */
	private function cleanup_session_data() {
		if ( \WC()->session ) {
			\WC()->session->set( 'rtsb_cross_sell_popup', false );
			\WC()->session->set( 'rtsb_last_added_product', null );
		}
	}
	/**
	 * Get products to display in the cross-sell popup.
	 *
	 * Determines which products to show based on plugin settings or product-level
	 * overrides. Filters out unavailable or non-purchasable products, and limits
	 * the number of results according to the settings.
	 *
	 * @param \WC_Product $product    The current WooCommerce product object.
	 * @param int         $product_id The current product ID.
	 *
	 * @return array List of valid product IDs to display in the popup.
	 */
	public function get_products_for_popup( $product, $product_id ) {
		$options = CrossSellFns::get_options();

		// Get product source and applicable sets.
		if ( $this->is_override_enabled( $product_id ) ) {
			$product_source        = get_post_meta( $product_id, '_rtsb_cross_sell_product_source', true );
			$applicable_products   = $this->get_applied_products( $product_id );
			$applicable_categories = $this->get_applied_categories( $product_id );
		} else {
			$product_source        = $options['product_source'] ?? 'cross_sell';
			$applicable_products   = Fns::multiselect_settings_field_value( $options['applicable_products'] ?? '' );
			$applicable_categories = Fns::multiselect_settings_field_value( $options['applicable_categories'] ?? '' );
		}

		$max_products = $options['products_limit'] ?? 4;
		$products_ids = $this->get_products_by_source(
			$product_source,
			$product,
			$product_id,
			$applicable_products,
			$applicable_categories,
			$max_products
		);

		// Limit unless categories source.
		if ( 'categories' !== $product_source ) {
			$products_ids = array_slice( $products_ids, 0, $max_products );
		}
		if ( WC()->cart && ! WC()->cart->is_empty() ) {
			$cart_product_ids = [];

			foreach ( WC()->cart->get_cart() as $cart_item ) {
				$cart_product_ids[] = $cart_item['variation_id'] ?: $cart_item['product_id'];
			}

			$products_ids = array_map(
				function ( $p ) {
					return is_object( $p ) ? $p->get_id() : absint( $p );
				},
				$products_ids
			);

			$products_ids = array_diff( $products_ids, $cart_product_ids );

		}

		// Filter only purchasable + in stock.
		return array_filter(
			$products_ids,
			function ( $pid ) {
				$p = wc_get_product( $pid );
				return $p && $p->is_in_stock() && $p->is_purchasable();
			}
		);
	}

	/**
	 * Check if product-level overrides are enabled.
	 *
	 * @param int $product_id Product ID to check.
	 *
	 * @return bool True if override is enabled, false otherwise.
	 */
	private function is_override_enabled( $product_id ) {
		return 'on' === get_post_meta( $product_id, '_rtsb_enable_extended_cross_sell', true );
	}

	/**
	 * Retrieve applied product IDs from post meta.
	 *
	 * Ensures the return value is always an array of integers, whether
	 * the meta contains a single ID or multiple IDs.
	 *
	 * @param int $product_id The current product ID.
	 *
	 * @return int[] Array of product IDs.
	 */
	private function get_applied_products( $product_id ) {
		$products = [];
		$meta     = get_post_meta( $product_id, '_rtsb_cross_sell_applied_products', true );

		if ( ! empty( $meta ) ) {
			$products = is_array( $meta ) ? array_map( 'absint', $meta ) : [ absint( $meta ) ];
		}

		return $products;
	}

	/**
	 * Retrieve applied category IDs from post meta.
	 *
	 * Converts category slugs stored in meta into valid WooCommerce
	 * product category IDs. Always returns an array of integers.
	 *
	 * @param int $product_id The current product ID.
	 *
	 * @return int[] Array of category term IDs.
	 */
	private function get_applied_categories( $product_id ) {
		$categories = [];
		$meta       = get_post_meta( $product_id, '_rtsb_cross_sell_applied_categories', true );

		if ( ! empty( $meta ) ) {
			$slugs = is_array( $meta ) ? $meta : [ $meta ];
			foreach ( $slugs as $slug ) {
				$category = get_term_by( 'slug', $slug, 'product_cat' );
				if ( $category ) {
					$categories[] = (int) $category->term_id;
				}
			}
		}

		return $categories;
	}

	/**
	 * Retrieve product IDs based on the selected product source.
	 *
	 * @param string      $source               The product source type (cross_sell, up_sell, related, categories, custom_products).
	 * @param \WC_Product $product             The current WooCommerce product object.
	 * @param int         $product_id           The current product ID.
	 * @param int[]       $applicable_products  List of manually selected product IDs.
	 * @param int[]       $applicable_categories List of applicable category IDs.
	 * @param int         $max                  Maximum number of products to retrieve.
	 *
	 * @return \WC_Product[] Array of product IDs from the given source.
	 */
	private function get_products_by_source( $source, $product, $product_id, $applicable_products, $applicable_categories, $max ) {
		switch ( $source ) {
			case 'cross_sell':
				return $this->get_cross_sell_products( $product );
			case 'up_sell':
				return $this->get_up_sell_products( $product );
			case 'related':
				return $this->get_related_products( $product_id );
			case 'categories':
				return $this->get_categories_products( $max, $applicable_categories );
			case 'custom_products':
				return $this->get_custom_products( $applicable_products );
			default:
				return [];
		}
	}



	/**
	 * Get cross-sell product IDs for a given product.
	 *
	 * @param \WC_Product $product WooCommerce product object.
	 * @return array List of cross-sell product IDs.
	 */
	public function get_cross_sell_products( $product ) {
		return $product->get_cross_sell_ids();
	}
	/**
	 * Get up-sell product IDs for a given product.
	 *
	 * @param \WC_Product $product WooCommerce product object.
	 * @return array List of up-sell product IDs.
	 */
	public function get_up_sell_products( $product ) {
		return $product->get_upsell_ids();
	}
	/**
	 * Get related product IDs for a given product.
	 *
	 * @param int $product_id WooCommerce product ID.
	 * @return array List of related product IDs.
	 */
	public function get_related_products( $product_id ) {
		return wc_get_related_products( $product_id );
	}
	/**
	 * Get products from specific categories.
	 *
	 * Queries products from the given category IDs and returns
	 * an array of WC_Product objects indexed by product ID.
	 *
	 * @param int   $max_products        Maximum number of products to return.
	 * @param array $applicable_categories Array of category term IDs to include.
	 *
	 * @return \WC_Product[] Array of WC_Product objects indexed by product ID.
	 */
	public function get_categories_products( $max_products, $applicable_categories ) {
		$products = [];
		if ( ! empty( $applicable_categories ) && is_array( $applicable_categories ) ) {
			$args = [
				'post_type'      => 'product',
				'posts_per_page' => $max_products,
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'tax_query'      => [
					[
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $applicable_categories,
					],
				],
			];

			$query = new \WP_Query( $args );

			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					$product = wc_get_product( get_the_ID() );
					if ( $product ) {
						$products[ $product->get_id() ] = $product;
					}
				}
				wp_reset_postdata();
			}
		}

		return $products;
	}
	/**
	 * Get custom products by their IDs.
	 *
	 * Loops through the provided product IDs and returns an array
	 * of WC_Product objects for valid products, indexed by product ID.
	 *
	 * @param array $applicable_products Array of product IDs to include.
	 *
	 * @return \WC_Product[] Array of WC_Product objects indexed by product ID.
	 */
	public function get_custom_products( $applicable_products ) {
		$products = [];
		if ( ! empty( $applicable_products ) && is_array( $applicable_products ) ) {
			foreach ( $applicable_products as $product_id ) {
				$product = wc_get_product( $product_id );
				if ( $product ) {
					$products[ $product_id ] = $product;
				}
			}
		}
		return $products;
	}
}
