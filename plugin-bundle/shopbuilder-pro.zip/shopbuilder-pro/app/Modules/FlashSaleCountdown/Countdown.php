<?php
/**
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\FlashSaleCountdown;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Helpers\FnsPro;
use RadiusTheme\SBPRO\Modules\AddOns\AddOnsFns;
use RadiusTheme\SBPRO\Modules\PreOrder\PreOrderFns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class Countdown {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * @var array
	 */
	private $cache = [];

	/**
	 * Hello
	 */
	private function __construct() {
		if ( wp_doing_ajax() || ! is_admin() ) {
			add_filter( 'rtsb/currency/switcher/disable/price/html', [ $this, 'currency_switcher_disable_price_html' ], 10, 2 );
			// Price Html.
			add_filter( 'woocommerce_get_price_html', [ $this, 'custom_price_html_display' ], 10, 2 );
			// Generating dynamically the product "sale price".
			add_filter( 'woocommerce_product_is_on_sale', [ $this, 'campaign_set_product_as_on_sale' ], 50, 2 );
			// Hello.
			add_filter( 'woocommerce_cart_contents_changed', [ $this, 'adjust_cart_subtotal' ], 25, 1 );
			CountdownFrontEnd::instance();
		}
	}

	/**
	 * Filter to disable the price HTML output when a campaign is active for the product.
	 *
	 * This is intended for use with a currency switcher plugin or similar,
	 * where the price HTML should be hidden if a matching campaign is found for the product.
	 *
	 * @param mixed       $bool    Current disable state (true or false).
	 * @param \WC_Product $product WooCommerce product object.
	 * @return mixed|true Returns true if a campaign is active for the product, otherwise returns the original $bool value.
	 */
	public function currency_switcher_disable_price_html( $bool, $product ) {
		$campaign = CountdownFns::get_campaign_for_current_product( $product );
		if ( empty( $campaign ) ) {
			return $bool;
		}
		return true;
	}
	/**
	 * Determines if a product should be marked as on sale based on campaign settings.
	 *
	 * Checks if a product is associated with an active campaign and applies the campaign discount logic.
	 * Utilizes caching for performance optimization.
	 *
	 * @param bool        $on_sale Whether the product is already marked as on sale.
	 * @param \WC_Product $product The WooCommerce product object.
	 *
	 * @return bool True if the product is on sale due to a campaign or previous conditions; otherwise, the original $on_sale value.
	 */
	public function campaign_set_product_as_on_sale( $on_sale, $product ) {
		if ( $on_sale || ! $product instanceof \WC_Product ) {
			return $on_sale;
		}
		$product_id = $product->get_id();
		$cache_key  = 'campaign_cache_on_sale_' . $product_id;
		if ( isset( $this->cache[ $cache_key ] ) ) {
			return $this->cache[ $cache_key ];
		}
		$campaign = CountdownFns::get_campaign_for_current_product( $product );
		if ( empty( $campaign ) ) {
			return $on_sale;
		}
		$discount_price = $campaign['discount_amount'] ?? 0;
		if ( ! empty( $discount_price ) ) {
			$this->cache[ $cache_key ] = true;
			return $this->cache[ $cache_key ];
		}
		$this->cache[ $cache_key ] = $on_sale;
		return $this->cache[ $cache_key ];
	}

	/**
	 * Price Html Customize.
	 *
	 * @param string $price_html string.
	 * @param object $product product object.
	 * @return mixed|string
	 */
	public function custom_price_html_display( $price_html, $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return $price_html;
		}
		$is_on_pre_order = 'variation' === $product->get_type()
			? PreOrderFns::variation_id_is_on_pre_order( $product->get_id() )
			: PreOrderFns::is_on_pre_order( $product );

		if ( $is_on_pre_order ) {
			return $price_html;
		}

		$campaign = CountdownFns::get_campaign_for_current_product( $product );

		if ( empty( $campaign ) || empty( $campaign['discount_amount'] ) ) {
			return $price_html;
		}

		if ( $product->is_type( 'variable' ) ) {
			$min_regular = $product->get_variation_regular_price( 'min', true );
			$max_regular = $product->get_variation_regular_price( 'max', true );
			$min_sale    = $min_regular - CountdownFns::campaign_discount_price( $min_regular, $campaign );
			$max_sale    = $max_regular - CountdownFns::campaign_discount_price( $max_regular, $campaign );
			// Return range price display with del/ins.
			return wc_price( $min_sale ) . ' – ' . wc_price( $max_sale );
		}

		// Simple product.
		$regular_price = floatval( $product->get_regular_price() );
		$sale_price    = $regular_price - CountdownFns::campaign_discount_price( $regular_price, $campaign );
		$regular_price = Fns::get_currency_base_price( $regular_price );
		$sale_price    = Fns::get_currency_base_price( $sale_price );

		if ( $sale_price && $sale_price < $regular_price ) {
			return wc_format_sale_price( $regular_price, $sale_price );
		}
		return wc_price( $regular_price );
	}

	/**
	 * Adjusts the cart subtotal based on campaign discounts.
	 *
	 * @param array $cart_contents Cart Content.
	 * @return array
	 */
	public function adjust_cart_subtotal( $cart_contents ) {
		foreach ( $cart_contents as $cart_item ) {
			$campaign = CountdownFns::get_campaign_for_current_product( $cart_item['data'] );
			if ( empty( $campaign ) || empty( $campaign['discount_amount'] ) ) {
				continue;
			}
			$regular_price = floatval( $cart_item['data']->get_regular_price() );
			$sale_price    = $regular_price - CountdownFns::campaign_discount_price( $regular_price, $campaign );
			$cart_item['data']->set_price( $sale_price );
		}
		return $cart_contents;
	}
}
