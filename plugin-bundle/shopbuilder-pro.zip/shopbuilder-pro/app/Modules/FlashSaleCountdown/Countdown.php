<?php
/**
 * Main FilterHooks class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\FlashSaleCountdown;

use RadiusTheme\SBPRO\Helpers\FnsPro;
use RadiusTheme\SBPRO\Modules\AddOns\AddOnsFns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class Countdown {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * @var array
	 */
	private $cache = [];

	/**
	 *
	 */
	private function __construct() {
		if ( wp_doing_ajax() || ! is_admin() ) {
			// Generating dynamically the product "sale price".
			add_filter( 'woocommerce_product_is_on_sale', [ $this, 'campaign_set_product_as_on_sale' ], 50, 2 );

			// Product price calculate for cart.
			add_filter( 'woocommerce_product_get_sale_price', [ $this, 'product_get_price' ], 14, 2 );
			add_filter( 'woocommerce_product_get_price', [ $this, 'product_get_price' ], 15, 2 );
			// Generating dynamically the product "sale price".

			// Generating dynamically the product "sale price" for variable products.
			// Example Resource : https://stackoverflow.com/questions/49943319/change-product-variation-prices-via-a-hook-in-woocommerce-3-3
			add_filter( 'woocommerce_product_variation_get_sale_price', [ $this, 'product_get_price' ], 14, 2 );
			add_filter( 'woocommerce_product_variation_get_price', [ $this, 'product_get_price' ], 15, 2 );
			// Hook to modify variation product prices.
			// add_filter( 'woocommerce_variation_prices_price', [ $this, 'product_get_price' ], 15, 2 );
			add_filter( 'woocommerce_variation_prices', [ $this, 'woocommerce_variation_prices_array' ], 5, 2 );

			CountdownFrontEnd::instance();
		}
	}

	/**
	 * @param $sale_price
	 * @param $variation_id
	 * @param $product
	 * @return float|mixed
	 */
	private function product_get_sale_price_for_variation( $sale_price, $variation_id, $product ) {
		$campaign = CountdownFns::get_campaign_for_current_product( $product );

		if ( empty( $campaign ) ) {
			return $sale_price;
		}
		$discount_amount = $campaign['discount_amount'] ?? 0;
		if ( empty( $discount_amount ) ) {
			return $sale_price;
		}

		$regular_price  = floatval( get_post_meta( $variation_id, '_regular_price', true ) );
		$discount_price = floatval( CountdownFns::campaign_discount_price( $regular_price, $campaign ) );


		return $regular_price - $discount_price;
	}


	/**
	 * @param array  $prices_array prices array.
	 * @param object $product product object.
	 * @return array
	 */
	public function woocommerce_variation_prices_array( $prices_array, $product ) {
		if ( is_array( $prices_array['price'] ) ) {
			foreach ( $prices_array['price'] as $key => $value ) {
				$prices_array['price'][ $key ] = $this->product_get_sale_price_for_variation( $value, $key, $product );
			}
		}
		/*
		 * If need will apply.
		if ( is_array( $prices_array['regular_price'] ) ) {
			foreach ( $prices_array['regular_price'] as $key => $value ) {
				$prices_array['regular_price'][ $key ] = $value * $this->get_current_rate();
			}
		}
		if ( is_array( $prices_array['sale_price'] ) ) {
			foreach ( $prices_array['sale_price'] as $key => $value ) {
				$prices_array['sale_price'][ $key ] = $value * $this->get_current_rate();
			}
		}
		*/

		return $prices_array;
	}

	/**
	 * @param $on_sale
	 * @param $product
	 *
	 * @return float
	 */
	public function campaign_set_product_as_on_sale( $on_sale, $product ) {
		if ( $on_sale || ! $product instanceof \WC_Product ) {
			return $on_sale;
		}

		$product_id = $product->get_id();
		$cache_key  = 'campaign_cache_on_sale_' . $product_id;

		if ( isset( $this->cache[ $cache_key ] ) ) {
			return $this->cache[ $cache_key ];
		}

		$campaign = CountdownFns::get_campaign_for_current_product( $product );
		if ( empty( $campaign ) ) {
			return $on_sale;
		}

		$discount_price = $campaign['discount_amount'] ?? 0;

		if ( ! empty( $discount_price ) ) {
			$this->cache[ $cache_key ] = true;
			return $this->cache[ $cache_key ];
		}
		$this->cache[ $cache_key ] = $on_sale;

		return $this->cache[ $cache_key ];
	}

	/**
	 * @param $sale_price
	 * @param $product
	 *
	 * @return float
	 */
	public function product_get_price( $sale_price, $product ) {

		if ( ! $product instanceof \WC_Product ) {
			return $sale_price;
		}

		$type = $product->get_type();

		/**
		 * Product addons compatibility.
		 */
		if ( ( FnsPro::is_module_active( 'product_add_ons' ) )
			&& ( 'variation' === $type || 'simple' === $type ) && AddOnsFns::product_has_addons( $product, 'variation' === $type ) ) {
			return $sale_price;
		}

		$product_id = $product->get_id();
		$cache_key  = 'campaign_cache_' . $product_id;

		if ( ! empty( $this->cache[ $cache_key ] ) ) {
			return $this->cache[ $cache_key ];
		}

		$campaign = CountdownFns::get_campaign_for_current_product( $product );

		if ( ! empty( $campaign ) ) {
			$discount_amount = $campaign['discount_amount'] ?? 0;

			if ( ! empty( $discount_amount ) ) {
				$regular_price  = floatval( get_post_meta( $product_id, '_regular_price', true ) );
				$discount_price = floatval( CountdownFns::campaign_discount_price( $regular_price, $campaign ) );
				$sale_price     = $regular_price - $discount_price;
			}
		}
		$this->cache[ $cache_key ] = $sale_price;
		return $this->cache[ $cache_key ];
	}
}
