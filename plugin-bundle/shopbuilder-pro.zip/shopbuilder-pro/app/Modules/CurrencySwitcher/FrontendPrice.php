<?php
/**
 * Main FilterHooks class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\CurrencySwitcher;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Modules\AddOns\AddOnsFns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();


/**
 * Class WOOMULTI_CURRENCY_Frontend_Price
 */
class FrontendPrice extends CurrencyBase {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Class Constructor
	 */
	private function __construct() {
		parent::__construct();
		$this->exchange_shopping_cost();
	}

	/**
	 * @return void
	 */
	public function exchange_shopping_cost() {
		if ( ! $this->is_available_currency() ) {
			return;
		}

		if ( $this->get_default_currency() === $this->get_current_currency() ) {
			return;
		}
		add_filter( 'rtsb/convert/currency/price', [ $this, 'convert_price' ], 99, 2 );
		add_filter( 'woocommerce_get_price_html', [ $this, 'custom_price_html_display' ], 15, 2 );
		add_filter( 'woocommerce_before_calculate_totals', [ $this, 'apply_custom_price' ], 99 );
		// Hook into WooCommerce shipping calculator.
		add_filter( 'woocommerce_package_rates', [ $this, 'calculate_shipping_costs' ], 35, 2 );
		add_filter( 'woocommerce_shipping_rate_taxes', [ $this, 'shipping_rate_taxes' ], 35, 2 );
		add_filter( 'woocommerce_coupon_get_amount', [ $this, 'custom_convert_coupon_amount' ], 10, 2 );
	}

	/**
	 * Converts the coupon discount amount based on the current currency.
	 *
	 * Applies only to fixed amount coupons (fixed_cart and fixed_product).
	 *
	 * @param float     $amount The original coupon discount amount.
	 * @param WC_Coupon $coupon The WooCommerce coupon object.
	 *
	 * @return float The converted discount amount.
	 */
	public function custom_convert_coupon_amount( $amount, $coupon ) {
		$type = $coupon->get_discount_type(); // fixed_cart, fixed_product, percent
		// Only modify fixed amount coupons.
		if ( ! in_array( $type, [ 'fixed_cart', 'fixed_product' ], true ) ) {
			return $amount;
		}
		$amount = Fns::get_currency_base_price( $amount );
		return $amount;
	}
	/**
	 * Applies the custom price to the cart item.
	 *
	 * @param Object $cart The cart object.
	 *
	 * @return void
	 */
	public function apply_custom_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}
		if ( did_action( 'woocommerce_before_calculate_totals' ) > 1 ) {
			return; // Skip repeated calls.
		}
		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			// Skip if already converted.
			$price         = $cart_item['data']->get_price();
			$regular_price = floatval( $cart_item['data']->get_regular_price() );
			$sale_price    = floatval( $cart_item['data']->get_sale_price() );
			$price         = Fns::get_currency_base_price( $price );
			$regular_price = Fns::get_currency_base_price( $regular_price );
			$sale_price    = Fns::get_currency_base_price( $sale_price );
			$cart_item['data']->set_price( $price );
			$cart_item['data']->set_regular_price( $regular_price );
			$cart_item['data']->set_sale_price( $sale_price );

		}
	}

	/**
	 * Price Html Customize.
	 *
	 * @param string $price_html string.
	 * @param object $product product object.
	 * @return mixed|string
	 */
	public function custom_price_html_display( $price_html, $product ) {
		if ( apply_filters( 'rtsb/currency/switcher/disable/price/html', false, $product ) ) {
			return $price_html;
		}
		if ( ! $product instanceof \WC_Product ) {
			return $price_html;
		}
		if ( $product->is_type( 'variable' ) ) {
			$min_regular = $product->get_variation_regular_price( 'min', true );
			$max_regular = $product->get_variation_regular_price( 'max', true );
			$min_sale    = $product->get_variation_sale_price( 'min', true );
			$max_sale    = $product->get_variation_sale_price( 'max', true );

			$min_regular = $this->convert_price( $min_regular );
			$max_regular = $this->convert_price( $max_regular );
			$min_sale    = $this->convert_price( $min_sale );
			$max_sale    = $this->convert_price( $max_sale );

			if ( $min_sale && $min_sale < $min_regular ) {
				return wc_price( $min_sale ) . ' – ' . wc_price( $max_sale );
			}

			return wc_price( $min_regular ) . ' – ' . wc_price( $max_regular );
		}
		// Simple product.
		// Simple product (regular + sale).
		$regular_price = $this->convert_price( $product->get_regular_price() );
		$sale_price    = $this->convert_price( $product->get_sale_price() );

		if ( $sale_price && $sale_price < $regular_price ) {
			return wc_format_sale_price( $regular_price, $sale_price );
		}
		return wc_price( $regular_price );
	}

	/**
	 * @param float $price Product price.
	 * @return mixed
	 */
	public function convert_price( $price ) {
		if ( ! $price ) {
			return $price;
		}
		return $price * $this->get_current_rate();
	}

	/**
	 * @param array $rates Shipping Cost Rate.
	 * @param array $package shipping package.
	 * @return array
	 */
	public function calculate_shipping_costs( $rates, $package ) {
		foreach ( $rates as $rate_key => $rate ) {
			$rates[ $rate_key ]->cost = $rate->cost * $this->get_current_rate();
		}
		return $rates;
	}

	/**
	 * @param float  $taxes applied Texes.
	 * @param object $obj shipping object.
	 * @return array
	 */
	public function shipping_rate_taxes( $taxes, $obj ) {
		$cost  = $obj->get_cost();
		$taxes = \WC_Tax::calc_shipping_tax( $cost, \WC_Tax::get_shipping_tax_rates() );
		return $taxes;
	}
}
