<?php
/**
 * Main FilterHooks class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\MultiStepsCheckout;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class MultiStepsCheckoutFns {
	/**
	 * @return array
	 */
	public static function settings_field() {
		return apply_filters(
			'rtsb/module/multistep_checkout_settings/fields',
			[

				// Cart Drawer
				// ======================
				'checkout_step_settings'   => [
					'id'    => 'checkout_step_settings',
					'type'  => 'title',
					'label' => esc_html__( 'Multi-step Checkout Settings', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],

				'login_step_visibility'    => [
					'id'    => 'show_login_step',
					'type'  => 'switch',
					'label' => esc_html__( 'Login Step Visibility', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Enable this option to show Login Step. Please note that this settings will override the WooCommerce Guest checkout login option.', 'shopbuilder-pro' ),
					'tab'   => 'general',
					'value' => 'on',
				],

				'show_back_to_cart_button' => [
					'id'    => 'show_back_to_cart_button',
					'type'  => 'switch',
					'label' => esc_html__( 'Back to Cart Button Visibility', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Enable this option to Show Back to cart button', 'shopbuilder-pro' ),
					'tab'   => 'general',
					'value' => 'on',
				],

				'checkout_text_change'     => [
					'id'    => 'checkout_text_change',
					'type'  => 'title',
					'label' => esc_html__( 'Change Label', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],

				// Change all text.
				'back_to_top_btn_text'     => [
					'id'    => 'back_to_top_btn_text',
					'type'  => 'text',
					'label' => esc_html__( 'Back to Cart', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Change "Back to cart" button text', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],
				'previous_btn_text'        => [
					'id'    => 'previous_btn_text',
					'type'  => 'text',
					'label' => esc_html__( 'Previous Button', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Change "Previous" button text', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],
				'next_btn_text'            => [
					'id'    => 'next_btn_text',
					'type'  => 'text',
					'label' => esc_html__( 'Next Button', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Change "Next" button text', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],
				'skip_login_btn_text'      => [
					'id'    => 'skip_login_btn_text',
					'type'  => 'text',
					'label' => esc_html__( 'Skip Login', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Change "Skip Login" button text', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],
				'place_order_btn_text'     => [
					'id'    => 'place_order_btn_text',
					'type'  => 'text',
					'label' => esc_html__( 'Place Order', 'shopbuilder-pro' ),
					'help'  => esc_html__( 'Change "Place Order" button text', 'shopbuilder-pro' ),
					'tab'   => 'general',
				],

				// TODO: Not implemented yet

				// Style.
				'primary_color'            => [
					'id'          => 'primary_color',
					'label'       => esc_html__( 'Primary Color', 'shopbuilder-pro' ),
					'type'        => 'color',
					'default_val' => '#034DFF',
					'tab'         => 'style',
				],
			]
		);
	}

	/**
	 * Checkout Steps
	 *
	 * @return array[]
	 */
	public static function checkout_steps() {

		return apply_filters(
			'rtsb_checkout_steps',
			[
				'billing'  => [
					'title'    => __( 'Billing', 'shopbuilder-pro' ),
					'position' => 10,
					'class'    => 'rtrb-checkout-step-billing',
					'sections' => [ 'billing' ],
				],
				'shipping' => [
					'title'    => __( 'Shipping', 'shopbuilder-pro' ),
					'position' => 20,
					'class'    => 'rtrb-checkout-step-shipping',
					'sections' => [ 'shipping' ],
				],
				'order'    => [
					'title'    => __( 'Order', 'shopbuilder-pro' ),
					'position' => 30,
					'class'    => 'rtrb-checkout-step-order',
					'sections' => [ 'order' ],
				],
				'payment'  => [
					'title'    => __( 'Payment', 'shopbuilder-pro' ),
					'position' => 40,
					'class'    => 'rtrb-checkout-step-payment',
					'sections' => [ 'payment' ],
				],
			]
		);

	}


}
