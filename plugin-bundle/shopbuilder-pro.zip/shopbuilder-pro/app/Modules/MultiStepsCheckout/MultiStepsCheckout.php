<?php
/**
 * Main MiniCart class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\MultiStepsCheckout;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class MultiStepsCheckout {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * @var array|mixed
	 */
	private array $options;

	/**
	 * Class constructor
	 */
	private function __construct() {
		$this->options = Fns::get_options( 'modules', 'multi_step_checkout' );
		if ( class_exists( 'Astra_Woocommerce' ) ) {
			remove_action( 'wp', [ \Astra_Woocommerce::get_instance(), 'woocommerce_checkout' ] );
		}
		add_filter( 'woocommerce_locate_template', [ $this, 'woocommerce_locate_template' ], 30, 3 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_public_scripts' ], 99 );
	}


	/**
	 * @param $template
	 * @param $template_name
	 * @param $template_path
	 *
	 * @return mixed|string
	 */
	public function woocommerce_locate_template( $template, $template_name, $template_path ) {

		if ( 'checkout/form-checkout.php' !== $template_name ) {
			return $template;
		}
		MultiStepsHooks::instance();
		return RTSBPRO_PATH . 'templates/multi-step-checkout/form-checkout.php';
	}


	/**
	 * Public CSS
	 *
	 * @return void
	 */
	public function enqueue_public_scripts() {
		if ( ! apply_filters( 'rtsb/module/step_checkout/show_button', true ) ) {
			return;
		}

		$opt         = $this->options;
		$dynamic_css = '';

		// Float button style.

		if ( ! empty( $opt['primary_color'] ) ) {
			$dynamic_css .= ":root {--rtsb-checkout-primary:{$opt['primary_color']};}";
		}

		if ( ! empty( $dynamic_css ) ) {
			wp_add_inline_style( 'rtsb-frontend', $dynamic_css );
		}
	}
}
