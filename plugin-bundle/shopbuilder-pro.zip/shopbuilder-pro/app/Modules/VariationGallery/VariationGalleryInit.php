<?php
/**
 * Main FilterHooks class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\VariationGallery;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SB\Modules\VariationGallery\GalleryFns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class VariationGalleryInit {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Class construction.
	 */
	private function __construct() {
		add_action( 'wp_footer', [ $this, 'slider_and_thumbnail_template_js' ] );
		add_filter( 'attachment_fields_to_edit', [ $this, 'add_media_video_meta' ], 10, 2 );
		add_filter( 'attachment_fields_to_save', [ $this, 'save_media_video_meta' ], 10, 2 );
		add_filter( 'wp_prepare_attachment_for_js', [ $this, 'update_attachment_for_js' ], 10, 3 );
		add_filter( 'rtsb/vg/slider/options', [ $this, 'slider_options' ] );
		add_filter( 'rtsb/vg/thumbnails/slider/options', [ $this, 'thumbnail_slider_options' ], 11, 2 );
		add_filter( 'rtsb/after/product/thumbnail/image', [ $this, 'after_product_thumbnail_image' ] );
		add_filter( 'rtsb/product/attachment/props', [ $this, 'product_attachment_props' ], 11, 2 );
		add_filter( 'rtsb/vg/get/main/attachment/html', [ $this, 'get_main_attachment_html' ], 11, 2 );
		add_action( 'wp_ajax_rtsb_vg_update_attachment_video_meta', [ $this, 'save_ajax_media_video_meta' ] );
	}
	/**
	 * Save attachment video meta (AJAX).
	 */
	public function save_ajax_media_video_meta() {
		// Permission check.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Permission denied.', 'shopbuilder-pro' ) );
		}
		// Validate nonce if used.
		if ( isset( $_POST['_wpnonce'] ) && ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'rtsb_vg_nonce' ) ) {
			wp_send_json_error( __( 'Security check failed.', 'shopbuilder-pro' ) );
		}
		$attachment_id = intval( $_POST['attachment_id'] ?? 0 );
		if ( ! $attachment_id ) {
			wp_send_json_error( __( 'Invalid attachment ID.', 'shopbuilder-pro' ) );
		}
		// Sanitize values.
		$video_link   = sanitize_text_field( wp_unslash( $_POST['video_link'] ?? '' ) );
		$video_width  = sanitize_text_field( wp_unslash( $_POST['video_width'] ?? '' ) );
		$video_height = sanitize_text_field( wp_unslash( $_POST['video_height'] ?? '' ) );
		// Update meta fields.
		update_post_meta( $attachment_id, 'rtsb_vg_video_link', $video_link );
		update_post_meta( $attachment_id, 'rtsb_vg_video_width', $video_width );
		update_post_meta( $attachment_id, 'rtsb_vg_video_height', $video_height );
		// Optional: clear cache or transients if used.
		$parent_id = wp_get_post_parent_id( $attachment_id );
		if ( $parent_id ) {
			GalleryFns::delete_transients( $parent_id, 'variation-images' );
		}
		wp_send_json_success(
			[
				'message'  => 'Video added successfully.',
				'hasVideo' => ! empty( $video_link ),
			]
		);
	}

	/**
	 * Converts a given YouTube or Vimeo URL into a simple embeddable URL format.
	 *
	 * This function detects whether the provided media link is from YouTube or Vimeo
	 * and transforms it into the corresponding embed URL. It supports both standard
	 * YouTube watch URLs and Vimeo video URLs. The resulting embed URL can be used
	 * directly in an iframe or other embedding contexts.
	 *
	 * @param string $media_link The original media URL (YouTube or Vimeo).
	 * @return string|null The transformed embed URL, or null if the URL is invalid or unsupported.
	 */
	public function get_simple_embed_url( $media_link ) {
		// YouTube.
		$re    = '#https?://(www\.)?youtube\.com/watch\?v=([^&]+)#';
		$subst = 'https://www.youtube.com/embed/$2?feature=oembed';
		$link  = preg_replace( $re, $subst, $media_link, 1 );

		// YouTube Shorts.
		$re    = '#https?://(www\.)?youtube\.com/shorts/([^/?]+)#';
		$subst = 'https://www.youtube.com/embed/$2?feature=oembed';
		$link  = preg_replace( $re, $subst, $link, 1 );

		// Vimeo.
		$re    = '#https?://(www\.)?vimeo\.com/([^/]+)#';
		$subst = 'https://player.vimeo.com/video/$2';
		$link  = preg_replace( $re, $subst, $link, 1 );

		// TikTok.
		$re    = '#https?://(www\.)?tiktok\.com/@[^/]+/video/([0-9]+)#';
		$subst = 'https://www.tiktok.com/embed/v2/$2';
		$link  = preg_replace( $re, $subst, $link, 1 );

		return apply_filters( 'rtwpvg_get_simple_embed_url', $link, $media_link );
	}
	/**
	 * Modify the product attachment properties before returning them.
	 *
	 * This function is hooked into the `custom_modify_attachment_props` filter
	 * to allow additional customization of the image properties.
	 *
	 * @param array $props     The original image properties.
	 * @param int   $image_id  The image attachment ID.
	 *
	 * @return array Modified image properties.
	 */
	public function product_attachment_props( $props, $image_id ) {
		$videoUrl  = trim( get_post_meta( $image_id, 'rtsb_vg_video_link', true ) ?? '' );
		$has_video = ! empty( $videoUrl );
		if ( ! $has_video ) {
			return $props;
		}
		$type                        = wp_check_filetype( $videoUrl );
		$video_width                 = trim( get_post_meta( $image_id, 'rtsb_vg_video_width', true ) ?? '' );
		$video_height                = trim( get_post_meta( $image_id, 'rtsb_vg_video_height', true ) ?? '' );
		$props['rtsb_vg_video_link'] = esc_url( $videoUrl );
		if ( ! empty( $type['type'] ) ) {
			$props['rtsb_vg_video_embed_type'] = 'video';
		} else {
			$props['rtsb_vg_video_embed_type'] = 'iframe';
			$videoUrl                          = $this->get_simple_embed_url( $videoUrl );
			if ( strpos( $videoUrl, 'youtube.com/embed' ) !== false ) {
				$videoUrl = add_query_arg(
					[
						'enablejsapi' => 1,
						'rel'         => 0,
					],
					esc_url( $videoUrl )
				);
			}
			$props['rtsb_vg_video_embed_url'] = $videoUrl;
		}
		$props['rtsb_vg_video_width']  = $video_width ?: 'auto';
		$props['rtsb_vg_video_height'] = $video_height ?: '100%';
		return $props;
	}
	/**
	 * @param array  $form_fields Fields.
	 * @param object $post Image Post Object.
	 *
	 * @return mixed
	 */
	public function add_media_video_meta( $form_fields, $post ) {
		$form_fields['rtsb_vg_video_link_label'] = [
			'tr' => "<tr><td colspan='2'><h2>" . __( 'VARIATION GALLERY VIDEO', 'shopbuilder-pro' ) . '</h2></td></tr>',
		];
		$form_fields['rtsb_vg_video_link']       = [
			'value' => get_post_meta( $post->ID, 'rtsb_vg_video_link', true ),
			'label' => __( 'Video URL', 'shopbuilder-pro' ),
			'helps' => __( 'Youtube, vimeo, Tiktok video url<br> <a href="#" class="rtsb-vg-media-video-popup">Upload your video <span class="dashicons dashicons-video-alt3"></span></a>', 'shopbuilder-pro' ),
			'input' => 'url',
		];
		$form_fields['rtsb_vg_video_width']      = [
			'label' => esc_html__( 'Width', 'shopbuilder-pro' ),
			'input' => 'text',
			'value' => get_post_meta( $post->ID, 'rtsb_vg_video_width', true ) ?: '560px',
			'helps' => esc_html__( 'Video Width. px or %. Empty for default', 'shopbuilder-pro' ),
		];

		$form_fields['rtsb_vg_video_height'] = [
			'label' => esc_html__( 'Height', 'shopbuilder-pro' ),
			'input' => 'text',
			'value' => get_post_meta( $post->ID, 'rtsb_vg_video_height', true ) ?: '314px',
			'helps' => esc_html__( 'Video Height. px or %. Empty for default', 'shopbuilder-pro' ),
		];

		return $form_fields;
	}

	/**
	 * @param object $post post object.
	 * @param array  $attachment attachment.
	 * @return object
	 */
	public function save_media_video_meta( $post, $attachment ) {
		$post_id = $post['ID'];
		if ( isset( $attachment['rtsb_vg_video_link'] ) ) {
			$rtsb_vg_video_link = trim( $attachment['rtsb_vg_video_link'] );
			update_post_meta( $post_id, 'rtsb_vg_video_link', $rtsb_vg_video_link );
		}
		if ( isset( $attachment['rtsb_vg_video_width'] ) ) {
			update_post_meta( $post_id, 'rtsb_vg_video_width', trim( $attachment['rtsb_vg_video_width'] ) );
		}
		if ( isset( $attachment['rtsb_vg_video_height'] ) ) {
			update_post_meta( $post_id, 'rtsb_vg_video_height', trim( $attachment['rtsb_vg_video_height'] ) );
		}
		return $post;
	}

	/**
	 * @param array  $response response.
	 * @param object $attachment image.
	 * @return mixed
	 */
	public function update_attachment_for_js( $response, $attachment ) {
		$id                               = absint( $attachment->ID );
		$response['rtsb_vg_video_link']   = trim( get_post_meta( $id, 'rtsb_vg_video_link', true ) ?? '' );
		$response['rtsb_vg_video_width']  = trim( get_post_meta( $id, 'rtsb_vg_video_width', true ) ?? '' );
		$response['rtsb_vg_video_height'] = trim( get_post_meta( $id, 'rtsb_vg_video_height', true ) ?? '' );
		return $response;
	}

	/**
	 * @param array $slider_options options.
	 * @return mixed
	 */
	public function slider_options( $slider_options ) {
		$effect       = GalleryFns::get_options( 'main_image_transition_effect', 'slide' );
		$autoHeight   = boolval( GalleryFns::get_options( 'adaptive_height' ) );
		$galleryStyle = GalleryFns::get_options( 'gallery_style' );
		if ( 'bottom' !== $galleryStyle ) {
			$slider_options['autoHeight'] = false;
		} else {
			$slider_options['autoHeight'] = $autoHeight;
		}
		unset( $slider_options['thumbsSelectorNoSlider'] );
		$slider_options['effect']         = $effect;
		$slider_options['thumbsSelector'] = '.rtsb-vs-thumb-slider';
		return $slider_options;
	}
	/**
	 * @param array $options options.
	 * @param array $args args.
	 * @return mixed
	 */
	public function thumbnail_slider_options( $options, $args ) {
		$col          = GalleryFns::get_options( 'thumbnails_columns' );
		$gap          = GalleryFns::get_options( 'thumbnails_gap' );
		$galleryStyle = ( $args['thumbnailsPosition'] ?? 'bottom' );
		$options      = [
			'slidesPerView' => absint( $col ?: 4 ),
			'spaceBetween'  => absint( $gap ?: 10 ),
			'direction'     => 'bottom' !== $galleryStyle ? 'vertical' : 'horizontal',
			'speed'         => 500,
			'loop'          => false,
			'navigation'    => [
				'nextEl' => '.swiper-gallery-next.rtsb-random-id-' . esc_attr( $args['randDom'] ?? '' ),
				'prevEl' => '.swiper-gallery-prev.rtsb-random-id-' . esc_attr( $args['randDom'] ?? '' ),
			],
		] + $options;
		return $options;
	}
	/**
	 * @param array $args options.
	 * @return mixed
	 */
	public function after_product_thumbnail_image( $args ) {
		$images = $args['images'] ?? [];
		$col    = $args['col'] ?? 4;
		$class  = 'rtsb-vg-swiper-nav-hide';
		if ( $col <= count( $images ) ) {
			$class = '';
		}
		?>
		<div class="swiper-nav <?php echo esc_attr( $class ); ?>">
			<!-- Navigation Arrows -->
			<div class="swiper-arrow swiper-gallery-next rtsb-random-id-<?php echo esc_attr( $args['randDom'] ?? '' ); ?>"> <?php Fns::print_html( $args['iconRight'] ?? '', true ); ?> </div>
			<div class="swiper-arrow swiper-gallery-prev rtsb-random-id-<?php echo esc_attr( $args['randDom'] ?? '' ); ?>"> <?php Fns::print_html( $args['iconLeft'] ?? '', true ); ?> </div>
		</div>
		<?php
	}
	/**
	 * Filter main gallery image HTML (can be replaced with video or custom markup).
	 *
	 * @param string $html         The default image HTML.
	 * @param array  $props          The image data array.
	 *
	 * @return string Modified HTML output.
	 */
	public function get_main_attachment_html( $html, $props ) {
		if ( ! empty( $props['rtsb_vg_video_link'] ) ) {
			ob_start();
			Fns::load_template(
				'variation-gallery/default-vg-video-template',
				[
					'props' => $props,
				],
				false,
				'',
				rtsbpro()->get_plugin_template_path()
			);
			return ob_get_clean();
		}
		return $html;
	}
	/**
	 * @return void
	 */
	public function slider_and_thumbnail_template_js() {
		wp_enqueue_script( 'underscore' );
		Fns::load_template( 'variation-gallery/vg-grid-view-template', [] );
	}
}
