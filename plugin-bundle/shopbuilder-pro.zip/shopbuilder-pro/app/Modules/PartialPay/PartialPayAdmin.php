<?php
/**
 * Partial Pay Module Admin Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\PartialPay;

use RadiusTheme\SBPRO\Traits\SingletonTrait;
use RadiusTheme\SBPRO\Modules\PartialPay\Admin\CustomFields;

defined( 'ABSPATH' ) || exit();

/**
 * Partial Pay Module Admin Class.
 */
class PartialPayAdmin {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		CustomFields::instance();
	}
}
