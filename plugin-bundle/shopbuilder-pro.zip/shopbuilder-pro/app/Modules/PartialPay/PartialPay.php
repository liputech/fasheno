<?php
/**
 * Partial Pay Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\PartialPay;

use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Partial Pay Module Class.
 */
class PartialPay {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		PartialPayCommon::instance();
		PartialPayFrontend::instance();

		if ( is_admin() ) {
			PartialPayAdmin::instance();
		}
	}
}
