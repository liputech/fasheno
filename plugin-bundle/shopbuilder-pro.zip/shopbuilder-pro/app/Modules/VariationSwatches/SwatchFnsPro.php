<?php
/**
 * Sticky add-to-cart Functions Class.
 *
 * @package Rse\SB
 */

namespace RadiusTheme\SBPRO\Modules\VariationSwatches;

defined( 'ABSPATH' ) || exit();

/**
 * Sticky add-to-cart Functions Class.
 */
class SwatchFnsPro {
	/**
	 * Attributes Array.
	 *
	 * @param array $attributes Attributes.
	 * @return array
	 */
	public static function get_product_attributes_array( $attributes ) {
		if ( empty( $attributes ) ) {
			return [];
		}
		$attrs = [];
		foreach ( $attributes as $key => $value ) {
			$attrs[ $key ] = wc_attribute_label( $key );
		}
		return $attrs;
	}
}
