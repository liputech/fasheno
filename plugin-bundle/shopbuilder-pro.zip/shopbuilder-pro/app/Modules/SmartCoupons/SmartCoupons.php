<?php
/**
 * Smart Coupons Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\SmartCoupons;

use RadiusTheme\SBPRO\Helpers\FnsPro;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Smart Coupons Module Class.
 */
class SmartCoupons {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		SmartCouponsFrontEnd::instance();
		CouponCategories::instance();
		$this->run_cron();
		if ( is_admin() ) {
			SmartCouponsAdmin::instance();
		}
		add_action( 'rtsb_smart_coupon_csv_deletion', [ $this, 'delete_old_files' ] );
	}
	/**
	 * Run Cron Function
	 *
	 * @return void
	 */
	public function run_cron() {
		$action = 'rtsb_smart_coupon_csv_deletion';
		if ( ! wp_next_scheduled( $action ) ) {
			// ‘hourly’, ‘twicedaily’, and ‘daily’.
			wp_schedule_event( time(), 'weekly', $action );
			FnsPro::add_to_scheduled_hook_list( $action );
		}
	}
	/**
	 * Delete files older than 5 days.
	 */
	public function delete_old_files() {
		$upload_dir = wp_upload_dir();
		$csv_dir    = trailingslashit( $upload_dir['basedir'] ) . 'shopbuilder_uploads/coupon-exports';
		if ( ! is_dir( $csv_dir ) ) {
			return;
		}
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		$wp_filesystem->delete( $csv_dir, true ); // recursive.
	}
}
