<?php
/**
 * Product Add-Ons Module Admin Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\AddOns;

use RadiusTheme\SBPRO\Traits\SingletonTrait;
use RadiusTheme\SBPRO\Modules\AddOns\Admin\AdminAjax;
use RadiusTheme\SBPRO\Modules\AddOns\Admin\CustomFields;

defined( 'ABSPATH' ) || exit();

/**
 * Product Add-Ons Module Class.
 */
class AddOnsAdmin {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		CustomFields::instance();
		AdminAjax::instance();
	}
}
