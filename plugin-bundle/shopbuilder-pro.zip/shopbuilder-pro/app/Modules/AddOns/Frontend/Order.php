<?php
/**
 * Product AddOns Order Class.
 *
 * @package RadiusTheme\SBPRO
 */

namespace RadiusTheme\SBPRO\Modules\AddOns\Frontend;

use WC_Order_Item_Product;
use RadiusTheme\SBPRO\Traits\SingletonTrait;
use RadiusTheme\SBPRO\Modules\AddOns\AddOnsFns;

defined( 'ABSPATH' ) || exit();

/**
 * Product AddOns Order Class.
 */
class Order {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		/**
		 * Actions.
		 */
		add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'add_addons_meta' ], 10, 3 );

		/**
		 * Filters.
		 */
		add_filter( 'woocommerce_hidden_order_itemmeta', [ $this, 'hide_admin_meta' ], 10, 1 );
		add_filter( 'woocommerce_order_item_get_formatted_meta_data', [ $this, 'hide_addons_in_order_email' ], 10, 2 );
	}

	/**
	 * Adds product addons meta-data to the cart item.
	 *
	 * @param object $item      The cart item object to which meta-data is being added.
	 * @param string $cart_key  The unique identifier for the cart item.
	 * @param array  $values    The cart item values, including the product addons.
	 *
	 * @return void
	 */
	public function add_addons_meta( $item, $cart_key, $values ) {
		if ( empty( $values['rtsb_product_addons'] ) ) {
			return;
		}

		$total_price = 0;

		foreach ( $values['rtsb_product_addons'] as $addon_group ) {
			if ( empty( $addon_group['fields'] ) ) {
				continue;
			}

			foreach ( $addon_group['fields'] as $addon ) {
				$addon_price = 0;

				if ( is_array( $addon['value'] ) ) {
					$value_array = [];

					foreach ( $addon['value'] as $index => $single_value ) {
						$price         = is_array( $addon['price'] ) ? ( $addon['price'][ $index ] ?? 0 ) : $addon['price'];
						$addon_price  += floatval( $price );
						$value_array[] = $single_value . ( $price > 0 ? ' (' . wc_price( Product::convert_currency( $price ) ) . ')' : '' );
					}

					$value = implode( ', ', $value_array );
				} else {
					$addon_price = $addon['price'] ?? 0;
					$value       = $addon['value'];

					if ( $addon_price ) {
						$value .= ' (' . wc_price( Product::convert_currency( $addon_price ) ) . ')';
					}
				}

				$item->add_meta_data( $addon['label'], $value );

				$total_price += floatval( $addon_price );
			}
		}

		if ( $total_price > 0 ) {
			$item->add_meta_data( '_rtsb_addons_price', wc_price( floatval( $total_price ) ) );
		}
	}

	/**
	 * Hides the addon price meta-data from the admin order details view.
	 *
	 * @param array $hidden_meta_data Array of meta-data keys that should be hidden.
	 *
	 * @return array
	 */
	public function hide_admin_meta( $hidden_meta_data ) {
		$hidden_meta_data[] = '_rtsb_addons_price';

		return $hidden_meta_data;
	}

	/**
	 * Hide addons in order email metadata.
	 *
	 * @param array  $formatted_meta The formatted metadata array.
	 * @param object $order_item The order item object.
	 *
	 * @return array
	 */
	public function hide_addons_in_order_email( $formatted_meta, $order_item ) {
		if ( 'on' === AddOnsFns::get_add_ons_settings_data()['show_in_order_email'] ) {
			return $formatted_meta;
		}

		if ( did_action( 'woocommerce_email_order_details' ) ) {
			if ( ! $order_item instanceof WC_Order_Item_Product ) {
				return $formatted_meta;
			}

			$product_id     = $order_item->get_product_id();
			$product_addons = AddOnsFns::get_addon_groups( $product_id );
			$addon_labels   = [];

			foreach ( $product_addons as $addon_group ) {
				foreach ( $addon_group['inputs'] as $input ) {
					$addon_labels[] = $input['label'];
				}
			}

			if ( empty( $addon_labels ) ) {
				return $formatted_meta;
			}

			foreach ( $formatted_meta as $meta_id => $meta ) {
				if ( in_array( $meta->key, $addon_labels, true ) ) {
					unset( $formatted_meta[ $meta_id ] );
				}
			}
		}

		return $formatted_meta;
	}
}
