<?php
/**
 * Product Add-Ons Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\AddOns;

use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Product Add-Ons Module Class.
 */
class AddOns {
	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		AddOnsFrontEnd::instance();

		if ( is_admin() ) {
			AddOnsAdmin::instance();
		}
	}
}
