<?php
/**
 * PDF Invoice Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\PdfInvoice;

use WC_Order;
use Dompdf\Dompdf;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Back-order Module Class.
 */
class InvoiceInit {

	/**
	 * Singleton Trait.
	 */
	use SingletonTrait;

	/**
	 * Module Class Constructor.
	 */
	private function __construct() {
		$this->init();
		OrderMeta::instance();
	}
	/**
	 * @return void
	 */
	public function init() {
		add_action( 'template_redirect', [ $this, 'handle_download_request' ] );
		add_action( 'woocommerce_new_order', [ $this, 'save_order_meta' ], 12, 1 );
		add_filter( 'woocommerce_my_account_my_orders_actions', [ $this, 'add_invoice_download_link' ], 10, 2 );
		add_filter( 'woocommerce_email_attachments', [ $this, 'attach_invoice_to_order_email' ], 10, 3 );
		// Normal flow: delete when order marked completed.
		add_action( 'woocommerce_order_status_completed', [ $this, 'delete_pdf' ], 20 );
		// Resent emails: delete after resend.
		add_action( 'woocommerce_after_resend_order_email', [ $this, 'after_resend' ], 10, 2 );
		add_action( 'wp_footer', [ $this, 'add_invoice_target_blank_js' ] );
		/**
		 * Add add_filter( 'woocommerce_currency_symbol', [ $this, 'use_currency_font' ], 999, 1 );
		 */
	}

	/**
	 * Use currency symbol font (when enabled in options)
	 *
	 * @param string $currency_symbol Currency symbol.
	 *
	 * @return string Currency symbol
	 */
	public function use_currency_font( string $currency_symbol ) {
		$currency_symbol = sprintf( '<span class="rtsb-currency-symbol">%s</span>', $currency_symbol );
		return $currency_symbol;
	}

	/**
	 * Delete the PDF file for a given order.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function delete_pdf( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		$file_path = $order->get_meta( '_rtsb_invoice_pdf_path' );
		if ( $file_path && $wp_filesystem->exists( $file_path ) ) {
			$wp_filesystem->delete( $file_path ); // Delete file.
			$order->delete_meta_data( '_rtsb_invoice_pdf_path' );
			$order->save();
		}
	}

	/**
	 * Handle resending emails (only delete for specific email types).
	 *
	 * @param WC_Order $order  The order object.
	 * @param string   $action The email ID (e.g. customer_completed_order).
	 * @return void
	 */
	public function after_resend( $order, $action ) {
		if ( in_array( $action, [ 'customer_completed_order', 'customer_processing_order', 'customer_invoice' ], true ) ) {
			$this->delete_pdf( $order->get_id() );
		}
	}
	/**
	 * Attach the PDF invoice to WooCommerce order emails.
	 *
	 * This function generates the PDF invoice for the given order,
	 * saves it in the uploads directory with a clean filename, and
	 * attaches it to specific WooCommerce emails such as
	 * 'customer_completed_order' and 'customer_invoice'.
	 *
	 * @param array    $attachments Existing array of email attachment file paths.
	 * @param string   $email_id    ID of the WooCommerce email being sent.
	 * @param WC_Order $order       The WooCommerce order object.
	 * @return array Updated array of email attachment file paths.
	 */
	public function attach_invoice_to_order_email( $attachments, $email_id, $order ) {
		if ( ! $order instanceof WC_Order ) {
			return $attachments;
		}
		// Only attach for specific emails.
		if ( ! in_array( $email_id, [ 'customer_processing_order', 'customer_completed_order', 'customer_invoice' ], true ) ) {
			return $attachments;
		}
		// Generate PDF using your GenerateInvoice class.
		$invoice   = new GenerateInvoice( $order );
		$file_path = $invoice->generate_and_save_pdf();
		if ( $file_path ) {
			$attachments[] = $file_path;
		}
		return $attachments;
	}
	/**
	 * Adds a "PDF Invoice" download action to the My Account > Orders list.
	 *
	 * This hook runs on the 'woocommerce_my_account_my_orders_actions' filter and
	 * appends a custom action for downloading a PDF invoice if the order status is
	 * 'completed' or 'processing'.
	 *
	 * @param array     $actions Existing order actions.
	 * @param \WC_Order $order   WooCommerce order object.
	 * @return array Modified list of order actions.
	 */
	public function add_invoice_download_link( $actions, $order ) {
		if ( ! InvoiceFns::should_display_pdf_button( $order ) ) {
			return $actions;
		}
		$url                     = add_query_arg(
			[
				'download_invoice' => $order->get_id(),
				'_wpnonce'         => wp_create_nonce( 'download_invoice_' . $order->get_id() ),
			],
			wc_get_account_endpoint_url( 'orders' )
		);
		$actions['rtsb_invoice'] = [
			'name' => esc_html__( 'Download Invoice', 'shopbuilder-pro' ),
			'url'  => esc_url( $url ),
		];
		return $actions;
	}

	/**
	 * Save custom meta to order after it's created.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 * @return void
	 */
	public function save_order_meta( $order_id ) {
		$order     = wc_get_order( $order_id );
		$options   = InvoiceFns::get_options();
		$attach_to = $options['pdf_button_show'];
		$attach_to = ! empty( $attach_to ) && is_array( $attach_to ) ? $attach_to : [];
		if ( ! in_array( $order->get_status(), $attach_to, true ) ) {
			return;
		}
		$generate_invoice_number = ! empty( $options['generate_invoice_number'] ) ? $options['generate_invoice_number'] : false;
		if ( ! $generate_invoice_number ) {
			return;
		}
		$invoice = new GenerateInvoice( $order );
		$invoice->generate_invoice_number();
	}

	/**
	 * Handles the download request for the PDF invoice.
	 *
	 * Verifies the nonce and user authorization before generating
	 * the PDF for the specified order.
	 */
	public function handle_download_request() {
		if ( is_admin() ) {
			return;
		}
		if ( isset( $_GET['download_invoice'], $_GET['_wpnonce'] ) ) {
			$download_invoice = absint( wp_unslash( $_GET['download_invoice'] ) );
			$nonce            = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) );
			if ( wp_verify_nonce( $nonce, 'download_invoice_' . $download_invoice ) ) {
				$order = wc_get_order( $download_invoice );
				if ( ! $order || (int) $order->get_user_id() !== get_current_user_id() ) {
					wp_die( esc_html__( 'Unauthorized access.', 'shopbuilder-pro' ) );
				}
				$invoice = new GenerateInvoice( $order );
				$invoice->generate_pdf();
				exit;
			}
		}
	}

	/**
	 * Add Target Blank Link to Invoice Button
	 *
	 * @return void
	 */
	public function add_invoice_target_blank_js() {
		$isButton = is_account_page() || is_order_received_page();
		if ( ! $isButton ) {
			return;
		}
		$options  = InvoiceFns::get_options();
		$pdf_view = ! empty( $options['pdf_view'] ) ? $options['pdf_view'] : 'download';
		if ( 'new_tab' === $pdf_view ) {
			?>
			<script>
				document.addEventListener('DOMContentLoaded', function() {
					document.querySelectorAll('.woocommerce-button.rtsb_invoice').forEach(function(link) {
						link.setAttribute('target', '_blank');
					});
				});
			</script>
			<?php
		}
	}
}
