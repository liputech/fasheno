<?php
/**
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\PdfInvoice;

use RadiusTheme\SB\Helpers\Fns;
use WC_Order;

defined( 'ABSPATH' ) || exit();

/**
 * Main FilterHooks class.
 */
class InvoiceFns {
	/**
	 * @param string       $key Default Attribute.
	 * @param array|string $default Default Attribute.
	 * @return array|string
	 */
	public static function get_options( $key = null, $default = '' ) {
		$options = Fns::get_options( 'modules', 'pdf_invoice' );
		if ( $key ) {
			if ( isset( $options[ $key ] ) ) {
				return $options[ $key ];
			} else {
				return $default;
			}
		}
		return $options;
	}
	/**
	 * @return array
	 */
	public static function settings_field() {
		$fields = [
			'header_settings'         => [
				'id'    => 'header_settings',
				'type'  => 'title',
				'label' => esc_html__( 'Header', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'pdf_logo'                => [
				'id'    => 'pdf_logo',
				'type'  => 'fileupload',
				'label' => esc_html__( 'Upload Logo', 'shopbuilder-pro' ),
				'help'  => esc_html__( 'Please upload your custom image logo. Only .jpg, .jpeg and .png files are allowed', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'logo_width'              => [
				'id'    => 'logo_width',
				'label' => esc_html__( 'Logo Width', 'shopbuilder-pro' ),
				'type'  => 'slider',
				'min'   => 70,
				'max'   => 300,
				'unit'  => 'px',
				'value' => 100,
				'tab'   => 'general',
			],
			'company_name'            => [
				'id'          => 'company_name',
				'label'       => __( 'Store Name', 'shopbuilder-pro' ),
				'type'        => 'text',
				'placeholder' => esc_html__( 'Ex. 15', 'shopbuilder-pro' ),
				'help'        => esc_html__( 'Enter the store name.', 'shopbuilder-pro' ),
				'tab'         => 'general',
			],
			'office_address'          => [
				'id'    => 'office_address',
				'label' => __( 'Store Address', 'shopbuilder-pro' ),
				'type'  => 'textarea',
				'help'  => __( 'Shop Address.', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'invoice_settings'        => [
				'id'    => 'invoice_settings',
				'type'  => 'title',
				'label' => esc_html__( 'Invoice', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'template_layout'         => [
				'id'      => 'template_layout',
				'label'   => esc_html__( 'Template Layout', 'shopbuilder-pro' ),
				'help'    => esc_html__( 'Select the PDF Layout. You can override the default PDF layout by copying the template to your theme and customizing it.', 'shopbuilder-pro' ),
				'type'    => 'image_select',
				'value'   => 'layout1',
				'tab'     => 'general',
				'options' => [
					'layout1' => [
						'label' => esc_html__( 'Layout 1', 'shopbuilder-pro' ),
						'url'   => esc_url( rtsbpro()->get_assets_uri( 'images/pdf-layout/pdf-layout-1-min.png' ) ),
					],
					'layout2' => [
						'label' => esc_html__( 'Layout 2', 'shopbuilder-pro' ),
						'url'   => esc_url( rtsbpro()->get_assets_uri( 'images/pdf-layout/pdf-layout-2-min.png' ) ),
					],
					'layout3' => [
						'label' => esc_html__( 'Layout 3', 'shopbuilder-pro' ),
						'url'   => esc_url( rtsbpro()->get_assets_uri( 'images/pdf-layout/pdf-layout-3-min.png' ) ),
					],
				],

			],

			'paper_size'              => [
				'id'      => 'paper_size',
				'type'    => 'select',
				'value'   => 'a4',
				'label'   => esc_html__( 'Paper Size', 'shopbuilder-pro' ),
				'help'    => esc_html__( 'Select the type of offer.', 'shopbuilder-pro' ),
				'options' => [
					'a4'     => esc_html__( 'A4', 'shopbuilder-pro' ),
					'letter' => esc_html__( 'Letter', 'shopbuilder-pro' ),
				],
				'tab'     => 'general',
			],
			'generate_invoice_number' => [
				'id'    => 'generate_invoice_number',
				'type'  => 'switch',
				'label' => esc_html__( 'Generate Invoice Number', 'shopbuilder-pro' ),
				'value' => 'on',
				'tab'   => 'general',
			],
			'invoice_start_number'    => [
				'id'         => 'invoice_start_number',
				'label'      => __( 'Invoice Starting Number', 'shopbuilder-pro' ),
				'type'       => 'number',
				'value'      => 1,
				'tab'        => 'general',
				'dependency' => [
					'rules' => [
						[
							'item'     => 'modules.pdf_invoice.generate_invoice_number',
							'value'    => 'on',
							'operator' => '==',
						],
					],
				],
			],
			'invoice_prefix'          => [
				'id'         => 'invoice_prefix',
				'label'      => __( 'Invoice Prefix', 'shopbuilder-pro' ),
				'type'       => 'text',
				'tab'        => 'general',
				'dependency' => [
					'rules' => [
						[
							'item'     => 'modules.pdf_invoice.generate_invoice_number',
							'value'    => 'on',
							'operator' => '==',
						],
					],
				],
			],
			'invoice_suffix'          => [
				'id'         => 'invoice_suffix',
				'label'      => __( 'Invoice Suffix', 'shopbuilder-pro' ),
				'type'       => 'text',
				'tab'        => 'general',
				'dependency' => [
					'rules' => [
						[
							'item'     => 'modules.pdf_invoice.generate_invoice_number',
							'value'    => 'on',
							'operator' => '==',
						],
					],
				],
			],
			'display_shipping'        => [
				'id'    => 'display_shipping',
				'type'  => 'switch',
				'label' => esc_html__( 'Show Shipping Address', 'shopbuilder-pro' ),
				'value' => 'on',
				'tab'   => 'general',
			],
			'customer_note'           => [
				'id'    => 'customer_note',
				'type'  => 'switch',
				'label' => esc_html__( 'Show Customer Note', 'shopbuilder-pro' ),
				'value' => 'on',
				'tab'   => 'general',
			],

			'pdf_button_show'         => [
				'id'          => 'pdf_button_show',
				'label'       => esc_html__( 'PDF Button for Order Statuses', 'shopbuilder-pro' ),
				'help'        => esc_html__( 'Choose the order statuses where the PDF Invoice button will be visible.', 'shopbuilder-pro' ),
				'type'        => 'checkbox',
				'orientation' => 'vertical',
				'value'       => array_keys( wc_get_order_statuses() ),
				'options'     => array_map(
					function ( $status_key, $status_label ) {
						return [
							'value' => str_replace( 'wc-', '', $status_key ),
							'label' => $status_label,
						];
					},
					array_keys( wc_get_order_statuses() ),
					wc_get_order_statuses()
				),
				'tab'         => 'general',
			],
			'pdf_view'                => [
				'id'      => 'pdf_view',
				'type'    => 'select',
				'value'   => 'download',
				'label'   => esc_html__( 'How do you want to view the PDF?', 'shopbuilder-pro' ),
				'help'    => esc_html__( 'Select the type of offer.', 'shopbuilder-pro' ),
				'options' => [
					'download' => esc_html__( 'Download the PDF', 'shopbuilder-pro' ),
					'new_tab'  => esc_html__( 'Open the PDF in a new browser tab/window', 'shopbuilder-pro' ),
				],
				'tab'     => 'general',
			],
			'footer_settings'         => [
				'id'    => 'footer_settings',
				'type'  => 'title',
				'label' => esc_html__( 'Footer', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'footer_text'             => [
				'id'    => 'footer_text',
				'label' => __( 'Footer Text', 'shopbuilder-pro' ),
				'type'  => 'textarea',
				'help'  => __( 'This text will be shown at the bottom of the invoice PDF. If you want to enable linking then use https//: Or www', 'shopbuilder-pro' ),
				'tab'   => 'general',
			],
			'add_page_number'         => [
				'id'    => 'add_page_number',
				'type'  => 'switch',
				'label' => esc_html__( 'PDF Page Numbers', 'shopbuilder-pro' ),
				'help'  => __( 'Show page numbers automatically when the PDF has more than one page.', 'shopbuilder-pro' ),
				'value' => 'on',
				'tab'   => 'general',
			],
			'body_font_size'          => [
				'id'    => 'body_font_size',
				'label' => esc_html__( 'PDF Body Font Size', 'shopbuilder-pro' ),
				'type'  => 'slider',
				'min'   => 10,
				'max'   => 30,
				'unit'  => 'px',
				'value' => 14,
				'tab'   => 'styles',
			],
			'heading_bg'              => [
				'id'    => 'heading_bg',
				'type'  => 'color',
				'value' => '#111111',
				'label' => esc_html__( 'Heading Background', 'shopbuilder-pro' ),
				'tab'   => 'styles',
			],
		];
		return $fields;
	}
	/**
	 * Determine whether the PDF invoice button should be displayed for the given order.
	 *
	 * @param WC_Order $order The WooCommerce order object.
	 * @return bool True if the PDF button should be shown for this order status, false otherwise.
	 */
	public static function should_display_pdf_button( WC_Order $order ) {
		$options   = self::get_options();
		$attach_to = $options['pdf_button_show'];
		$attach_to = ! empty( $attach_to ) && is_array( $attach_to ) ? $attach_to : [];
		return in_array( $order->get_status(), $attach_to, true );
	}
}
