<?php
namespace RadiusTheme\SBPRO\Modules\PdfInvoice;

use RadiusTheme\SB\Helpers\Fns;
use WC_Order;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit;

/**
 * OrderMeta class.
 */
class OrderMeta {
	/**
	 * Singleton instance.
	 *
	 * @var OrderMeta
	 */
	use SingletonTrait;

	/**
	 * Constructor.
	 *
	 * Hooks into WooCommerce and WordPress actions to register meta boxes.
	 */
	private function __construct() {
		add_action( 'add_meta_boxes', [ $this, 'add_invoice_metabox' ] );
		add_action( 'admin_init', [ $this, 'handle_download_request' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_pdf_invoice_admin_js' ] );
		// Add column.
		add_filter( 'woocommerce_shop_order_list_table_columns', [ $this, 'add_column' ] );
		// Render column content.
		add_action( 'woocommerce_shop_order_list_table_custom_column', [ $this, 'render_column' ], 20, 2 );

		add_action( 'wp_ajax_rtsb_send_pdf_invoice_email', [ $this, 'send_pdf_invoice_email' ] );
		add_action( 'wp_ajax_rtsb_generate_invoice_number', [ $this, 'generate_invoice_number' ] );
	}
	/**
	 * Invoice Number Generated.
	 */
	public function generate_invoice_number() {
		if ( ! wp_verify_nonce( Fns::get_nonce(), rtsb()->nonceText ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}
		if ( ! isset( $_POST['order_id'] ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}
		$order_id = absint( $_POST['order_id'] );
		$order    = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}
		$invoice       = new GenerateInvoice( $order );
		$invoiceNumber = $invoice->generate_invoice_number();
		if ( ! empty( $invoiceNumber ) ) {
			wp_send_json_success( [ 'message' => esc_html__( 'Invoice Generated! Invoice Number: ', 'shopbuilder-pro' ) . esc_html( $invoiceNumber ) ] );
		} else {
			wp_send_json_error( [ 'message' => esc_html__( 'Invoice not Generated!', 'shopbuilder-pro' ) ] );
		}
	}
	/**
	 * Send PDF invoice email
	 */
	public function send_pdf_invoice_email() {
		if ( ! wp_verify_nonce( Fns::get_nonce(), rtsb()->nonceText ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}
		if ( ! isset( $_POST['order_id'] ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}
		$order_id = absint( $_POST['order_id'] );
		$order    = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid Order', 'shopbuilder-pro' ) ] );
		}

		$invoice = new GenerateInvoice( $order );
		$send    = $invoice->send_email_pdf();
		if ( $send ) {
			wp_send_json_success( [ 'message' => esc_html__( 'Invoice send!', 'shopbuilder-pro' ) ] );
		} else {
			wp_send_json_error( [ 'message' => esc_html__( 'Invoice not send!', 'shopbuilder-pro' ) ] );
		}
	}

	/**
	 * Pdf Invoice Admin JS.
	 */
	public function enqueue_pdf_invoice_admin_js() {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}
		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : RTSBPRO_VERSION;
		if ( in_array( 'sitepress-multilingual-cms/sitepress.php', get_option( 'active_plugins' ), true ) ) {
			$ajaxurl = admin_url( 'admin-ajax.php?lang=' . ICL_LANGUAGE_CODE );
		} else {
			$ajaxurl = admin_url( 'admin-ajax.php' );
		}
		wp_register_script( 'rtsb-pdf-invoice-admin', rtsbpro()->get_assets_uri( 'js/backend/pdf-invoice-admin.js' ), [ 'jquery' ], $version, true );
		// Gift Card Admin Params.
		wp_localize_script(
			'rtsb-pdf-invoice-admin',
			'rtsbPDFInvoiceAdminParam',
			[
				'ajaxUrl'            => esc_url( $ajaxurl ),
				'confirmMessage'     => esc_html__( 'Are you sure you want to send PDF invoice email?', 'shopbuilder-pro' ),
				'afterSendMessage'   => esc_html__( '✅ PDF invoice email sent successfully.', 'shopbuilder-pro' ),
				'afterInvoiceNumber' => esc_html__( '✅ Invoice Number Generated Successfully.', 'shopbuilder-pro' ),
				rtsb()->nonceId      => wp_create_nonce( rtsb()->nonceText ),
			]
		);
	}
	/**
	 * Handles the download request for the PDF invoice.
	 *
	 * Verifies the nonce and user authorization before generating
	 * the PDF for the specified order.
	 */
	public function handle_download_request() {
		if ( isset( $_GET['download_invoice'], $_GET['_wpnonce'] ) ) {
			$download_invoice = absint( wp_unslash( $_GET['download_invoice'] ) );
			$nonce            = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) );

			if ( wp_verify_nonce( $nonce, 'download_invoice_' . $download_invoice ) ) {
				$order = wc_get_order( $download_invoice );

				if ( ! $order || (int) $order->get_user_id() !== get_current_user_id() ) {
					wp_die( esc_html__( 'Unauthorized access.', 'shopbuilder-pro' ) );
				}
				$invoice = new GenerateInvoice( $order );
				$invoice->generate_pdf( 'download' );
				exit;
			}
		}
	}

	/**
	 * Add legacy meta box for CPT-based orders.
	 *
	 * This function adds a custom meta box titled "PDF Invoice data"
	 * to the WooCommerce order edit screen.
	 * It is only applicable when orders are stored as posts (non-HPOS).
	 *
	 * @return void
	 */
	public function add_invoice_metabox() {
		$current_screen = get_current_screen();
		$screen_id      = $current_screen->id;
		if ( 'woocommerce_page_wc-orders' !== $screen_id ) {
			return;
		}
		add_meta_box(
			'rtsb-pdf-invoice',
			__( 'PDF Invoice Data', 'shopbuilder-pro' ),
			[ $this, 'render_invoice_section' ],
			'woocommerce_page_wc-orders',
			'side',
			'high'
		);
	}

	/**
	 * Render the invoice section inside the order edit page.
	 *
	 * @param WC_Order|mixed $order Order object if available, otherwise the current post.
	 *
	 * @return void
	 */
	public function render_invoice_section( $order ) {

		if ( ! $order ) {
			echo '<p>' . esc_html__( 'Order not found.', 'shopbuilder-pro' ) . '</p>';
			return;
		}

		wp_enqueue_script( 'rtsb-pdf-invoice-admin' );
		$download_url = add_query_arg(
			[
				'download_invoice' => $order->get_id(),
				'_wpnonce'         => wp_create_nonce( 'download_invoice_' . $order->get_id() ),
			],
			admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order->get_id() )
		);

		$invoiceNumber = $order->get_meta( '_rtsb_invoice_id' );
		if ( ! empty( $invoiceNumber ) ) {
			$invoice_date = $order->get_meta( '_rtsb_invoice_date' );
			echo '<p>' . esc_html__( 'Invoice Number: ', 'shopbuilder-pro' ) . '<code>' . esc_html( $invoiceNumber ) . '</code></p>';
			if ( ! empty( $invoice_date ) ) {
				echo '<p>' . esc_html__( 'Invoice Date: ', 'shopbuilder-pro' ) . '<code>' . esc_html( $invoice_date ) . '</code></p>';
			}
		} else {
			echo '<p><a id="rtsb_generate_invoice_number" data-order-id="' . absint( $order->get_id() ) . '" href="#" class="button button-secondary" >' . esc_html__( 'Generate Invoice Number', 'shopbuilder-pro' ) . '</a></p>';
		}
		echo '<p><a href="' . esc_url( $download_url ) . '" class="button button-secondary" >' . esc_html__( 'Download PDF Invoice', 'shopbuilder-pro' ) . '</a></p>';
		echo '<p><a id="rtsb_send_pdf_invoice_to_customer" data-order-id="' . absint( $order->get_id() ) . '" href="#" class="button button-primary" >' . esc_html__( 'Send PDF Invoice Email to Customer', 'shopbuilder-pro' ) . '</a></p>';
		echo '<p><span class="pdf-invoice-send-message" style="margin: 10px 0;"></span></p>';
	}

	/**
	 * Add the custom column after Order Date.
	 *
	 * @param array $columns Array of existing columns.
	 * @return array
	 */
	public function add_column( $columns ) {
		$new_columns = [];
		foreach ( $columns as $key => $label ) {
			$new_columns[ $key ] = $label;
			if ( 'order_number' === $key ) {
				$new_columns['rtsb_invoice_number'] = esc_html__( 'Invoice Number', 'shopbuilder-pro' );
				$new_columns['rtsb_invoice_date']   = esc_html__( 'Invoice Date', 'shopbuilder-pro' );
			}
		}

		return $new_columns;
	}

	/**
	 * Display the custom column content.
	 *
	 * @param string        $column Column ID.
	 * @param WC_Order|bool $order  The order object.
	 */
	public function render_column( $column, $order ) {
		if ( 'rtsb_invoice_number' === $column ) {
			$invoice_number = $order->get_meta( '_rtsb_invoice_id' );
			if ( $invoice_number ) {
				echo esc_html( $invoice_number );
			} else {
				echo '<span style="color:#aaa;">—</span>';
			}
		}
		if ( 'rtsb_invoice_date' === $column ) {
			$invoice_date = $order->get_meta( '_rtsb_invoice_date' );
			if ( $invoice_date ) {
				echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $invoice_date ) ) );
			} else {
				echo '<span style="color:#aaa;">' . esc_html__( '—', 'shopbuilder-pro' ) . '</span>';
			}
		}
	}
}
