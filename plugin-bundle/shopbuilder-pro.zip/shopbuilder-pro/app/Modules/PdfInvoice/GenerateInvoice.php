<?php
/**
 * PDF Invoice Module Class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Modules\PdfInvoice;

use Dompdf\FontMetrics;
use WC_Order;
use Dompdf\Dompdf;
use Dompdf\Options;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;

defined( 'ABSPATH' ) || exit();

/**
 * Back-order Module Class.
 */
class GenerateInvoice {

	/**
	 * @var WC_Order $order.
	 */
	public $order;
	/**
	 * @param WC_Order $order wc order.
	 */
	public function __construct( WC_Order $order ) {
		$this->order = $order;
	}
	/**
	 * Get the language attributes for the document.
	 *
	 * @return string
	 */
	public function get_language_attributes() {
		return apply_filters( 'rtsb/pdf/invoice/document/language/attributes', get_language_attributes(), $this );
	}

	/**
	 * Print the language attributes for the document.
	 *
	 * @return void
	 */
	public function language_attributes() {
		echo esc_html( $this->get_language_attributes() );
	}
	/**
	 * Output template styles
	 */
	public function template_styles() {
		$css_file_path = __DIR__ . '/templates/style.css';
		$css           = file_get_contents( $css_file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$css           = apply_filters( 'rtsb/pdf/invoice/template/styles', $css, $this );
		Fns::print_html( $css, true );
	}
	/**
	 * Output template styles
	 */
	public function template_custom_styles() {
		$data = [];
		Fns::load_template( 'pdf-invoice/style', $data, false, '', rtsbpro()->get_plugin_template_path() );
	}

	/**
	 * Get the chroot paths for Dompdf.
	 *
	 * @return array
	 */
	private function get_chroot_paths(): array {
		$chroot = [ WP_CONTENT_DIR ]; // default.

		$upload_dir = wp_upload_dir();
		$custom_dir = trailingslashit( $upload_dir['basedir'] ) . 'shopbuilder_uploads/invoices';
		$tmp_base   = trailingslashit( $custom_dir ) . 'dompdf-tmp';

		if ( ! empty( $custom_dir ) ) {
			$chroot[] = $custom_dir;
		}
		if ( ! empty( $tmp_base ) ) {
			$chroot[] = $tmp_base;
		}
		return apply_filters( 'rtsb/pdf/invoice/dompdf/chroot', $chroot );
	}
	/**
	 * Get all fonts from the plugin (excluding base path!)
	 *
	 * @return array
	 */
	public function get_plugin_fonts() {
		$pluginFonts = [
			'open sans'   => [
				'normal'      => 'OpenSans-Normal',
				'bold'        => 'OpenSans-Bold',
				'italic'      => 'OpenSans-Italic',
				'bold_italic' => 'OpenSans-BoldItalic',
			],
			'segoe'       => [
				'normal'      => 'Segoe-Normal',
				'bold'        => 'Segoe-Bold',
				'italic'      => 'Segoe-Italic',
				'bold_italic' => 'Segoe-BoldItalic',
			],
			'roboto slab' => [
				'normal'      => 'RobotoSlab-Normal',
				'bold'        => 'RobotoSlab-Bold',
				'italic'      => 'RobotoSlab-Italic',
				'bold_italic' => 'RobotoSlab-BoldItalic',
			],
			'currencies'  => [
				'normal'      => 'currencies',
				'bold'        => 'currencies',
				'italic'      => 'currencies',
				'bold_italic' => 'currencies',
			],
		];
		return apply_filters( 'rtsb/pdf/invoice/fonts/list', $pluginFonts );
	}

	/**
	 * Copy plugin fonts to the persistent Dompdf font directory.
	 *
	 * @param string $sourceDir Source fonts directory inside the plugin.
	 * @param string $destDir   Destination persistent font directory.
	 * @return void
	 */
	private function register_plugin_fonts( string $sourceDir, string $destDir ) {
		if ( ! is_dir( $sourceDir ) ) {
			return;
		}
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;

		if ( ! $wp_filesystem->is_dir( $destDir ) ) {
			$wp_filesystem->mkdir( $destDir, FS_CHMOD_DIR );
		}
		$jsonPath   = trailingslashit( $destDir ) . 'installed-fonts.json';
		$extensions = [ '.ttf', '.ufm', '.afm' ];
		// Start with existing Dompdf fonts if installed-fonts.json exists.
		$installedFonts = [];
		if ( $wp_filesystem->exists( $jsonPath ) ) {
			$installedFonts = json_decode( $wp_filesystem->get_contents( $jsonPath ), true );
		}
		$update      = false;
		$pluginFonts = $this->get_plugin_fonts();
		foreach ( $pluginFonts as $fontName => $styles ) {
			if ( ! isset( $installedFonts[ $fontName ] ) ) {
				$installedFonts[ $fontName ] = [];
			}
			$sourceDir = apply_filters( 'rtsb/pdf/invoice/fonts/source/dir', $sourceDir, $fontName, $styles, $installedFonts );
			foreach ( $styles as $style => $fileBase ) {
				foreach ( $extensions as $ext ) {
					$source = trailingslashit( $sourceDir ) . $fileBase . $ext;
					if ( $wp_filesystem->exists( $source ) ) {
						// Add first existing file for this style.
						if ( ! isset( $installedFonts[ $fontName ][ $style ] ) ) {
							$installedFonts[ $fontName ][ $style ] = trailingslashit( $sourceDir ) . $fileBase;
							$update                                = true;
						}
					}
				}
			}
		}
		/**
		 * Allow other developers to modify the font list before saving
		 *
		 * @param array $installedFonts Font array to be written
		 * @param string $sourceDir font source path
		 */
		$installedFonts = apply_filters( 'rtsb/pdf/invoice/registered/fonts', $installedFonts, $sourceDir );

		if ( $update ) {
			$wp_filesystem->put_contents( $jsonPath, wp_json_encode( $installedFonts, JSON_PRETTY_PRINT ), FS_CHMOD_FILE );
		}
	}
	/**
	 * Generate PDF binary from order.
	 *
	 * @return string PDF file content.
	 */
	public function build_pdf() {
		$options    = InvoiceFns::get_options();
		$paperSize  = $options['paper_size'] ?? 'a4';
		$pageNumber = $options['add_page_number'] ?? '';
		// WordPress uploads folder.
		$upload_dir = wp_upload_dir();
		$custom_dir = trailingslashit( $upload_dir['basedir'] ) . 'shopbuilder_uploads/invoices';
		// Persistent font directory.
		$fontDir = $custom_dir . '/dompdf-fonts';
		if ( ! file_exists( $fontDir ) ) {
			wp_mkdir_p( $fontDir );
		}
		// Copy all plugin fonts into persistent font directory.
		$this->register_plugin_fonts( __DIR__ . '/templates/fonts', $fontDir );

		$html    = $this->get_invoice_html();
		$args    = [
			'fontDir'                 => $fontDir,
			'fontCache'               => $fontDir,
			'chroot'                  => $this->get_chroot_paths(),
			'defaultFont'             => 'DejaVu Sans', // Set your font as default.
			'isRemoteEnabled'         => true,
			'isHtml5ParserEnabled'    => true,
			'isFontSubsettingEnabled' => true,
		];
		$options = new Options( apply_filters( 'rtsb/dompdf/options', $args ) );
		$dompdf  = new Dompdf( $options );
		$dompdf->loadHtml( $html );
		$dompdf->setPaper( $paperSize, 'portrait' );
		$dompdf->render();
		// Add page numbers (footer).
		if ( 'on' === $pageNumber ) {
			$canvas = $dompdf->getCanvas();
			$canvas->page_script(
				function ( $pageNumber, $pageCount, $canvas, $fontMetrics ) {
					if ( $pageCount > 1 ) {
						$text  = "Page $pageNumber of $pageCount";
						$font  = $fontMetrics->get_font( 'helvetica', 'normal' );
						$size  = 10;
						$width = $fontMetrics->get_text_width( $text, $font, $size );
						$x     = ( $canvas->get_width() - $width ) / 2;
						$y     = $canvas->get_height() - 30; // 30px from bottom
						$canvas->text( $x, $y, $text, $font, $size );
					}
				}
			);
		}
		return $dompdf->output();
	}
	/**
	 * Stream the PDF to the browser.
	 *
	 * @param string $pdf_view 'download' or 'new-window'.
	 * @return void
	 */
	public function generate_pdf( $pdf_view = null ) {
		$order         = $this->order;
		$options       = InvoiceFns::get_options();
		$pdf_output    = $this->build_pdf();
		$pdf_view      = ! empty( $pdf_view ) ? $pdf_view : ( $options['pdf_view'] ?? 'download' );
		$invoiceNumber = $order->get_meta( '_rtsb_invoice_id' ) ?: $order->get_id();

		$disposition = ( 'download' === $pdf_view ) ? 'attachment' : 'inline';
		$filename    = 'invoice-' . $invoiceNumber . '.pdf';
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: ' . $disposition . '; filename="' . $filename . '"' );
		echo $pdf_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Generate and save PDF invoice for the order.
	 *
	 * @return string|false Full path of saved PDF or false on failure.
	 */
	public function generate_and_save_pdf() {
		global $wp_filesystem;
		$order = $this->order;
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		$pdf_content = $this->build_pdf(); // Dompdf PDF binary.
		$invoice_id  = $order->get_meta( '_rtsb_invoice_id' ) ?: $order->get_id();
		$filename    = 'invoice-' . $invoice_id . '.pdf';

		$upload_dir = wp_upload_dir();
		$custom_dir = trailingslashit( $upload_dir['basedir'] ) . 'shopbuilder_uploads/invoices';

		if ( ! $wp_filesystem->is_dir( $custom_dir ) ) {
			$wp_filesystem->mkdir( $custom_dir, FS_CHMOD_DIR );
		}

		$file_path = trailingslashit( $custom_dir ) . $filename;
		$success   = $wp_filesystem->put_contents( $file_path, $pdf_content, FS_CHMOD_FILE );
		$order->update_meta_data( '_rtsb_invoice_pdf_path', $file_path );
		$order->save();
		return $success ? $file_path : false;
	}
	/**
	 * Generate invoice number.
	 */
	public function generate_invoice_number() {
		$order                   = $this->order;
		$options                 = InvoiceFns::get_options();
		$generate_invoice_number = ! empty( $options['generate_invoice_number'] ) ? $options['generate_invoice_number'] : false;
		if ( ! $generate_invoice_number ) {
			return '';
		}
		// Prevent overwriting if invoice number already exists.
		if ( ! empty( $order->get_meta( '_rtsb_invoice_id' ) ) ) {
			return $order->get_meta( '_rtsb_invoice_id' );
		}
		$options              = InvoiceFns::get_options();
		$invoice_start_number = absint( $options['invoice_start_number'] ?? 1 );
		// Generate sequential invoice number.
		$last_invoice       = absint( get_option( 'rtsb_last_invoice_number', $invoice_start_number ) );
		$new_invoice_number = $last_invoice + 1;
		if ( $invoice_start_number > $new_invoice_number ) {
			$new_invoice_number = $invoice_start_number;
		}
		$invoice_prefix = $options['invoice_prefix'] ?? '';
		$invoice_suffix = $options['invoice_suffix'] ?? '';
		$invoice_id     = $invoice_prefix . $new_invoice_number . $invoice_suffix;
		$invoice_id     = apply_filters( 'rtsb/pdf/invoice/number', $invoice_id, $new_invoice_number, $order, $options );
		// Save to order meta.
		$order->update_meta_data( '_rtsb_invoice_id', $invoice_id );
		$invoice_date = current_time( 'Y-m-d' );
		$order->update_meta_data( '_rtsb_invoice_date', $invoice_date );
		$order->save();
		// Update stored counter.
		update_option( 'rtsb_last_invoice_number', $new_invoice_number );
		return $invoice_id;
	}
	/**
	 * Send PDF invoice directly to customer email.
	 *
	 * @param string $recipient Optional. Email address to send the invoice to.
	 */
	public function send_email_pdf( $recipient = '' ) {
		if ( empty( $recipient ) ) {
			$recipient = $this->order->get_billing_email();
		}

		$file_path = $this->generate_and_save_pdf();
		if ( ! $file_path ) {
			return false;
		}

		$mailer = WC()->mailer();
		/* translators: %1$s: Order number */
		$subject = sprintf( __( 'Invoice for Order #%s', 'shopbuilder-pro' ), $this->order->get_order_number() );
		$message = __( 'Please find your invoice attached.', 'shopbuilder-pro' );
		$content = $mailer->wrap_message( $subject, $message );
		$headers = [ 'Content-Type: text/html; charset=UTF-8' ];

		$sent = $mailer->send( $recipient, $subject, $content, $headers, [ $file_path ] );
		// Delete the PDF file after sending.
		global $wp_filesystem;
		if ( $sent && $wp_filesystem->exists( $file_path ) ) {
			$wp_filesystem->delete( $file_path );
		}
		return $sent;
	}
	/**
	 * Generates the HTML content for the invoice.
	 *
	 * This method builds the HTML structure for the PDF invoice
	 * based on the provided WooCommerce order.
	 *
	 * @return array.
	 */
	public function get_woocommerce_totals() {
		$order           = $this->order;
		$totals          = [];
		$non_price_types = [ 'payment_method', 'customer_note', 'shipping_method', 'pickup_location' ];
		$non_price_types = apply_filters( 'rtsb/pdf/invoice/non_price_types', $non_price_types, $order );
		foreach ( $order->get_order_item_totals() as $total ) {
			$type  = $total['type'] ?? '';
			$label = $total['label'];
			if ( in_array( $type, $non_price_types, true ) ) {
				continue;
			} else {
				$totals[] = [
					'label' => $label,
					'value' => $total['value'],
				];
			}
		}
		return $totals;
	}

	/**
	 * @return string
	 */
	public function get_billing_details_text() {
		$order         = $this->order;
		$country_code  = $order->get_billing_country();
		$country_name  = WC()->countries->countries[ $country_code ] ?? $country_code;
		$address_parts = [
			$order->get_billing_address_1(),
			$order->get_billing_address_2(),
			$order->get_billing_city() . ', ' . $order->get_billing_state() . ', ' . $order->get_billing_postcode(),
			$country_name,
		];
		// Filter out empty fields and join with commas.
		$address = implode( '<br/> ', array_filter( $address_parts ) );
		$phone   = $order->get_billing_phone();
		$email   = $order->get_billing_email();
		if ( ! empty( $phone ) ) {
			$address .= '<br/>' . esc_html__( 'Phone: ', 'shopbuilder-pro' ) . $phone;
		}
		if ( ! empty( $email ) ) {
			$address .= '<br/>' . esc_html__( 'Email: ', 'shopbuilder-pro' ) . $email;
		}
		return $address;
	}
	/**
	 * Get formatted shipping details for the order.
	 *
	 * @return string HTML formatted shipping address details.
	 */
	public function get_shipping_details_text() {
		$order            = $this->order;
		$options          = InvoiceFns::get_options();
		$display_shipping = ! empty( $options['display_shipping'] ) ? $options['display_shipping'] : false;
		if ( ! $display_shipping ) {
			return '';
		}
		$address_1 = $order->get_shipping_address_1();
		if ( empty( $address_1 ) ) {
			return '';
		}
		$address_2     = $order->get_shipping_address_2();
		$country_code  = $order->get_shipping_country();
		$country_name  = WC()->countries->countries[ $country_code ] ?? $country_code;
		$address_parts = [
			$address_1,
			$address_2,
			$order->get_shipping_city() . ', ' . $order->get_shipping_state() . ', ' . $order->get_shipping_postcode(),
			$country_name,
		];
		// Filter out empty fields and join with line breaks.
		$address = implode( '<br/>', array_filter( $address_parts ) );
		// Shipping phone and email are usually not stored separately, but fallback to billing if needed.
		$phone = $order->get_shipping_phone() ?: $order->get_billing_phone();
		$email = $order->get_billing_email(); // Usually email is billing email.

		if ( ! empty( $phone ) ) {
			$address .= '<br/>' . esc_html__( 'Phone: ', 'shopbuilder-pro' ) . esc_html( $phone );
		}
		if ( ! empty( $email ) ) {
			$address .= '<br/>' . esc_html__( 'Email: ', 'shopbuilder-pro' ) . esc_html( $email );
		}
		return $address;
	}
	/**
	 * Generates the HTML content for the invoice.
	 *
	 * This method builds the HTML structure for the PDF invoice
	 * based on the provided WooCommerce order.
	 *
	 * @return string HTML content of the invoice.
	 */
	public function get_invoice_html() {
		$order = $this->order;
		ob_start();
		?>
		<!DOCTYPE html>
		<html <?php $this->language_attributes(); ?>>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
			<title>PDF Invoice DDD</title>
			<style type="text/css">
				<?php $this->template_styles(); ?>
				<?php $this->template_custom_styles(); ?>
			</style>
		</head>
		<body>
		<?php
		$options    = InvoiceFns::get_options();
		$pdf_logo   = $options['pdf_logo'];
		$logo_width = ! empty( $options['logo_width'] ) ? absint( $options['logo_width'] ) : 150;

		$layout          = ! empty( $options['template_layout'] ) ? $options['template_layout'] : 'layout1';
		$pdf_logo        = ! empty( $pdf_logo ) ? json_decode( stripslashes( $pdf_logo ), true ) : '';
		$imageId         = $pdf_logo['id'] ?? '';
		$imageUrl        = $imageId ? wp_get_attachment_image_url( $imageId, 'full' ) : '';
		$base64_img_logo = $imageUrl ? $this->image_to_data_uri( $imageUrl ) : '';
		$invoice_id      = $order->get_meta( '_rtsb_invoice_id' );
		$data            = [
			'order'            => $order,
			'order_status'     => wc_get_order_status_name( $order->get_status() ),
			'options'          => $options,
			'totals'           => $this->get_woocommerce_totals(),
			'base64_img_logo'  => $base64_img_logo,
			'shop_address'     => nl2br( $options['office_address'] ?? '' ),
			'company_name'     => $options['company_name'] ?? '',
			'billing_details'  => $this->get_billing_details_text(),
			'shipping_details' => $this->get_shipping_details_text(),
			'footer_text'      => $options['footer_text'] ?? '',
			'invoice_id'       => $invoice_id,
			'logo_width'       => $logo_width,
		];
		$data            = apply_filters( 'rtsb/pdf/invoice/data', $data, $order, $options );
		Fns::load_template( 'pdf-invoice/invoice-' . $layout, $data, false, '', rtsbpro()->get_plugin_template_path() );
		?>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
	/**
	 * Convert image (local or remote) to base64 or inline data URI.
	 *
	 * - Local files use file_get_contents().
	 * - Remote files use wp_remote_get().
	 * - SVGs are returned as UTF-8-encoded raw content.
	 *
	 * @param string $image_url Local path or remote image URL.
	 * @return string|false     Data URI or false on failure.
	 */
	public function image_to_data_uri( $image_url ) {
		$is_remote = filter_var( $image_url, FILTER_VALIDATE_URL );
		// Load image content.
		if ( $is_remote ) {
			$response = wp_remote_get( $image_url );
			if ( is_wp_error( $response ) ) {
				return false;
			}
			$image_data = wp_remote_retrieve_body( $response );
		} else {
			if ( ! file_exists( $image_url ) || ! is_readable( $image_url ) ) {
				return false;
			}
			$image_data = file_get_contents( $image_url ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}
		if ( empty( $image_data ) ) {
			return false;
		}
		// Use wp_parse_url instead of parse_url.
		$parsed_url = wp_parse_url( $image_url );
		$path       = isset( $parsed_url['path'] ) ? $parsed_url['path'] : '';
		// Get MIME type.
		if ( function_exists( 'finfo_open' ) ) {
			$finfo     = finfo_open( FILEINFO_MIME_TYPE );
			$mime_type = finfo_buffer( $finfo, $image_data );
			finfo_close( $finfo );
		} else {
			$mime_type = $is_remote
				? wp_remote_retrieve_header( $response, 'content-type' )
				: mime_content_type( $image_url );
		}
		if ( empty( $mime_type ) ) {
			return false;
		}
		return 'data:' . $mime_type . ';base64,' . base64_encode( $image_data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}
}
