<?php

namespace RadiusTheme\SBPRO\Controllers;

use Elementor\Plugin;
use RadiusTheme\SB\Helpers\BuilderFns;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Helpers\FnsPro;
use RadiusTheme\SBPRO\Traits\SingletonTrait;
use RadiusTheme\SB\Controllers\AssetsController;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

class AssetsControllerPro {

	/**
	 * Singleton.
	 */
	use SingletonTrait;

	/**
	 * Plugin version
	 *
	 * @var string
	 */
	private $version;

	/**
	 * Styles.
	 *
	 * @var array
	 */
	private $styles = [];

	/**
	 * Ajax URL
	 *
	 * @var string
	 */
	private static $ajaxurl;

	/**
	 * Scripts.
	 *
	 * @var array
	 */
	private $scripts = [];

	/**
	 * Class Constructor
	 */
	public function __construct() {
		$this->version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : RTSBPRO_VERSION;
		if ( in_array( 'sitepress-multilingual-cms/sitepress.php', get_option( 'active_plugins' ) ) ) {
			self::$ajaxurl = admin_url( 'admin-ajax.php?lang=' . ICL_LANGUAGE_CODE );
		} else {
			self::$ajaxurl = admin_url( 'admin-ajax.php' );
		}
		/**
		 * Public scripts.
		 */
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_public_scripts' ], 20 );
		add_action( 'wp_enqueue_scripts', [ $this, 'pro_style_settings' ], 30 );

		/**
		 * Admin scripts.
		 */
		add_action( 'admin_enqueue_scripts', [ $this, 'register_backend_assets' ], 1 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_backend_scripts' ], 15 );
	}

	/**
	 * Registers Admin scripts.
	 *
	 * @return void
	 */
	public function register_backend_assets() {
		/**
		 * Styles.
		 */
		wp_register_style( 'rtsb-product-admin', rtsbpro()->get_assets_uri( 'css/backend/product-admin.css' ), '', $this->version );

		/**
		 * Scripts.
		 */
		wp_register_script( 'rtsb-admin-license', rtsbpro()->get_assets_uri( 'js/backend/license-settings.js' ), [ 'jquery' ], $this->version, true );
		wp_register_script( 'rtsb-product-admin', rtsbpro()->get_assets_uri( 'js/backend/product-admin.js' ), [ 'jquery' ], $this->version, true );
	}

	/**
	 * Enqueues admin scripts.
	 *
	 * @param string $hook Hooks.
	 *
	 * @return void
	 */
	public function enqueue_backend_scripts( $hook ) {
		global $pagenow, $typenow;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'admin.php' === $pagenow && ! empty( $_GET['page'] ) && 'rtsb-license' === $_GET['page'] ) {
			wp_enqueue_script( 'rtsb-admin-license' );
			wp_localize_script(
				'rtsb-admin-license',
				'rtsbLicenseParams',
				[
					'ajaxurl' => esc_url( self::$ajaxurl ),

				]
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_orders_page = ( isset( $_REQUEST['post_type'] ) && 'shop_order' === sanitize_text_field( wp_unslash( $_REQUEST['post_type'] ) ) ) || ( isset( $_REQUEST['page'] ) && 'wc-orders' === sanitize_text_field( wp_unslash( $_REQUEST['page'] ) ) ) || 'shop_order' === $typenow;

		if ( 'product' === $typenow || $is_orders_page ) {
			wp_enqueue_style( 'rtsb-product-admin' );
		}

		if ( $this->is_product_edit_page() ) {
			global $post;

			$screen    = get_current_screen();
			$screen_id = $screen ? $screen->id : '';

			wp_enqueue_script( 'rtsb-product-admin' );

			wp_localize_script(
				'rtsb-product-admin',
				'rtsbAdminParamsPro',
				[
					'ajaxurl'       => admin_url( 'admin-ajax.php' ),
					rtsb()->nonceId => wp_create_nonce( rtsb()->nonceText ),
					'post_id'       => 'product' === $screen_id ? $post->ID : null,
					'addOnActive'   => FnsPro::is_module_active( 'product_add_ons' ) ? 'yes' : 'no',
				]
			);
		}
	}

	/**
	 * Localized Data.
	 *
	 * @static
	 * @return void
	 */
	public static function localizeData() {
		$mini_cart                 = Fns::get_options( 'modules', 'mini_cart' );
		$is_mini_cart_active       = ! empty( $mini_cart['active'] ) && 'on' === $mini_cart['active'];
		$mini_cart_custom_selector = $mini_cart['mini_cart_custom_selector'] ?? '';
		$time_text                 = apply_filters(
			'rtsb/localize/script/time/text',
			[
				'day'    => esc_html__( 'Day', 'shopbuilder-pro' ),
				'hour'   => esc_html__( 'Hr', 'shopbuilder-pro' ),
				'minute' => esc_html__( 'Min', 'shopbuilder-pro' ),
				'second' => esc_html__( 'Sec', 'shopbuilder-pro' ),
			]
		);

		wp_localize_script(
			'rtsb-public',
			'rtsbPublicParamsPro',
			[
				'day'                             => $time_text['day'] ?? esc_html__( 'Day', 'shopbuilder-pro' ),
				'hour'                            => $time_text['hour'] ?? esc_html__( 'Hr', 'shopbuilder-pro' ),
				'minute'                          => $time_text['minute'] ?? esc_html__( 'Min', 'shopbuilder-pro' ),
				'second'                          => $time_text['second'] ?? esc_html__( 'Sec', 'shopbuilder-pro' ),
				'qucikCheckout'                   => esc_html__( 'Quick Checkout', 'shopbuilder-pro' ),
				'isMiniCartActive'                => $is_mini_cart_active,
				'miniCartCustomSelector'          => $mini_cart_custom_selector,
				'filterErrorText'                 => esc_html__( 'Filtering error occurred. Please ensure that the filter settings are correctly configured.', 'shopbuilder-pro' ),
				'filterSearchText'                => esc_html__( 'Search Terms', 'shopbuilder-pro' ),
				'urlQSExceptions'                 => apply_filters(
					'rtsb/elements/widget/url/query_exceptions',
					[
						'orderby',
						'displayview',
						'customize_changeset_uuid',
						'customize_theme',
						'customize_messenger_channel',
						'elementor-preview',
						'post_type',
						'shopview',
						'preview_id',
						'preview_nonce',
						'preview',
						'd',
						'fbclid',
					]
				),
				'resetFilterText'                 => apply_filters( 'rtsb/elements/elementor/reset_filter_text', esc_html__( 'Clear all filters', 'shopbuilder-pro' ) ),
				// Step checkout.
				'keyboard_nav'                    => true,
				'hide_last_prev'                  => true,
				'hide_last_back_to_cart'          => true,
				'skip_login_above_form'           => true,
				'skip_login_next_to_login_button' => true,
			]
		);
	}

	/**
	 * Get all frontend scripts.
	 *
	 * @return void
	 */
	private function get_public_assets() {
		$this->get_public_styles()->get_public_scripts();
	}

	/**
	 * Get public styles.
	 *
	 * @return object
	 */
	private function get_public_styles() {
		$rtl_suffix     = is_rtl() ? '-rtl' : '';
		$this->styles[] = [
			'handle' => 'rtsb-frontend',
			'src'    => rtsbpro()->get_assets_uri( 'css/frontend/frontend' . $rtl_suffix . '.css' ),
		];

		return $this;
	}

	/**
	 * Get public scripts.
	 *
	 * @return object
	 */
	private function get_public_scripts() {
		$frontend_js             = 'frontend.js';
		$is_filter_widget_active = Fns::get_options( 'elements', 'ajax_product_filters' )['active'] ?? 'on';

		if ( ( BuilderFns::is_archive() || BuilderFns::is_shop() ) && $is_filter_widget_active ) {
			$frontend_js = 'frontend-archive.js';
		}
		$this->scripts[] = [
			'handle' => 'rtsb-public',
			'src'    => rtsbpro()->get_assets_uri( 'js/frontend/' . $frontend_js ),
			'deps'   => defined( 'ELEMENTOR_VERSION' ) && Plugin::$instance->preview->is_preview_mode() ? [ 'jquery', 'rtsb-imagesloaded', 'swiper', 'masonry' ] : [ 'jquery', 'rtsb-imagesloaded', 'swiper' ],
			'footer' => true,
		];

		return $this;
	}

	/**
	 * Register public scripts.
	 *
	 * @return void
	 */
	public function register_public_scripts() {
		$this->get_public_assets();

		wp_deregister_style( 'rtsb-frontend' );
		wp_deregister_script( 'rtsb-public' );

		/**
		 * No need re enqueue 'rtsb-frontend' and 'rtsb-public', The handle already enqueue from free version
		 */
		// Register public styles.
		foreach ( $this->styles as $style ) {
			wp_register_style( $style['handle'], $style['src'], '', $this->version );
		}

		// Register public scripts.
		foreach ( $this->scripts as $script ) {
			wp_register_script( $script['handle'], $script['src'], $script['deps'], $this->version, $script['footer'] );
		}

		AssetsController::localizeData();
		self::localizeData();
	}

	/**
	 * Enqueues public scripts.
	 *
	 * @return void
	 */
	public function enqueue_public_scripts() {
		/**
		 * Register scripts.
		 */
		$this->register_public_scripts();

		/**
		 * Enqueue Script Below if need
		 */
		wp_enqueue_script( 'rtsb-sticky-sidebar' );

		if ( is_shop() || is_product_taxonomy() ) {
			wp_enqueue_style( 'rtsb-noui-slider' );
		}
	}

	/**
	 * Enqueues general public scripts.
	 *
	 * @return void
	 */
	public function pro_style_settings() {
		$tooltip_font_size   = absint( Fns::get_option( 'general', 'tooltip', 'tooltip_font_size', 13 ) );
		$tooltip_font_weight = absint( Fns::get_option( 'general', 'tooltip', 'tooltip_font_weight', 500 ) );
		$tooltip_color       = Fns::get_option( 'general', 'tooltip', 'tooltip_color', '#fff' );
		$tooltip_color_bg    = Fns::get_option( 'general', 'tooltip', 'tooltip_bg', '#000' );

		$dynamic_css = '';

		if ( ! empty( $tooltip_font_size ) ) {
			$dynamic_css .= "body .tipsy .tipsy-inner { font-size: {$tooltip_font_size}px !important; }";
		}

		if ( ! empty( $tooltip_font_weight ) ) {
			$dynamic_css .= "body .tipsy .tipsy-inner { font-weight: {$tooltip_font_weight} !important; }";
		}

		if ( ! empty( $tooltip_color ) ) {
			$dynamic_css .= "body .tipsy .tipsy-inner { color: {$tooltip_color} !important; }";
		}

		if ( ! empty( $tooltip_color_bg ) ) {
			$dynamic_css .= "body .tipsy .tipsy-inner { background-color: {$tooltip_color_bg} !important; }";
			$dynamic_css .= "body .tipsy.tipsy-s .tipsy-arrow { border-top-color: {$tooltip_color_bg} !important; }";
			$dynamic_css .= "body .tipsy.tipsy-e .tipsy-arrow { border-left-color: {$tooltip_color_bg} !important; }";
			$dynamic_css .= "body .tipsy.tipsy-w .tipsy-arrow { border-right-color: {$tooltip_color_bg} !important; }";
			$dynamic_css .= "body .tipsy.tipsy-n .tipsy-arrow { border-bottom-color: {$tooltip_color_bg} !important; }";
		}

		if ( ! empty( $dynamic_css ) ) {
			wp_add_inline_style( 'rtsb-frontend', $dynamic_css );
		}
	}

	/**
	 * Checks if the current page is a WooCommerce product edit page in the WordPress admin.
	 *
	 * @return bool
	 */
	private function is_product_edit_page() {
		global $pagenow, $post;

		// Check if we are on the edit page for a product.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'post.php' === $pagenow && isset( $_GET['action'] ) && 'edit' === $_GET['action'] ) {
			if ( isset( $post->ID ) && 'product' === get_post_type( $post->ID ) ) {
				return true;
			}
		}

		// Check if we are on the new post page for a product.
		if ( 'post-new.php' === $pagenow ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( wp_unslash( $_GET['post_type'] ) ) : 'post';

			if ( 'product' === $post_type ) {
				return true;
			}
		}

		return false;
	}
}
