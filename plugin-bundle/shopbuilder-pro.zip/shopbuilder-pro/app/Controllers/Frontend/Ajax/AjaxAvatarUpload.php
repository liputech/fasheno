<?php
/**
 * Ajax Actions Class for Product Lookbook.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Controllers\Frontend\Ajax;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;
use WP_Query;

/**
 * Class AjaxAdvancedSearch.
 */
class AjaxAvatarUpload {
	use SingletonTrait;

	/**
	 * Class Constructor.
	 *
	 * @return void
	 */
	private function __construct() {
		add_action( 'wp_ajax_rtsb_upload_custom_avatar', [ $this, 'response' ] );
		add_action( 'wp_ajax_rtsb_remove_custom_avatar', [ $this, 'remove_avatar_response' ] );
	}
	/**
	 * Ajax response.
	 *
	 * @return void
	 */
	public function response() {
        // phpcs:disable
		if ( ! Fns::verify_nonce() ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed!', 'shopbuilder-pro' ) ] );
		}
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( [ 'message' => __( 'You are not logged in!', 'shopbuilder-pro' ) ] );
		}
		if ( empty( $_FILES['avatar_file'] ) ) {
			wp_send_json_error( [ 'message' => __( 'No file uploaded.', 'shopbuilder-pro' ) ] );
		}
        $file = $_FILES['avatar_file'];

        $allowed_types = array('image/jpeg', 'image/jpg', 'image/png');
        $file_type = wp_check_filetype($file['name']);

        if (!in_array($file['type'], $allowed_types) || !in_array($file_type['type'], $allowed_types)) {
            wp_send_json_error(array('message' => __('Invalid file type. Only JPG and PNG images are allowed.','shopbuilder-pro')));
        }

        $max_size = 2 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            wp_send_json_error(array('message' => __('Uploaded file is too large. Maximum size is 2MB.', 'shopbuilder-pro')));
        }

        $image_info = getimagesize($file['tmp_name']);
        if ($image_info === false) {
            wp_send_json_error(array('message' => __('Invalid image file.', 'shopbuilder-pro')));
        }

        if (!in_array($image_info['mime'], $allowed_types)) {
            wp_send_json_error(array('message' => __('Invalid file type. Only JPG and PNG images are allowed.', 'shopbuilder-pro')));
        }

        $file['name'] = sanitize_file_name($file['name']);

        add_filter('upload_mimes', function($mimes) {
            return array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png' => 'image/png'
            );
        });

        $attachment_id = media_handle_sideload(
            array(
                'name'     => $file['name'],
                'type'     => $file['type'],
                'tmp_name' => $file['tmp_name'],
                'error'    => $file['error'],
                'size'     => $file['size']
            ),
            0,
            'Avatar for user ' . get_current_user_id()
        );

        remove_all_filters('upload_mimes');

        if (is_wp_error($attachment_id)) {
            if (file_exists($file['tmp_name'])) {
                @unlink($file['tmp_name']);
            }
            wp_send_json_error(array('message' => $attachment_id->get_error_message()));
        }

        $attachment_url = wp_get_attachment_url($attachment_id);
        $user_id = get_current_user_id();


        $old_avatar_id = get_user_meta($user_id, 'rtsb_user_custom_avatar_id', true);
        if ($old_avatar_id && $old_avatar_id != $attachment_id) {
            wp_delete_attachment($old_avatar_id, true);
        }

        update_user_meta($user_id, 'rtsb_user_custom_avatar', esc_url_raw($attachment_url));
        update_user_meta($user_id, 'rtsb_user_custom_avatar_id', absint($attachment_id));

        wp_send_json_success(array(
            'message' => __('Avatar uploaded successfully.', 'shopbuilder-pro'),
            'url' => esc_url($attachment_url),
            'id' => absint($attachment_id)
        ));
	}
    /**
     * Handle avatar removal
     */
    public function remove_avatar_response() {
        if ( ! Fns::verify_nonce() ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed!', 'shopbuilder-pro' ) ] );
        }

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'You are not logged in!', 'shopbuilder-pro' ) ] );
        }

        $user_id = get_current_user_id();

        $avatar_id = get_user_meta($user_id, 'rtsb_user_custom_avatar_id', true);

        if ($avatar_id) {
            $deleted = wp_delete_attachment($avatar_id, true);

            if ($deleted === false) {
                wp_send_json_error(array(
                    'message' => __('Failed to delete avatar file.', 'shopbuilder-pro')
                ));
            }
        }

        delete_user_meta($user_id, 'rtsb_user_custom_avatar');
        delete_user_meta($user_id, 'rtsb_user_custom_avatar_id');

        wp_send_json_success(array(
            'message' => __('Avatar removed successfully.', 'shopbuilder-pro')
        ));
    }
}
