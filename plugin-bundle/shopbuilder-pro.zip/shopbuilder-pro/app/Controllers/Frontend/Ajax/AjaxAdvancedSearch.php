<?php
/**
 * Ajax Actions Class for Product Lookbook.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Controllers\Frontend\Ajax;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RadiusTheme\SB\Elementor\Render\GeneralAddons;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Traits\SingletonTrait;
use WP_Query;

/**
 * Class AjaxAdvancedSearch.
 */
class AjaxAdvancedSearch {
	use SingletonTrait;

	/**
	 * Class Constructor.
	 *
	 * @return void
	 */
	private function __construct() {
		add_action( 'wp_ajax_rtsb_get_search_products', [ $this, 'response' ] );
		add_action( 'wp_ajax_nopriv_rtsb_get_search_products', [ $this, 'response' ] );

		// AJAX handlers for add to cart.
		add_action( 'wp_ajax_rtsb_advanced_ajax_search_add_to_cart', [ $this, 'advanced_ajax_search_add_to_cart' ] );
		add_action( 'wp_ajax_nopriv_rtsb_advanced_ajax_search_add_to_cart', [ $this, 'advanced_ajax_search_add_to_cart' ] );
	}
	/**
	 * Ajax response.
	 *
	 * @return void
	 */
	public function response() {
		if ( ! Fns::verify_nonce() ) {
			wp_send_json_error( esc_html__( 'Security check failed!', 'shopbuilder-pro' ) );
		}
        // phpcs:disable
		$search_term = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$term        = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		$taxonomy    = isset( $_POST['taxonomy'] ) ? sanitize_text_field( wp_unslash( $_POST['taxonomy'] ) ) : 'product_cat';
        $products_id = array_map( 'absint', (array) wp_unslash( $_POST['products_id'] ?? [] ) );
        if ( isset( $_POST['settings'] ) ) {
			$settings = $this->sanitize_settings_json( $_POST['settings'] );
			extract( $settings );
		} else {
			$product_limit       = 12;
			$show_thumbnail      = true;
			$show_add_to_cart    = false;
			$show_rating         = false;
			$show_quantity_field = false;
			$show_category       = true;
			$show_brand          = false;
		}

		if ( strlen( $search_term ) < 2 ) {
			wp_send_json_error( [ 'message' => 'Search term too short' ] );
		}

		$args = [
			'post_type'      => 'product',
			'posts_per_page' => $product_limit,
			'post_status'    => 'publish',
		];
        if ( ! empty( $products_id ) ){
            $args['post__in'] = $products_id;
            $args['orderby'] = 'post__in';
        } else {
            $args['s'] = $search_term;
        }
        if (  !empty($term) && taxonomy_exists( $taxonomy ) ) {
            $args['tax_query'] = [
                [
                    'taxonomy' => $taxonomy,
                    'field'    => 'slug',
                    'terms'    => $term,
                ],
            ];
        }
		$query = new WP_Query( $args );

		if ( ! $query->have_posts() ) {
			wp_send_json_success( [ 'html' => '' ] );
		}

		ob_start();
        ?>
        <div class="rtsb-product-wrap">
		<?php while ( $query->have_posts() ) {
			$query->the_post();
			$product = wc_get_product( get_the_ID() );
            $data = [
                'product' => $product,
                'show_thumbnail' => $show_thumbnail,
                'show_add_to_cart' => $show_add_to_cart,
                'show_rating' => $show_rating,
                'show_category' => $show_category,
                'show_quantity_field' => $show_quantity_field,
                'show_brand' => $show_brand
            ];
            Fns::load_template( 'elementor/general/advanced-ajax-search/product-list', $data, false, '', rtsbpro()->get_plugin_template_path() );
		}
        ?>
        </div>
		<?php wp_reset_postdata();

		$html = ob_get_clean();

		wp_send_json_success( [ 'html' => $html ] );
	}

	/**
	 * Sanitize and extract settings JSON into separate variables.
	 *
	 * @param string $settings_json JSON string from $_POST['settings'].
	 * @return array Extracted sanitized variables
	 */
	public function sanitize_settings_json( $settings_json ) {

		$settings_json = wp_unslash( $settings_json );
		$settings_json = sanitize_text_field( $settings_json );

		$settings_array = json_decode( $settings_json, true );

		$defaults = [
			'product_limit'       => 12,
			'show_thumbnail'      => true,
			'show_add_to_cart'    => false,
			'show_attributes'     => false,
			'show_quantity_field' => false,
			'show_brand'          => false,
		];

		$settings = wp_parse_args( is_array( $settings_array ) ? $settings_array : [], $defaults );

		$settings['product_limit']       = absint( $settings['product_limit'] );
		$settings['show_thumbnail']      = (bool) $settings['show_thumbnail'];
		$settings['show_add_to_cart']    = (bool) $settings['show_add_to_cart'];
		$settings['show_attributes']     = (bool) $settings['show_attributes'];
		$settings['show_quantity_field'] = (bool) $settings['show_quantity_field'];
		$settings['show_brand']          = (bool) $settings['show_brand'];

		return $settings;
	}

    /**
     * Ajax response.
     *
     * @return void
     * @throws \Exception
     */
    public function advanced_ajax_search_add_to_cart() {
        if ( ! Fns::verify_nonce() ) {
            wp_send_json_error( esc_html__( 'Security check failed!', 'shopbuilder-pro' ) );
        }
        if ( ! isset( $_POST['product_id'] ) ) {
            wp_send_json_error(['message' => 'Invalid product']);
        }
        $product_id = absint( $_POST['product_id'] );
        $quantity   = isset( $_POST['quantity'] ) ? absint( $_POST['quantity'] ) : 1;
        $product    = wc_get_product( $product_id );
        if ( ! $product ) {
            wp_send_json_error( esc_html__( 'Product not found', 'shopbuilder-pro' ) );
        }
        $passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );
        if ( ! $passed_validation ) {
            wp_send_json_error( esc_html__( 'Product validation failed', 'shopbuilder-pro' ) );
        }
        if ( \WC()->cart->add_to_cart( $product_id, $quantity ) ) {
            do_action( 'woocommerce_ajax_added_to_cart', $product_id );

            wp_send_json_success(
                [
                    'message'    => __( 'Product added to cart', 'shopbuilder-pro' ),
                    'cart_count' => \WC()->cart->get_cart_contents_count(),
                    'cart_total' => \WC()->cart->get_cart_total(),
                ]
            );
        } else {
            wp_send_json_error( esc_html__( 'Failed to add product to cart', 'shopbuilder-pro' ) );
        }
    }
}
