<?php

namespace RadiusTheme\SBPRO\Helpers;

use RadiusTheme\SB\Helpers\Installation as InstallationMain;
use RadiusTheme\SB\Models\ExtraSettings;

// Do not allow directly accessing this file.

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

class Installation {

	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'check_version' ], 6 );
	}

	public static function check_version() {
		$version = ExtraSettings::instance()->get_option( 'rtsbpro_version' ) ?? get_option( 'rtsbpro_version' );
		if ( ! $version || version_compare( $version, RTSBPRO_VERSION, '<' ) ) {
			self::save_default_pro_settings();
		}
	}

	public static function save_default_pro_settings() {

		// If we made it till here nothing is running yet, lets set the transient now.
		set_transient( 'rtsb_installing', 'yes', MINUTE_IN_SECONDS * 10 );

		// Do something here
		InstallationMain::set_default_options();

		self::update_rtsb_version();

		delete_transient( 'rtsb_installing' );
	}

	private static function update_rtsb_version() {
		// update_option( 'rtsbpro_version', RTSBPRO_VERSION );
		ExtraSettings::instance()->set_option( 'rtsbpro_version', RTSB_VERSION );
	}

	public static function activate() {}
	public static function deactivation() { }
}
