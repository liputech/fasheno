<?php
/**
 * BuilderFns class
 *
 * The  builder.
 *
 * @package  RadiusTheme\SB
 * @since    1.0.0
 */

namespace RadiusTheme\SBPRO\Helpers;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

use RadiusTheme\SB\Helpers\BuilderFns;
use RadiusTheme\SB\Helpers\Fns;

/**
 * BuilderFns class
 */
class BuilderFunPro {

	/**
	 * Template builder
	 *
	 * @var boolean
	 */
	public static function is_thank_you() {
		return BuilderFns::is_page_builder( 'order-thank-you', is_checkout() && is_order_received_page() );
	}

	/**
	 * Template builder
	 *
	 * @var boolean
	 */
	public static function is_account_dashboard() {
		return BuilderFns::is_page_builder( 'myaccount-dashboard', is_account_page() && ! is_wc_endpoint_url(), true );
	}

	/***
	 * @return bool
	 */
	public static function is_orders_page() {
		return BuilderFns::is_page_builder( 'myaccount-order', is_wc_endpoint_url( 'orders' ), true );
	}

	/**
	 * Checks if the provided type corresponds to a custom endpoint on the My Account page.
	 *
	 * @param string $name The name of the custom endpoint to check.
	 * @return bool
	 */
	public static function is_account_custom_endpoint( $name ) {
		return BuilderFns::is_page_builder( 'myaccount-' . $name, FnsPro::is_wc_endpoint_url( $name ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_orders_details_page() {
		return BuilderFns::is_page_builder( 'myaccount-order-details', is_wc_endpoint_url( 'view-order' ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_downloads_page() {
		return BuilderFns::is_page_builder( 'myaccount-downloads', is_wc_endpoint_url( 'downloads' ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_address_page() {
		$is_edit_address = is_wc_endpoint_url( 'edit-address' ) && ! ( self::is_myaccount_address_type( 'billing' ) || self::is_myaccount_address_type( 'shipping' ) );
		return BuilderFns::is_page_builder( 'myaccount-address', $is_edit_address, true );
	}

	/***
	 * @return bool
	 */
	public static function is_account_edit_billing_address() {
		return BuilderFns::is_page_builder( 'myaccount-edit-billing-address', self::is_myaccount_address_type( 'billing' ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_account_edit_shipping_address() {
		return BuilderFns::is_page_builder( 'myaccount-edit-shipping-address', self::is_myaccount_address_type( 'shipping' ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_account_details() {
		return BuilderFns::is_page_builder( 'myaccount-edit-details', is_wc_endpoint_url( 'edit-account' ), true );
	}

	/***
	 * @return bool
	 */
	public static function is_account_wishlist() {
		$page_id = Fns::get_option( 'modules', 'wishlist', 'page' );

		if ( ! $page_id ) {
			return false;
		}
		return BuilderFns::is_page_builder( 'myaccount-wishlist', is_page( $page_id ) );
	}

	/***
	 * @return bool
	 */
	public static function is_account_login_register() {
		return BuilderFns::is_page_builder( 'myaccount-auth', ! is_user_logged_in() && is_account_page() && ! is_wc_endpoint_url() );
	}

	/***
	 * @return bool
	 */
	public static function is_lost_password_page() {
		return BuilderFns::is_page_builder( 'myaccount-lost-password', is_wc_endpoint_url( 'lost-password' ) );
	}

	/**
	 * @return bool|\WC_Order|\WC_Order_Refund
	 */
	public static function get_order() {
		global $wp;
		$order_id = 0;
		$order    = null;
		if ( isset( $wp->query_vars['order-received'] ) ) {
			$order_id = $wp->query_vars['order-received'];
			$order    = wc_get_order( $order_id );
		}
		if ( ! absint( $order_id ) ) {
			$args = [
				'limit'   => 1,
				'orderby' => 'ID',
				'order'   => 'DESC',
				// 'status'  => [ 'wc-on-hold', 'wc-processing','wc-completed' ],
			];
			// Get orders.
			$orders = wc_get_orders( $args );
			if ( ! empty( $orders ) ) {
				$order = reset( $orders );
			}
			if ( is_a( $order, 'WC_Order_Refund' ) ) {
				$order = wc_get_order( $order->get_parent_id() );
			}
		}

		return $order;
	}
	/**
	 * @return bool
	 */
	public static function is_myaccount_address_type( $type ) {
		global $wp;
		$is_edit_address = false;
		if ( isset( $wp->query_vars['edit-address'] ) && $wp->query_vars['edit-address'] === $type ) {
			$is_edit_address = true;
		}
		return $is_edit_address;
	}
}
