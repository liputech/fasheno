<?php
/**
 * AdminInputsFns Helpers class
 *
 * @package  RadiusTheme\SBPRO
 */

namespace RadiusTheme\SBPRO\Helpers;

use RadiusTheme\SB\Helpers\Fns;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * AdminInputsFns Helpers class
 */
class AdminInputsFns {
	/**
	 * Renders the HTML for a section title with actions based on the provided arguments.
	 *
	 * @param array $args Title args.
	 *
	 * @return string The HTML output of the title section.
	 */
	public static function render_title_with_actions( $args = [] ) {
		$defaults = [
			'type'         => 'h3',
			'title_class'  => 'addons-title',
			'title'        => esc_html__( 'Untitled', 'shopbuilder-pro' ),
			'drag_tip'     => esc_html__( 'Drag and drop to rearrange', 'shopbuilder-pro' ),
			'remove_class' => 'remove',
			'has_edit'     => true,
		];

		$args = wp_parse_args( $args, $defaults );

		ob_start();
		?>
		<<?php echo esc_html( $args['type'] ); ?> class="<?php echo esc_attr( $args['title_class'] ); ?>">
		<?php
		if ( ! empty( $args['title'] ) ) {
			?>
			<span><?php echo esc_html( $args['title'] ); ?></span>
			<?php
		}
		?>
		<div class="title-actions">
			<div class="tips sort" data-tip="<?php echo esc_attr( $args['drag_tip'] ); ?>"></div>
			<a href="#" class="remove-button <?php echo esc_attr( $args['remove_class'] ); ?>"><?php esc_html_e( 'Remove', 'shopbuilder-pro' ); ?></a>
			<?php
			if ( $args['has_edit'] ) {
				?>
				<a href="javascript:void(0)" class="edit-group edit"><?php esc_html_e( 'Edit', 'shopbuilder-pro' ); ?></a>
				<?php
			}
			?>
		</div>
		</<?php echo esc_html( $args['type'] ); ?>>
		<?php
		return ob_get_clean();
	}

	/**
	 * Generates HTML for a field description tip.
	 *
	 * @param array $args Arguments.
	 *
	 * @return string
	 */
	private static function render_field_description_tip( $args ) {
		if ( empty( $args['desc_tip'] ) ) {
			return '';
		}

		ob_start();
		?>

		<span class="woocommerce-help-tip" tabindex="0" aria-label="<?php echo esc_attr( $args['aria_label'] ); ?>" data-tip="<?php echo esc_attr( $args['description'] ); ?>"></span>

		<?php
		return ob_get_clean();
	}

	/**
	 * Generates HTML attributes from an associative array.
	 *
	 * @param array $attributes An associative array of attributes.
	 *
	 * @return string
	 */
	private static function generate_custom_attributes( $attributes = [] ) {
		$html = '';

		foreach ( $attributes as $attribute => $value ) {
			if ( empty( $value ) ) {
				continue;
			}

			$html .= esc_attr( $attribute ) . '="' . esc_attr( $value ) . '" ';
		}

		return trim( $html );
	}

	/**
	 * Provides default arguments for input fields.
	 *
	 * @return array
	 */
	private static function get_default_args() {
		return [
			'tag'               => 'p',
			'id'                => '',
			'label'             => '',
			'desc_tip'          => true,
			'aria_label'        => '',
			'description'       => '',
			'placeholder'       => '',
			'input_class'       => '',
			'value'             => '',
			'wrapper_class'     => 'form-field',
			'custom_attributes' => [],
		];
	}

	/**
	 * Generates common HTML attributes for input fields.
	 *
	 * @param array $args Arguments for generating the attributes.
	 *
	 * @return string
	 */
	private static function get_common_input_attributes( $args ) {
		$attributes = [
			'id'          => $args['id'],
			'name'        => $args['id'],
			'class'       => $args['input_class'],
			'value'       => $args['value'],
			'placeholder' => $args['placeholder'],
		];

		return self::generate_custom_attributes( $attributes );
	}

	/**
	 * Generates the HTML for the label.
	 *
	 * @param array $args Arguments for generating the label.
	 *
	 * @return string
	 */
	private static function render_label( $args ) {
		if ( empty( $args['label'] ) ) {
			return '';
		}

		$class = ! empty( $args['label_class'] ) ? sprintf( ' class="%s"', esc_attr( $args['label_class'] ) ) : '';

		return sprintf(
			'<label for="%s"%s>%s</label>',
			esc_attr( $args['id'] ),
			$class,
			esc_html( $args['label'] )
		);
	}

	/**
	 * Wraps the input field with a specified HTML tag.
	 *
	 * @param string $content The content to wrap.
	 * @param array  $args Arguments for the wrapper tag.
	 *
	 * @return string
	 */
	private static function wrap_with_tag( $content, $args ) {
		return sprintf(
			'<%s class="%s">%s%s%s</%s>',
			esc_html( $args['tag'] ),
			esc_attr( $args['wrapper_class'] ),
			self::render_label( $args ),
			self::render_field_description_tip( $args ),
			$content,
			esc_html( $args['tag'] )
		);
	}

	/**
	 * Generate the HTML for an admin text input field.
	 *
	 * @param array $args Arguments for generating the text input field.
	 *
	 * @return string
	 */
	public static function generate_text_input( $args = [] ) {
		$args = wp_parse_args( $args, self::get_default_args() );

		ob_start();
		?>
		<input type="text"
			<?php
			Fns::print_html( self::get_common_input_attributes( $args ) );
			Fns::print_html( self::generate_custom_attributes( $args['custom_attributes'] ) );
			?>
		/>
		<?php
		$input_html = ob_get_clean();

		return self::wrap_with_tag( $input_html, $args );
	}

	/**
	 * Generate the HTML for an admin text input field.
	 *
	 * @param array $args Arguments for generating the textarea input field.
	 *
	 * @return string
	 */
	public static function generate_textarea_input( $args = [] ) {
		$args = wp_parse_args( $args, self::get_default_args() );

		ob_start();
		?>
		<textarea
			<?php
			Fns::print_html( self::get_common_input_attributes( $args ) );
			Fns::print_html( self::generate_custom_attributes( $args['custom_attributes'] ) );
			?>
			rows="<?php echo esc_attr( $args['rows'] ?? 4 ); ?>"
			cols="<?php echo esc_attr( $args['cols'] ?? 20 ); ?>"
		><?php echo esc_textarea( $args['value'] ); ?></textarea>
		<?php
		$input_html = ob_get_clean();

		return self::wrap_with_tag( $input_html, $args );
	}

	/**
	 * Generate the HTML for an admin switch input field.
	 *
	 * @param array $args The arguments for the input field.
	 *
	 * @return string
	 */
	public static function generate_switch_input( $args = [] ) {
		$args    = wp_parse_args( $args, self::get_default_args() );
		$checked = isset( $args['checked'] ) && 'on' === $args['checked'] ? 'checked' : '';

		$args['wrapper_class'] .= ' switch-field';

		ob_start();
		?>
		<label class="switch-wrapper">
			<span class="switch">
				<input type="checkbox"
					<?php
					Fns::print_html( self::get_common_input_attributes( $args ) );
					echo esc_attr( $checked );
					Fns::print_html( self::generate_custom_attributes( $args['custom_attributes'] ) );
					?>
				/>
				<span class="slider"></span>
			</span>
		</label>
		<?php
		$input_html = ob_get_clean();

		return self::wrap_with_tag( $input_html, $args );
	}

	/**
	 * Generate the HTML for an admin select field.
	 *
	 * @param array $args The arguments for the input field.
	 *
	 * @return string
	 */
	public static function generate_select_input( $args = [] ) {
		$args     = wp_parse_args( $args, self::get_default_args() );
		$options  = $args['options'] ?? [];
		$selected = $args['value'] ?? '';

		ob_start();
		?>
		<select
			<?php
			Fns::print_html( self::get_common_input_attributes( $args ) );
			Fns::print_html( self::generate_custom_attributes( $args['custom_attributes'] ) );
			?>
		>
			<?php
			foreach ( $options as $value => $label ) {
				?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected, $value ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
				<?php
			}
			?>
		</select>
		<?php
		$input_html = ob_get_clean();

		return self::wrap_with_tag( $input_html, $args );
	}

	/**
	 * Generate the HTML for an admin number input field.
	 *
	 * @param array $args Arguments for generating the number input field.
	 *
	 * @return string
	 */
	public static function generate_number_input( $args = [] ) {
		$args = wp_parse_args( $args, self::get_default_args() );

		$args = wp_parse_args(
			$args,
			[
				'min'  => '',
				'max'  => '',
				'step' => '',
			]
		);

		ob_start();
		?>
		<input type="number"
			<?php
			Fns::print_html( self::get_common_input_attributes( $args ) );

			if ( isset( $args['min'] ) && '' !== $args['min'] ) {
				echo 'min="' . esc_attr( $args['min'] ) . '" ';
			}

			if ( isset( $args['max'] ) && '' !== $args['max'] ) {
				echo 'max="' . esc_attr( $args['max'] ) . '" ';
			}

			if ( isset( $args['step'] ) && '' !== $args['step'] ) {
				echo 'step="' . esc_attr( $args['step'] ) . '" ';
			}

			Fns::print_html( self::generate_custom_attributes( $args['custom_attributes'] ) );
			?>
		/>
		<?php
		$input_html = ob_get_clean();

		return self::wrap_with_tag( $input_html, $args );
	}

	/**
	 * Generates date picker input for a specified field.
	 *
	 * @param int     $post_id Post ID.
	 * @param array   $field   Field properties.
	 * @param boolean $time    With time field.
	 *
	 * @return void
	 */
	public static function generate_date_picker_input( $post_id, $field, $time = false ) {
		// Set default values for the field properties.
		$field = wp_parse_args(
			$field,
			[
				'type'          => $time ? 'datetime-local' : 'date',
				'name'          => $field['name'] ?? $field['id'],
				'wrapper_class' => $field['wrapper_class'] ?? '',
				'class'         => $field['class'] ?? 'short',
				'style'         => $field['style'] ?? '',
				'value'         => $field['value'] ?? get_post_meta( $post_id, $field['id'], true ),
			]
		);

		ob_start();
		?>
		<p class="form-field rtsb-form-field <?php echo esc_attr( $field['id'] ); ?>_field <?php echo esc_attr( $field['wrapper_class'] ); ?>">
			<label for="<?php echo esc_attr( $field['id'] ); ?>"><?php echo wp_kses_post( $field['label'] ); ?></label>

			<?php
			if ( ! empty( $field['description'] ) && false !== $field['desc_tip'] ) {
				echo wp_kses_post( wc_help_tip( $field['description'] ) );
			} elseif ( ! empty( $field['description'] ) && false === $field['desc_tip'] ) {
				echo '<span class="description">' . wp_kses_post( $field['description'] ) . '</span>';
			}
			?>
			<input type="<?php echo esc_attr( $field['type'] ); ?>"
			       name="<?php echo esc_attr( $field['name'] ); ?>"
			       id="<?php echo esc_attr( $field['id'] ); ?>"
			       value="<?php echo esc_attr( $field['value'] ); ?>"
			       class="<?php echo esc_attr( $field['class'] ); ?>"
			       style="<?php echo esc_attr( $field['style'] ); ?>"
			       data-date="<?php echo esc_attr( $field['value'] ); ?>"
			/>
		</p>
		<?php
		Fns::print_html( ob_get_clean(), true );
	}
}
