<?php
/**
 * AccountAddressSettings class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\Controls;

use RadiusTheme\SB\Elementor\Widgets\Controls\ButtonSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

class QuickCheckoutSettings {
	/**
	 * Widget Field
	 *
	 * @return array
	 */
	public static function settings( $widget ) {
		$button = ButtonSettings::style_settings( $widget );
		unset( $button['button_section_start']['tab'] );
		return $button ;
	}

}
