<?php
/**
 * AvatarSettings class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\Controls;

use RadiusTheme\SB\Elementor\Helper\ControlHelper;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SB\Elementor\Widgets\Controls\TextStyleSettings;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * SaleCountSettings class.
 */
class AvatarSettings {
	/**
	 * Retrieve the settings for the given widget.
	 *
	 * This method returns the general settings associated with the specified widget object.
	 *
	 * @param object $widget The widget instance for which to retrieve settings.
	 *
	 * @return array The array of settings for the given widget.
	 */
	public static function settings( $widget ) {
		return array_merge(
			self::general_settings( $widget ),
			self::image_style( $widget ),
			self::upload_icon_style( $widget ),
			self::remove_icon_style( $widget ),
			self::content_style( $widget )
		);
	}
	/**
	 * Widget Field
	 *
	 * @param object $widget The widget instance for which to retrieve settings.
	 *
	 * @return array
	 */
	public static function general_settings( $widget ) {
		return [
			'sec_general'            => [
				'mode'  => 'section_start',
				'label' => esc_html__( 'General', 'shopbuilder-pro' ),
			],
			'content_position'       => [
				'type'        => 'choose',
				'separator'   => 'before',
				'label'       => esc_html__( 'Content Position', 'shopbuilder-pro' ),
				'options'     => [
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'shopbuilder-pro' ),
						'icon'  => 'eicon-v-align-bottom',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'shopbuilder-pro' ),
						'icon'  => 'eicon-h-align-right',
					],

				],
				'toggle'      => true,
				'render_type' => 'template',
				'default'     => 'right',
			],
			'content_gap'            => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Content Gap', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					$widget->selectors['content_gap'] => 'gap:{{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'content_position' => 'right',
				],
			],
			'content_alignment'      => [
				'mode'      => 'responsive',
				'type'      => 'choose',
				'label'     => esc_html__( 'Content Alignment', 'shopbuilder-pro' ),
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'shopbuilder-pro' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shopbuilder-pro' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'shopbuilder-pro' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'separator' => 'before',
				'selectors' => [ $widget->selectors['content_alignment'] => 'text-align: {{VALUE}};' ],
				'condition' => [
					'content_position' => 'bottom',
				],
			],
			'upload_icon'            => [
				'label'   => esc_html__( 'Upload Icon', 'shopbuilder-pro' ),
				'type'    => 'icons',
				'default' => [
					'value'   => 'fas fa-upload',
					'library' => 'fa-solid',
				],
			],
			'show_upload_icon_hover' => [
				'type'        => 'switch',
				'label'       => esc_html__( 'Show Upload Icon On Hover', 'shopbuilder-pro' ),
				'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
				'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
				'description' => esc_html__( 'Switch on to show search button text.', 'shopbuilder-pro' ),
			],
			'remove_icon'            => [
				'label'   => esc_html__( 'Remove Icon', 'shopbuilder-pro' ),
				'type'    => 'icons',
				'default' => [
					'value'   => 'fas fa-times',
					'library' => 'fa-solid',
				],
			],
			'sec_general_end'        => [
				'mode' => 'section_end',
			],
		];
	}
	/**
	 * Image style section
	 *
	 * @param object $widget Reference object.
	 *
	 * @return array
	 */
	public static function image_style( $widget ) {
		return [
			'image_style_sec_start' => $widget->start_section(
				esc_html__( 'Image', 'shopbuilder-pro' ),
				'style'
			),
			'image_width'           => [
				'type'        => 'slider',
				'mode'        => 'responsive',
				'label'       => esc_html__( 'Image Width', 'shopbuilder-pro' ),
				'size_units'  => [ 'px' ],
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
				],
				'render_type' => 'template',
				'selectors'   => [
					$widget->selectors['image_width'] => 'width: {{SIZE}}{{UNIT}};flex: 0 0 {{SIZE}}{{UNIT}}',
				],
			],
			'image_height'          => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Image Height', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 600,
						'step' => 1,
					],
				],
				'selectors'  => [
					$widget->selectors['image_height'] => 'height: {{SIZE}}{{UNIT}};object-fit: cover;',
				],
			],
			'image_note'            => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Border', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'image_border'          => [
				'mode'           => 'group',
				'type'           => 'border',
				'label'          => esc_html__( 'Border', 'shopbuilder-pro' ),
				'selector'       => $widget->selectors['image_border'],
				'fields_options' => [
					'color' => [
						'label' => esc_html__( 'Border Color', 'shopbuilder-pro' ),
					],
				],
				'separator'      => 'default',
			],
			'img_border_radius'     => [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Border Radius', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$widget->selectors['img_border_radius'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			],
			'image_spacing'         => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Spacing', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'image_margin'          => [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Margin', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$widget->selectors['image_margin'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			],
			'image_style_sec_end'   => $widget->end_section(),
		];
	}
	/**
	 * Upload Icon style section
	 *
	 * @param object $widget Reference object.
	 *
	 * @return array
	 */
	public static function upload_icon_style( $widget ) {
		return [
			'upload_icon_style_sec_start' => $widget->start_section(
				esc_html__( 'Upload Icon', 'shopbuilder-pro' ),
				'style'
			),
			'icon_typography'             => [
				'mode'     => 'group',
				'type'     => 'typography',
				'selector' => $widget->selectors['icon_typography'],
			],
			'icon_color_note'             => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Color', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'icon_color'                  => [
				'type'      => 'color',
				'label'     => esc_html__( 'Icon Color', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['icon_color'] => 'color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'icon_bg_color'               => [
				'type'      => 'color',
				'label'     => esc_html__( 'Icon Background', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['icon_bg_color'] => 'background-color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'icon_dimension_note'         => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Dimension', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'icon_width'                  => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Icon Width', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 600,
					],
				],
				'selectors'  => [
					$widget->selectors['icon_width'] => 'width: {{SIZE}}{{UNIT}};flex: 0 0 {{SIZE}}{{UNIT}}',
				],
			],
			'icon_height'                 => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Icon Height', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 600,
					],
				],
				'selectors'  => [
					$widget->selectors['icon_height'] => 'height: {{SIZE}}{{UNIT}};',
				],
			],
			'icon_border_note'            => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Border', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'icon_border'                 => [
				'mode'           => 'group',
				'type'           => 'border',
				'label'          => esc_html__( 'Border', 'shopbuilder-pro' ),
				'selector'       => $widget->selectors['icon_border'],
				'fields_options' => [
					'color' => [
						'label' => esc_html__( 'Border Color', 'shopbuilder-pro' ),
					],
				],
				'separator'      => 'default',
			],
			'icon_border_radius'          => [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Border Radius', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$widget->selectors['icon_border_radius'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			],
			'icon_style_sec_end'          => $widget->end_section(),
		];
	}
	/**
	 * Remove Icon style section
	 *
	 * @param object $widget Reference object.
	 *
	 * @return array
	 */
	public static function remove_icon_style( $widget ) {
		return [
			'remove_icon_style_sec_start' => $widget->start_section(
				esc_html__( 'Remove Icon', 'shopbuilder-pro' ),
				'style'
			),
			'remove_icon_typography'      => [
				'mode'     => 'group',
				'type'     => 'typography',
				'selector' => $widget->selectors['remove_icon_typography'],
			],
			'remove_icon_color_note'      => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Color', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'remove_icon_color'           => [
				'type'      => 'color',
				'label'     => esc_html__( 'Icon Color', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['remove_icon_color'] => 'color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'remove_icon_bg_color'        => [
				'type'      => 'color',
				'label'     => esc_html__( 'Icon Background', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['remove_icon_bg_color'] => 'background-color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'remove_icon_dimension_note'  => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Dimension', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'remove_icon_width'           => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Icon Width', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 600,
					],
				],
				'selectors'  => [
					$widget->selectors['remove_icon_width'] => 'width: {{SIZE}}{{UNIT}};flex: 0 0 {{SIZE}}{{UNIT}}',
				],
			],
			'remove_icon_height'          => [
				'type'       => 'slider',
				'mode'       => 'responsive',
				'label'      => esc_html__( 'Icon Height', 'shopbuilder-pro' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 30,
						'max' => 600,
					],
				],
				'selectors'  => [
					$widget->selectors['remove_icon_height'] => 'height: {{SIZE}}{{UNIT}};',
				],
			],
			'remove_icon_border_note'     => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Border', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'remove_icon_border'          => [
				'mode'           => 'group',
				'type'           => 'border',
				'label'          => esc_html__( 'Border', 'shopbuilder-pro' ),
				'selector'       => $widget->selectors['remove_icon_border'],
				'fields_options' => [
					'color' => [
						'label' => esc_html__( 'Border Color', 'shopbuilder-pro' ),
					],
				],
				'separator'      => 'default',
			],
			'remove_icon_border_radius'   => [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Border Radius', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$widget->selectors['remove_icon_border_radius'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			],
			'remove_icon_style_sec_end'   => $widget->end_section(),
		];
	}
	/**
	 * Content  style section
	 *
	 * @param object $widget Reference object.
	 *
	 * @return array
	 */
	public static function content_style( $widget ) {
		return [
			'content_style_sec_start' => $widget->start_section(
				esc_html__( 'Content', 'shopbuilder-pro' ),
				'style'
			),
			'user_name_note'          => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'User Name', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'user_name_typography'    => [
				'mode'     => 'group',
				'type'     => 'typography',
				'selector' => $widget->selectors['user_name_typography'],
			],
			'user_name_color'         => [
				'type'      => 'color',
				'label'     => esc_html__( 'Color', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['user_name_color'] => 'color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'user_name_margin'        => [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Margin', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$widget->selectors['user_name_margin'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			],
			'email_note'              => [
				'type'            => 'html',
				'raw'             => '<h3 class="rtsb-elementor-group-heading">' . esc_html__( 'Email', 'shopbuilder-pro' ) . '</h3>',
				'separator'       => 'default',
				'content_classes' => 'elementor-panel-heading-title',
			],
			'email_typography'        => [
				'mode'     => 'group',
				'type'     => 'typography',
				'selector' => $widget->selectors['email_typography'],
			],
			'email_color'             => [
				'type'      => 'color',
				'label'     => esc_html__( 'Color', 'shopbuilder-pro' ),
				'selectors' => [
					$widget->selectors['email_color'] => 'color:{{VALUE}};',
				],
				'separator' => 'default',
			],
			'content_style_sec_end'   => $widget->end_section(),
		];
	}
}
