<?php
/**
 * AccountOrders class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\MyAccount;

use RadiusTheme\SB\Abstracts\ElementorWidgetBase;
use RadiusTheme\SB\Elementor\Helper\ControlHelper;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Elementor\Widgets\Controls\AvatarSettings;


// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * AccountNavigation class.
 */
class AccountAvatar extends ElementorWidgetBase {

	/**
	 * Construct function
	 *
	 * @param array $data default array.
	 * @param mixed $args default arg.
	 */
	public function __construct( $data = [], $args = null ) {
		$this->rtsb_name = esc_html__( 'Account Avatar', 'shopbuilder-pro' );
		$this->rtsb_base = 'rtsb-account-avatar';

		parent::__construct( $data, $args );
	}

	/**
	 * Widget Field
	 *
	 * @return void|array
	 */
	public function widget_fields() {
		return AvatarSettings::settings( $this );
	}
	/**
	 * Set Widget Keyword.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'My Account' ] + parent::get_keywords();
	}

	/**
	 * Get Avatar Image Attribute
	 *
	 * @return string
	 */
	protected function get_avatar_image_attribute() {
		$avatar_alt = '';
		$user_info  = get_userdata( get_current_user_id() );
		$avatar_id  = get_user_meta( get_current_user_id(), 'rtsb_user_custom_avatar_id', true );
		if ( $avatar_id ) {
			$image_alt = get_post_meta( $avatar_id, '_wp_attachment_image_alt', true );
			if ( ! empty( $image_alt ) ) {
				$avatar_alt = $image_alt;
			} else {
				$image_title = get_the_title( $avatar_id );
				if ( ! empty( $image_title ) && 'Auto Draft' !== $image_title ) {
					$avatar_alt = $image_title;
				}
			}
		}

		if ( empty( $avatar_alt ) ) {
			$avatar_alt = $user_info->display_name . ' Avatar';
		}
		return $avatar_alt;
	}

	/**
	 * Render Function
	 *
	 * @return void
	 */
	protected function render() {
		$controllers = $this->get_settings_for_display();

		$this->theme_support();

		if ( ! is_user_logged_in() ) {
			echo '<p class="woocommerce-info">' . esc_html__( 'You are not logged in.', 'shopbuilder-pro' ) . '</p>';
			return;
		}

		$user_id     = get_current_user_id();
		$avatar_url  = get_user_meta( $user_id, 'rtsb_user_custom_avatar', true );
		$avatar_size = $controllers['image_width'] ? $controllers['image_width']['size'] : '150';
		$avatar_alt  = $this->get_avatar_image_attribute();
		$user_info   = get_userdata( get_current_user_id() );
		$user_email  = $user_info->user_email;
		$user_name   = $user_info->display_name;
		$hover_class = ! empty( $controllers['show_upload_icon_hover'] ) ? 'show-upload-icon-hover' : '';
		$data        = [
			'template'         => 'elementor/myaccount/account-avatar',
			'controllers'      => $controllers,
			'avatar_url'       => $avatar_url,
			'avatar_size'      => $avatar_size,
			'user_id'          => $user_id,
			'avatar_alt'       => $avatar_alt,
			'user_email'       => $user_email,
			'user_name'        => $user_name,
			'hover_class'      => $hover_class,
			'content_position' => $controllers['content_position'] ?? 'right',
		];

		Fns::load_template( $data['template'], $data, false, '', rtsbpro()->get_plugin_template_path() );

		$this->theme_support( 'render_reset' );
	}
}
