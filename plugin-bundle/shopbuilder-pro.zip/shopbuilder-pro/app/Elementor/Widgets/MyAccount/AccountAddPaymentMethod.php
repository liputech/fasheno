<?php
/**
 * AccountOrderDetailsOrderAgain class.
 *
 * @package RadiusTheme\SB
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\MyAccount;

use RadiusTheme\SB\Abstracts\ElementorWidgetBase;
use RadiusTheme\SB\Elementor\Widgets\Controls\ButtonSettings;
use RadiusTheme\SB\Elementor\Widgets\Controls\CheckoutPaymentSettings;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SBPRO\Elementor\Widgets\Controls\DownloadableProductSettings;


// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * AccountNavigation class.
 */
class AccountAddPaymentMethod extends ElementorWidgetBase {

	/**
	 * Construct function
	 *
	 * @param array $data default array.
	 * @param mixed $args default arg.
	 */
	public function __construct( $data = [], $args = null ) {
		$this->rtsb_name = esc_html__( 'Account Add Payment Method', 'shopbuilder-pro' );
		$this->rtsb_base = 'rtsb-account-add-payment-method';
		parent::__construct( $data, $args );
	}

	/**
	 * Widget Field
	 *
	 * @return void|array
	 */
	public function widget_fields() {
		 $payment_settings = CheckoutPaymentSettings::widget_fields( $this );
		 unset( $payment_settings['payment_link_color'] );
		 unset( $payment_settings['payment_button_area'] );
		 unset( $payment_settings['payment_button_description_typography'] );
		 unset( $payment_settings['payment_button_description_text_color'] );
		 unset( $payment_settings['payment_button_description_bg_color'] );
		 unset( $payment_settings['payment_button_wrapper_padding'] );
		 unset( $payment_settings['payment_button_wrapper_margin'] );

		return array_merge(
			$payment_settings,
			ButtonSettings::style_settings( $this )
		);
	}

	/**
	 * Set Widget Keyword.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'My Account' ] + parent::get_keywords();
	}

	/**
	 * Render Function
	 *
	 * @return void
	 */
	protected function render() {
		if ( $this->is_builder_mode() ) {
			wp_enqueue_script( 'wc-add-payment-method' );
		}
		$controllers = $this->get_settings_for_display();
		$this->theme_support();

		$data = [
			'template'    => 'elementor/myaccount/add-payment-method',
			'controllers' => $controllers,
		];
		Fns::load_template( $data['template'], $data, false, '', rtsbpro()->get_plugin_template_path() );

		$this->theme_support( 'render_reset' );
		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$this->add_inline_editor_script();
		}
	}
	/**
	 * Add inline script for Elementor editor
	 */
	private function add_inline_editor_script() {
		?>
		<script>
			jQuery(document).ready(function($) {

				function initPaymentMethods() {
					$('#add_payment_method').off('click.rtsb init_add_payment_method.rtsb');
					$('.payment-method-actions .button.delete').off('click.rtsb');

					initAddPaymentMethod();
				}

				initPaymentMethods();

				if (typeof elementor !== 'undefined') {
					elementor.hooks.addAction('panel/open_editor/widget', function(panel, model, view) {
						setTimeout(function() {
							initPaymentMethods();
						}, 100);
					});
				}
			});

			function initAddPaymentMethod() {
				jQuery(function($) {
					if (typeof woocommerce_params === 'undefined') {
						return false;
					}
					$('#add_payment_method')
						.on('click.rtsb init_add_payment_method.rtsb', '.payment_methods input.input-radio', function() {
							if ($('.payment_methods input.input-radio').length > 1) {
								var target_payment_box = $('div.payment_box.' + $(this).attr('ID'));
								if ($(this).is(':checked') && !target_payment_box.is(':visible')) {
									$('div.payment_box').filter(':visible').slideUp(250);
									if ($(this).is(':checked')) {
										$('div.payment_box.' + $(this).attr('ID')).slideDown(250);
									}
								}
							} else {
								$('div.payment_box').show();
							}
						})
						.find('input[name=payment_method]:checked').trigger('click');

					$('#add_payment_method').on('submit.rtsb', function() {
						$('#add_payment_method').block({
							message: null,
							overlayCSS: { background: '#fff', opacity: 0.6 }
						});
					});

					$(document.body).trigger('init_add_payment_method');

					$('.woocommerce .payment-method-actions .button.delete').on('click.rtsb', function(event) {
						if ($(this).hasClass('disabled')) {
							event.preventDefault();
						}
						$(this).addClass('disabled');
					});
				});
			}
		</script>
		<?php
	}
}
