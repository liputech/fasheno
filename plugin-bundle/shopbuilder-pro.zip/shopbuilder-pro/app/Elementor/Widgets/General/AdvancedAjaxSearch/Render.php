<?php
/**
 * Render class for Image Hotspots widget.
 *
 * @package RadiusTheme\SBPRO
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\General\AdvancedAjaxSearch;

use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SB\Elementor\Helper\RenderHelpers;
use RadiusTheme\SB\Elementor\Render\GeneralAddons;
use RadiusTheme\SBPRO\Helpers\FnsPro;

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Render class.
 *
 * @package RadiusTheme\SBPRO
 */
class Render extends GeneralAddons {
	/**
	 * Main render function for displaying content.
	 *
	 * @param array $data     Data to be passed to the template.
	 * @param array $settings Widget settings.
	 *
	 * @return string
	 */
	public function display_content( $data, $settings ) {
		$this->settings  = $settings;
		$data            = wp_parse_args( $this->get_template_args(), $data );
		$data            = apply_filters( 'rtsb/general/advanced_ajax_search/args/' . $data['unique_name'], $data );
		$data['content'] = Fns::load_template( $data['template'], $data, true );

		return $this->addon_view( $data, $settings );
	}

	/**
	 * Retrieves template args based on widget settings.
	 *
	 * @return array
	 */
	private function get_template_args() {
		return [
			'taxonomy_search_type'        => $this->settings['taxonomy_search_type'] ?? 'cat',
			'all_cat_text'                => $this->settings['all_cat_text'] ?? '',
			'all_tag_text'                => $this->settings['all_tag_text'] ?? '',
			'all_brand_text'              => $this->settings['all_brand_text'] ?? '',
			'has_search_btn_text'         => ! empty( $this->settings['show_search_btn_text'] ) && ! empty( $this->settings['search_btn_text'] ),
			'search_btn_text'             => $this->settings['search_btn_text'] ?? '',
			'search_icon'                 => $this->settings['search_icon'] ?? '',
			'category_separator_position' => $this->get_separator_position_class(),
			'custom_order'                => $this->generate_advanced_ajax_search_custom_order(),
			'settings'                    => $this->product_settings_options(),
			'render'                      => $this,
		];
	}

	/**
	 * Get separator position class.
	 *
	 * @return string
	 */
	public function get_separator_position_class() {
		return 'left' === $this->settings['separator_position'] ? 'left-position' : 'right-position';
	}

	/**
	 * Generate advanced ajax search custom order.
	 *
	 * @return string
	 */
	public function generate_advanced_ajax_search_custom_order() {
		return FnsPro::generate_advanced_ajax_search_custom_order( $this->settings['content_ordering'] );
	}
	/**
	 * Generate advanced ajax search custom order.
	 *
	 * @return array
	 */
	public function product_settings_options() {
		return [
			'enable_ai_search'    => $this->settings['enable_ai_search'] ?? 'yes',
			'product_limit'       => $this->settings['product_limit'] ?? '12',
			'show_thumbnail'      => ! empty( $this->settings['show_product_thumbnail'] ),
			'show_add_to_cart'    => ! empty( $this->settings['show_add_to_cart'] ),
			'show_rating'         => ! empty( $this->settings['show_product_rating'] ),
			'show_quantity_field' => ! empty( $this->settings['show_quantity_field'] ),
			'show_brand'          => ! empty( $this->settings['show_product_brand'] ),
			'show_category'       => ! empty( $this->settings['show_product_category'] ),
		];
	}
}
