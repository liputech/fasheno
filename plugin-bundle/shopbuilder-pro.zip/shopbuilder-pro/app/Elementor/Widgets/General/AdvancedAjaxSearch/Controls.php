<?php
/**
 * Controls class.
 *
 * @package RadiusTheme\SBPRO
 */

namespace RadiusTheme\SBPRO\Elementor\Widgets\General\AdvancedAjaxSearch;

use RadiusTheme\SB\AI\AIFns;
use RadiusTheme\SB\Helpers\Fns;
use RadiusTheme\SB\Elementor\Helper\ControlHelper;
use Elementor\Utils;
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

/**
 * Controls class.
 *
 * @package RadiusTheme\SBPRO
 */
class Controls {
	/**
	 * Content section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function content( $obj ) {
		return array_merge(
			self::general_settings( $obj ),
			self::search_icon_settings( $obj ),
			self::content_visibility_settings( $obj ),
			self::content_ordering( $obj ),
			self::product_style( $obj ),
			self::search_form_style( $obj ),
			self::search_icon_style( $obj ),
			self::category_style( $obj )
		);
	}

	/**
	 * General Controls
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function general_settings( $obj ) {
		$fields['general_settings_sec_start'] = $obj->start_section(
			esc_html__( 'General', 'shopbuilder-pro' ),
			'content',
			[],
		);
		$fields['product_limit']              = [
			'label'       => esc_html__( 'Product Limit', 'shopbuilder-pro' ),
			'description' => esc_html__( 'The number of products to show. Set empty to show all products.', 'shopbuilder-pro' ),
			'type'        => 'number',
			'default'     => '12',
			'separator'   => 'before',
		];
		$fields['cols']                       = [
			'type'           => 'select2',
			'mode'           => 'responsive',
			'label'          => esc_html__( 'Number of Columns', 'shopbuilder-pro' ),
			'description'    => esc_html__( 'Please select the number of columns to show per row.', 'shopbuilder-pro' ),
			'options'        => [
				1 => esc_html__( '1 Column', 'shopbuilder-pro' ),
				2 => esc_html__( '2 Columns', 'shopbuilder-pro' ),
				3 => esc_html__( '3 Columns', 'shopbuilder-pro' ),
				4 => esc_html__( '4 Columns', 'shopbuilder-pro' ),
				5 => esc_html__( '5 Columns', 'shopbuilder-pro' ),
				6 => esc_html__( '6 Columns', 'shopbuilder-pro' ),
			],
			'label_block'    => true,
			'default'        => '3',
			'tablet_default' => '1',
			'mobile_default' => '1',
			'required'       => true,
			'render_type'    => 'template',
			'selectors'      => [
				$obj->selectors['columns']['cols'] => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
			],
			'separator'      => 'before',
		];
		$fields['grid_gap']                   = [
			'type'        => 'slider',
			'mode'        => 'responsive',
			'label'       => esc_html__( 'Grid Gap / Spacing (px)', 'shopbuilder-pro' ),
			'size_units'  => [ 'px' ],
			'range'       => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default'     => [
				'unit' => 'px',
				'size' => 20,
			],
			'description' => esc_html__( 'Please select the grid gap in px.', 'shopbuilder-pro' ),
			'selectors'   => [
				$obj->selectors['columns']['grid_gap'] => 'gap: {{SIZE}}{{UNIT}};',
			],
		];
		$fields['image_width']                = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Image Width (px)', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 50,
					'max' => 600,
				],
			],
			'selectors'  => [
				$obj->selectors['columns']['image_width'] => 'flex: 0 0 {{SIZE}}{{UNIT}};max-width: {{SIZE}}{{UNIT}};',
			],
		];
		$fields['taxonomy_search_type']       = [
			'type'        => 'select',
			'label'       => esc_html__( 'Taxonomy Search Type', 'shopbuilder-pro' ),
			'options'     => [
				'cat'   => esc_html__( 'Categories', 'shopbuilder-pro' ),
				'tag'   => esc_html__( 'Tags', 'shopbuilder-pro' ),
				'brand' => esc_html__( 'Brands', 'shopbuilder-pro' ),
			],
			'label_block' => true,
			'default'     => 'cat',
		];
		$fields['all_cat_text']               = [
			'label'       => esc_html__( 'Text for "All Categories"', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Please enter the text for "All Categories".', 'shopbuilder-pro' ),
			'type'        => 'text',
			'label_block' => true,
			'default'     => __( 'All Categories', 'shopbuilder-pro' ),
			'condition'   => [
				'taxonomy_search_type' => 'cat',
			],
		];
		$fields['all_tag_text']               = [
			'label'       => esc_html__( 'Text for "All Tags"', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Please enter the text for "All Tags".', 'shopbuilder-pro' ),
			'type'        => 'text',
			'label_block' => true,
			'default'     => __( 'All Tags', 'shopbuilder-pro' ),
			'condition'   => [
				'taxonomy_search_type' => 'tag',
			],
		];
		$fields['all_brand_text']             = [
			'label'       => esc_html__( 'Text for "All Brands"', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Please enter the text for "All Brands".', 'shopbuilder-pro' ),
			'type'        => 'text',
			'label_block' => true,
			'default'     => __( 'All Brands', 'shopbuilder-pro' ),
			'condition'   => [
				'taxonomy_search_type' => 'brand',
			],
		];
		$fields['general_settings_sec_end']   = $obj->end_section();

		return $fields;
	}
	/**
	 * Search Icon Controls
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function search_icon_settings( $obj ) {
		$fields['search_icon_settings_sec_start'] = $obj->start_section(
			esc_html__( 'Search Icon', 'shopbuilder-pro' ),
			'content',
			[],
		);
		$fields['search_icon']                    = [
			'label'   => esc_html__( 'Search Icon', 'shopbuilder-pro' ),
			'type'    => 'icons',
			'default' => [
				'value'   => 'fas fa-search',
				'library' => 'fa-solid',
			],
		];
		$fields['show_search_btn_text']           = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Button Text', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show search button text.', 'shopbuilder-pro' ),
		];
		$fields['search_btn_text']                = [
			'label'       => esc_html__( 'Text', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Please enter the search button text.', 'shopbuilder-pro' ),
			'type'        => 'text',
			'label_block' => true,
			'default'     => __( 'Search', 'shopbuilder-pro' ),
			'condition'   => [
				'show_search_btn_text' => 'yes',
			],
		];

		$fields['search_icon_settings_sec_end'] = $obj->end_section();

		return $fields;
	}
	/**
	 * Content Visibility Controls
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function content_visibility_settings( $obj ) {
		$fields['content_visibility_settings_sec_start'] = $obj->start_section(
			esc_html__( 'Content Visibility', 'shopbuilder-pro' ),
			'settings',
			[],
		);
		$ai_data = false;
		if ( class_exists( AIFns::class ) ) {
			$ai_data = AIFns::activated_semantic_search();
		}
		if ( $ai_data ) {
			$fields['enable_ai_search'] = [
				'type'        => 'switch',
				'label'       => esc_html__( 'Enable Semantic Search?', 'shopbuilder-pro' ),
				'description' => esc_html__( 'Switch on to enable product semantic search.', 'shopbuilder-pro' ),
				'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
				'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
				'default'     => 'yes',
			];
		}
		$fields['show_product_thumbnail']              = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Product Thumbnail?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show product thumbnail.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
			'default'     => 'yes',
		];
		$fields['show_add_to_cart']                    = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Add to Cart?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show add to cart.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
			'default'     => 'yes',
		];
		$fields['show_product_rating']                 = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Product Rating?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show product rating.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
		];
		$fields['show_quantity_field']                 = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Quantity Field?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show quantity field.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
		];
		$fields['show_product_category']               = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Product Category?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show product category.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
			'default'     => 'yes',
		];
		$fields['show_product_brand']                  = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Show Product Brand?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to show product brand.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
		];
		$fields['content_visibility_settings_sec_end'] = $obj->end_section();

		return $fields;
	}
	/**
	 * Content ordering section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function content_ordering( $obj ) {
		$fields['ordering_section'] = $obj->start_section(
			esc_html__( 'Content Ordering', 'shopbuilder-pro' ),
			'settings'
		);

		$fields['ordering_note'] = [
			'type'            => 'html',
			'raw'             => '',
			'content_classes' => 'elementor-panel-heading-title',
		];

		$fields['custom_ordering'] = [
			'type'        => 'switch',
			'label'       => esc_html__( 'Enable Custom Ordering?', 'shopbuilder-pro' ),
			'description' => esc_html__( 'Switch on to enable elements custom ordering.', 'shopbuilder-pro' ),
			'label_on'    => esc_html__( 'On', 'shopbuilder-pro' ),
			'label_off'   => esc_html__( 'Off', 'shopbuilder-pro' ),
		];
		$defaults                  = [
			[
				'ordering_title' => esc_html__( 'Category Selector', 'shopbuilder-pro' ),
				'ordering_type'  => 'categories',
			],
			[
				'ordering_title' => esc_html__( 'Search Input', 'shopbuilder-pro' ),
				'ordering_type'  => 'search_input',
			],
			[
				'ordering_title' => esc_html__( 'Search Box', 'shopbuilder-pro' ),
				'ordering_type'  => 'search_box',
			],
		];

		$fields['content_ordering'] = [
			'type'         => 'repeater',
			'mode'         => 'repeater',
			'label'        => esc_html__( 'Please order elements below', 'shopbuilder-pro' ),
			'condition'    => [
				'custom_ordering' => [ 'yes' ],
			],
			'fields'       => [],
			'default'      => $defaults,
			'separator'    => 'before',
			'item_actions' => [
				'add'       => false,
				'duplicate' => false,
				'remove'    => false,
				'sort'      => true,
			],
			'title_field'  => '{{{ ordering_title }}}',
		];

		$fields['ordering_section_end'] = $obj->end_section();

		return $fields;
	}
	/**
	 * Search Form Style section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function search_form_style( $obj ) {
		$css_selectors = $obj->selectors['form_style'];
		$title         = esc_html__( 'Form Style', 'shopbuilder-pro' );
		$selectors     = [
			'typography'    => $css_selectors['typography'],
			'bg_color'      => [ $css_selectors['bg_color'] => 'background-color: {{VALUE}};' ],
			'color'         => [ $css_selectors['color'] => 'color: {{VALUE}};' ],
			'border'        => $css_selectors['border'],
			'border_radius' => [ $css_selectors['border_radius'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		];

		$fields = ControlHelper::general_elementor_style( 'form_style', $title, $obj, [], $selectors );
		unset(
			$fields['form_style_alignment'],
			$fields['form_style_padding'],
			$fields['form_style_margin'],
			$fields['form_style_color_tabs'],
			$fields['form_style_color_tab'],
			$fields['form_style_color_tab_end'],
			$fields['form_style_hover_color_tab'],
			$fields['form_style_hover_color'],
			$fields['form_style_hover_bg_color'],
			$fields['form_style_border_hover_color'],
			$fields['form_style_hover_color_tab_end'],
			$fields['form_style_color_tabs_end'],
		);
		$extra_controls['form_height']    = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Form Height (px)', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 30,
					'max' => 300,
				],
			],
			'selectors'  => [
				$css_selectors['form_height'] => 'height:{{SIZE}}{{UNIT}};',
			],
		];
		$fields                           = Fns::insert_controls( 'form_style_spacing_note', $fields, $extra_controls, true );
		$extra_controls2['border_radius'] = [
			'label'      => esc_html__( 'Border Radius', 'shopbuilder-pro' ),
			'type'       => 'dimensions',
			'mode'       => 'responsive',
			'size_units' => [ 'px' ],
			'selectors'  => $selectors['border_radius'],
		];
		$fields                           = Fns::insert_controls( 'rtsb_el_form_style_border', $fields, $extra_controls2, true );
		return $fields;
	}
	/**
	 * Search Icon Style section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function search_icon_style( $obj ) {
		$css_selectors = $obj->selectors['search_icon_style'];
		$title         = esc_html__( 'Search Icon Style', 'shopbuilder-pro' );
		$selectors     = [
			'typography'         => $css_selectors['typography'],
			'bg_color'           => [ $css_selectors['bg_color'] => 'background-color: {{VALUE}};' ],
			'hover_bg_color'     => [ $css_selectors['hover_bg_color'] => 'background-color: {{VALUE}};' ],
			'color'              => [ $css_selectors['color'] => 'color: {{VALUE}};' ],
			'hover_color'        => [ $css_selectors['hover_color'] => 'color: {{VALUE}};' ],
			'border'             => $css_selectors['border'],
			'border_hover_color' => $css_selectors['border_hover_color'],
			'button_width'       => [ $css_selectors['button_width'] => 'width: {{SIZE}}{{UNIT}};' ],
			'icon_gap'           => [ $css_selectors['icon_gap'] => 'gap: {{SIZE}}{{UNIT}};' ],
		];

		$fields = ControlHelper::general_elementor_style( 'search_icon_style', $title, $obj, [], $selectors );
		unset(
			$fields['search_icon_style_alignment'],
			$fields['search_icon_style_padding'],
			$fields['rtsb_el_search_icon_style_border'],
			$fields['search_icon_style_border_hover_color'],
			$fields['search_icon_style_border_note'],
			$fields['search_icon_style_margin'],
		);
		$extra_controls['button_width'] = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Button Width (px)', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 50,
					'max' => 300,
				],
			],
			'selectors'  => $selectors['button_width'],
		];
		$extra_controls['icon_gap']     = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Icon Gap (px)', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'selectors'  => $selectors['icon_gap'],
		];
		return Fns::insert_controls( 'search_icon_style_spacing_note', $fields, $extra_controls, true );
	}

	/**
	 * Category Style section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function category_style( $obj ) {
		$css_selectors = $obj->selectors['category_style'];
		$title         = esc_html__( 'Taxonomy Dropdown Style', 'shopbuilder-pro' );
		$selectors     = [
			'typography'       => $css_selectors['typography'],
			'color'            => [ $css_selectors['color'] => 'color: {{VALUE}};' ],
			'separator_color'  => [ $css_selectors['separator_color'] => 'border-color: {{VALUE}};' ],
			'bg_color'         => [ $css_selectors['bg_color'] => 'background-color: {{VALUE}};' ],
			'dropdown_width'   => [ $css_selectors['dropdown_width'] => 'width: {{SIZE}}{{UNIT}};' ],
			'separator_width'  => [ $css_selectors['separator_width'] => 'border-width: {{SIZE}}{{UNIT}};' ],
			'separator_height' => [ $css_selectors['separator_height'] => 'height: {{SIZE}}{{UNIT}};' ],
		];

		$fields = ControlHelper::general_elementor_style( 'category_style', $title, $obj, [], $selectors );
		unset(
			$fields['category_style_alignment'],
			$fields['category_style_padding'],
			$fields['rtsb_el_category_style_border'],
			$fields['category_style_border_note'],
			$fields['category_style_hover_bg_color'],
			$fields['category_style_border_hover_color'],
			$fields['category_style_margin'],
			$fields['category_style_color_tabs'],
			$fields['category_style_color_tab'],
			$fields['category_style_hover_color'],
			$fields['category_style_color_tab_end'],
			$fields['category_style_hover_color_tab'],
			$fields['category_style_hover_color_tab_end'],
			$fields['category_style_color_tabs_end'],
		);
		$extra_controls['dropdown_width']           = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Dropdown Width (px)', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 30,
					'max' => 300,
				],
			],
			'selectors'  => $selectors['dropdown_width'],
		];
		$fields                                     = Fns::insert_controls( 'category_style_spacing_note', $fields, $extra_controls, true );
		$extra_controls2['dropdown_separator_note'] = $obj->el_heading(
			esc_html__( 'Dropdown Separator', 'shopbuilder-pro' ),
			'before',
		);
		$extra_controls2['separator_color']         = [
			'label'     => esc_html__( 'Separator Color', 'shopbuilder-pro' ),
			'type'      => 'color',
			'selectors' => $selectors['separator_color'],
		];
		$extra_controls2['separator_position']      = [
			'mode'    => 'responsive',
			'type'    => 'choose',
			'label'   => esc_html__( 'Separator Position', 'shopbuilder-pro' ),
			'options' => [
				'left'  => [
					'title' => esc_html__( 'Left', 'shopbuilder-pro' ),
					'icon'  => 'eicon-h-align-left',
				],
				'right' => [
					'title' => esc_html__( 'Right', 'shopbuilder-pro' ),
					'icon'  => 'eicon-h-align-right',
				],

			],
			'toggle'  => true,
			'default' => 'right',
		];
		$extra_controls2['separator_width']  = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Separator Width', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'selectors'  => $selectors['separator_width'],
		];
		$extra_controls2['separator_height'] = [
			'type'       => 'slider',
			'mode'       => 'responsive',
			'label'      => esc_html__( 'Separator Height', 'shopbuilder-pro' ),
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 0,
					'max' => 300,
				],
			],
			'selectors'  => $selectors['separator_height'],
		];
		return Fns::insert_controls( 'dropdown_width', $fields, $extra_controls2, true );
	}
	/**
	 * Product Style section
	 *
	 * @param object $obj Reference object.
	 *
	 * @return array
	 */
	public static function product_style( $obj ) {
		$fields['product_style_sec_start'] = $obj->start_section(
			esc_html__( 'Product Style', 'shopbuilder-pro' ),
			'style',
			[],
		);
		$fields                           += self::style_group_fields( $obj, __( 'Title', 'shopbuilder-pro' ), 'title' );

		$fields += self::style_group_fields( $obj, __( 'Category', 'shopbuilder-pro' ), 'category' );

		$fields                             += self::style_group_fields( $obj, __( 'Brand', 'shopbuilder-pro' ), 'brand', [ 'show_product_brand' => 'yes' ] );
		$fields                             += self::style_group_fields(
			$obj,
			__( 'Add to Cart', 'shopbuilder-pro' ),
			'add_to_cart',
			[ 'show_add_to_cart' => 'yes' ],
			[
				'bg_color'           => true,
				'hover_bg_color'     => true,
				'border'             => true,
				'hover_border_color' => true,
			]
		);
		$fields['product_style_section_end'] = $obj->end_section();
		return $fields;
	}
	/**
	 * Helper: Generate style field group (typography + color + hover) with flexibility.
	 *
	 * @param object $obj Elementor control object.
	 * @param string $label Field label (e.g. 'Title', 'Category').
	 * @param string $key Unique field key (e.g. 'title', 'brand').
	 * @param array  $condition Optional Elementor display condition.
	 * @param array  $options Optional field options.
	 * @return array
	 */
	private static function style_group_fields( $obj, $label, $key, $condition = [], $options = [] ) {

		$defaults = [
			'typography'         => true,
			'color'              => true,
			'bg_color'           => false,
			'hover_color'        => true,
			'hover_bg_color'     => false,
			'border'             => false,
			'hover_border_color' => false,
			'margin'             => true,
		];

		$options = wp_parse_args( $options, $defaults );

		$fields = [];

		$fields[ "{$key}_style_note" ] = $obj->el_heading(
			esc_html( $label ),
			'before',
			[],
			$condition
		);

		if ( $options['typography'] ) {
			$fields[ "{$key}_typography" ] = [
				'mode'      => 'group',
				'type'      => 'typography',
				'selector'  => $obj->selectors['product_style'][ "{$key}_typography" ],
				'condition' => $condition,
			];
		}

		if ( $options['color'] ) {
			$fields[ "{$key}_color" ] = [
				'label'     => 'Color',
				'type'      => 'color',
				'selectors' => [
					$obj->selectors['product_style'][ "{$key}_color" ] => 'color: {{VALUE}};',
				],
				'condition' => $condition,
			];
		}

		if ( $options['hover_color'] ) {
			$fields[ "{$key}_hover_color" ] = [
				'label'     => 'Hover Color',
				'type'      => 'color',
				'selectors' => [
					$obj->selectors['product_style'][ "{$key}_hover_color" ] => 'color: {{VALUE}};',
				],
				'condition' => $condition,
			];
		}
		if ( $options['bg_color'] ) {
			$fields[ "{$key}_bg_color" ] = [
				'label'     => 'Background',
				'type'      => 'color',
				'selectors' => [
					$obj->selectors['product_style'][ "{$key}_bg_color" ] => 'background-color: {{VALUE}};',
				],
				'condition' => $condition,
			];
		}
		if ( $options['hover_bg_color'] ) {
			$fields[ "{$key}_hover_bg_color" ] = [
				'label'     => 'Hover Background',
				'type'      => 'color',
				'selectors' => [
					$obj->selectors['product_style'][ "{$key}_hover_bg_color" ] => 'background-color: {{VALUE}};',
				],
				'condition' => $condition,
			];
		}
		if ( $options['border'] ) {
			$fields[ "{$key}_border" ] = [
				'mode'           => 'group',
				'type'           => 'border',
				'label'          => esc_html__( 'Border', 'shopbuilder-pro' ),
				'selector'       => $obj->selectors['product_style'][ "{$key}_border" ],
				'condition'      => $condition,
				'fields_options' => [
					'color' => [
						'label' => esc_html__( 'Border Color', 'shopbuilder-pro' ),
					],
				],
			];
		}
		if ( $options['hover_border_color'] ) {
			$fields[ "{$key}_hover_border_color" ] = [
				'label'     => 'Hover Border Color',
				'type'      => 'color',
				'selectors' => [
					$obj->selectors['product_style'][ "{$key}_hover_border_color" ] => 'border-color: {{VALUE}};',
				],
				'condition' => $condition,
			];
		}
		if ( $options['margin'] ) {
			$fields[ "{$key}_margin" ] = [
				'mode'       => 'responsive',
				'type'       => 'dimensions',
				'label'      => esc_html__( 'Margin', 'shopbuilder-pro' ),
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					$obj->selectors['product_style'][ "{$key}_margin" ] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => $condition,
			];
		}

		return $fields;
	}
}
