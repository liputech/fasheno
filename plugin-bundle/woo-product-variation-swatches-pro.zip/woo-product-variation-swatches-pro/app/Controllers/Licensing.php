<?php


namespace Rtwpvsp\Controllers;


use Rtwpvsp\Helpers\Functions;
use Rtwpvsp\Models\RtLicense;

class Licensing {

	// Licensing variable
	static $store_url = 'https://www.radiustheme.com';
	static $product_id = 99336;

	static function init() {
		add_action( 'admin_init', array( __CLASS__, 'license' ) );
		add_action( 'wp_ajax_rtwpvs_manage_licensing', array( __CLASS__, 'rtwpvs_manage_licensing' ) );
	}

	static function license() {
		if ( Functions::check_license() ) {
			$license_key    = trim( rtwpvs()->get_option( 'license_key' ) ?? '' );
			$license_status = rtwpvs()->get_option( 'license_status' );
			$status         = ( ! empty( $license_status ) && $license_status === 'valid' ) ? true : false;
			new RtLicense( static::$store_url, RTWPVSP_PLUGIN_FILE, array(
				'version' => RTWPVSP_VERSION,
				'license' => $license_key,
				'item_id' => self::$product_id,
				'author'  => 'RadiusTheme',
				'url'     => home_url(),
				'beta'    => false,
				'status'  => $status
			) );

		}
	}

	static function rtwpvs_manage_licensing() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [ 'error' => true, 'msg' => esc_html__( 'Permission denied.', 'woo-product-variation-swatches-pro' ) ] );
		}

		if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ), 'rtwpvs_manage_licensing' ) ) {
			wp_send_json( [ 'error' => true, 'msg' => esc_html__( 'Security check failed.', 'woo-product-variation-swatches-pro' ) ] );
		}

		$error          = true;
		$type           = $value = $data = $message = null;
		$license_key    = trim( rtwpvs()->get_option( 'license_key' ) ?? '' );
		$license_status = rtwpvs()->get_option( 'license_status' );
		$request_type   = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';

		if ( $request_type === 'license_activate' ) {
			$api_params = array(
				'edd_action' => 'activate_license',
				'license'    => $license_key,
				'item_id'    => self::$product_id,
				'url'        => home_url()
			);
			$response   = wp_remote_post( self::$store_url,
				array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				$err     = is_wp_error( $response ) ? $response->get_error_message() : '';
				$message = ! empty( $err ) ? esc_html( $err ) : __( 'An error occurred, please try again.', 'woo-product-variation-swatches-pro' );
			} else {
				$license_data = json_decode( wp_remote_retrieve_body( $response ) );
				if ( ! empty( $license_data ) && false === $license_data->success ) {
					switch ( $license_data->error ) {
						case 'expired' :
							$message = sprintf(
								__( 'Your license key expired on %s.', 'woo-product-variation-swatches-pro' ),
								date_i18n( get_option( 'date_format' ),
									strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
							);
							break;
						case 'revoked' :
							$message = __( 'Your license key has been disabled.', 'woo-product-variation-swatches-pro' );
							break;
						case 'missing' :
							$message = __( 'Invalid license.', 'woo-product-variation-swatches-pro' );
							break;
						case 'invalid' :
						case 'site_inactive' :
							$message = __( 'Your license is not active for this URL.', 'woo-product-variation-swatches-pro' );
							break;
						case 'item_name_mismatch' :
							$message = __( 'This appears to be an invalid license key for Variation Swatches Pro.', 'woo-product-variation-swatches-pro' );
							break;
						case 'no_activations_left':
							$message = __( 'Your license key has reached its activation limit.', 'woo-product-variation-swatches-pro' );
							break;
						default :
							$message = __( 'An error occurred, please try again.', 'woo-product-variation-swatches-pro' );
							break;
					}
				}
				// Check if anything passed on a message constituting a failure
				if ( empty( $message ) ) {
					rtwpvs()->update_option( 'license_status', sanitize_text_field( $license_data->license ) );
					$error = false;
					$type  = 'license_deactivate';
					$value = __( 'Deactivate License', 'woo-product-variation-swatches-pro' );
				}
			}
		}
		if ( $request_type === 'license_deactivate' ) {
			$api_params = array(
				'edd_action' => 'deactivate_license',
				'license'    => $license_key,
				'item_id'    => self::$product_id,
				'url'        => home_url()
			);
			$response   = wp_remote_post( self::$store_url,
				array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

			// Make sure there are no errors
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				$err     = is_wp_error( $response ) ? $response->get_error_message() : '';
				$message = ! empty( $err ) ? esc_html( $err ) : __( 'An error occurred, please try again.', 'woo-product-variation-swatches-pro' );
			} else {
				rtwpvs()->update_option( 'license_status', '' );
				$error = false;
				$type  = 'license_activate';
				$value = __( 'Activate License', 'woo-product-variation-swatches-pro' );
			}
		}
		$response = array(
			'error' => $error,
			'msg'   => $message,
			'type'  => $type,
			'value' => $value,
			'data'  => $data
		);
		wp_send_json( $response );
	}

}
