<?php

namespace Rtwpvsp\Controllers\Admin;

class AdminController {

    public function __construct() {
        new ScriptLoader();
        new AdminFilter();
    }
}