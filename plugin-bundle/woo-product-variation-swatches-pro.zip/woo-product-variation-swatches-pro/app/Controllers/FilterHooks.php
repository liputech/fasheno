<?php

namespace Rtwpvsp\Controllers;

use Rtwpvsp\Traits\SingletonTrait;

/**
 * Metaboxes class.
 */
class FilterHooks {
	/**
	 * Singleton Function.
	 */
	use SingletonTrait;

	/**
	 * Initial Function.
	 *
	 * @return void
	 */
	public function init() {
		$enable_archive_swatches = rtwpvs()->get_option( 'archive_swatches' );
		add_filter( 'rtwpvs_variation_attribute_default_type', [ $this, 'attribute_default_button_type' ] );
		add_filter( 'rtwpvs_product_attribute_is_default_to_image', [ $this, 'attribute_default_button_type' ] );
		add_filter( 'wp_kses_allowed_html', [ __CLASS__, 'allow_select_for_post_context' ], 10, 2 );
		add_filter( 'body_class', [ __CLASS__, 'body_class' ] );
		if ( $enable_archive_swatches ) {
			add_filter( 'woocommerce_product_get_image', [ $this, 'default_variation_image_html' ], 20, 5 );
		}
	}

	/**
	 * Replace image HTML with default variation image HTML if set.
	 *
	 * @param string       $image       Current image HTML.
	 * @param \WC_Product  $product     Product object.
	 * @param string|array $size        Image size.
	 * @param array        $attr        Image attributes.
	 * @return string
	 */
	public function default_variation_image_html( $image, $product, $size, $attr ) {
		if ( ! $product->is_type( 'variable' ) ) {
			return $image;
		}
		$variation = $this->get_default_variation( $product );
		if ( ! ( $variation && $variation->get_image_id() ) ) {
			return $image;
		}
		// Generate full <img> tag for variation image.
		$variation_image = wp_get_attachment_image( $variation->get_image_id(), $size, false, $attr );
		if ( ! $variation_image ) {
			return $image;
		}
		// Get src + dimensions for custom data-o_* attributes.
		$o_src  = wp_get_attachment_image_url( $product->get_image_id(), $size );
		$srcset = wp_get_attachment_image_srcset( $product->get_image_id(), $size );
		// Inject the extra attributes (data-o_src, data-o_width, data-o_height).
		$variation_image = preg_replace(
			'/<img /',
			sprintf(
				'<img data-o_src="%s" data-o_srcset="%s" ',
				esc_url( $o_src ),
				esc_attr( $srcset )
			),
			$variation_image,
			1
		);
		return $variation_image; // fallback to parent.
	}

	/**
	 * Helper: Get the default variation product object.
	 *
	 * @param WC_Product_Variable $product Variable product.
	 * @return WC_Product_Variation|false
	 */
	private function get_default_variation( $product ) {
		$default_attributes = $product->get_default_attributes();

		if ( empty( $default_attributes ) ) {
			return false;
		}

		// Format attributes properly.
		$formatted_attributes = [];
		foreach ( $default_attributes as $taxonomy => $value ) {
			$formatted_attributes[ 'attribute_' . $taxonomy ] = $value;
		}

		// Use WC core function to find matching variation.
		$data_store   = \WC_Data_Store::load( 'product' );
		$variation_id = $data_store->find_matching_product_variation( $product, $formatted_attributes );

		if ( ! $variation_id ) {
			return false;
		}

		return wc_get_product( $variation_id ); // Returns WC_Product_Variation object.
	}
	/**
	 * @param $tags
	 * @param $context
	 * @return mixed
	 */
	static function allow_select_for_post_context( $tags, $context ) {
		if ( 'post' === $context ) {
			$tags['select'] = [
				'name'                  => true,
				'id'                    => true,
				'class'                 => true,
				'style'                 => true,
				'data-id'               => true,
				'data-attribute_name'   => true,
				'data-show_option_none' => true,
			];
			$tags['option'] = [
				'value'    => true,
				'class'    => true,
				'selected' => true,
			];
		}
		return $tags;
	}

	static function body_class( $classes ) {
		if ( rtwpvs()->get_option( 'shape_style_checkmark' ) ) {
			$classes[] = 'rtwpvs-shape-checkmark';
		}
		return array_unique( $classes );
	}

	/**
	 * Undocumented function
	 *
	 * @return void
	 */
	public function attribute_default_button_type( $type ) {
		if ( rtwpvs()->get_option( 'default_to_image' ) ) {
			$type = 'image';
		}

		if ( ! $type && ( is_shop() || is_product_taxonomy() ) ) {
			$type = 'button';
		}

		return $type;
	}
}
